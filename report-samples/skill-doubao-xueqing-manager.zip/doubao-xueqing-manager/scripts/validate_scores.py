#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""校验学情成绩数据集（doubao-xueqing-manager 质量门）。

检查项：
- 逐题得分完整性（缺失必须标记并说明，不允许省略）
- 传入题目档案时：每名学生必须覆盖档案中的全部题目，且不得出现档案外的题号
- 总分 = 各题得分之和（逐题完整时）
- 总分 = 题型分之和
- 每题得分 <= 满分（可配合题目档案）
- 重复学生（exam_id+考号+班级+姓名）
- 得分率与总分/满分一致
- 只有总分（无逐题得分）的记录：只核对总分与得分率；同一数据集不允许部分有逐题、部分没有
- 多科成绩（"subjects": {"语文": 95, ...}）：各科得分 ≤ 该科满分、总分 = 各科得分之和、
  每人科目齐全（该科缺考写 null）；不与逐题得分混用
- 缺考（"absent": true）的记录：不做分数核对，只提示

用法:
    python3 validate_scores.py <成绩.json> [--paper <题目档案.json>] [--index <exam_index.json>]
        [--allow-missing-questions] [--strict]
    --index 用于读取多科考试的各科满分（考试条目的 subjects）；记录里也可写 subject_full。

退出码: 0=通过  1=存在错误  2=使用错误
"""
import argparse
import json
import sys


def first_present(r, *keys):
    """按顺序取第一个存在且不为 None 的字段值（0 也算有值）。"""
    for k in keys:
        v = r.get(k)
        if v is not None:
            return v
    return None


def main():
    ap = argparse.ArgumentParser(description="校验学情成绩数据集")
    ap.add_argument("dataset", help="成绩数据集 JSON 路径")
    ap.add_argument("--paper", default=None, help="题目档案 JSON 路径（提供每题满分，可选）")
    ap.add_argument("--index", default=None, help="exam_index.json（多科考试：读取各科满分）")
    ap.add_argument("--allow-missing-questions", action="store_true",
                    help="存在逐题得分缺失时降级为警告（默认视为错误）")
    ap.add_argument("--strict", action="store_true", help="严格模式：有警告也返回退出码1")
    args = ap.parse_args()

    try:
        with open(args.dataset, encoding="utf-8-sig") as f:
            data = json.load(f)
    except Exception as e:
        print(f"无法读取数据集: {e}")
        sys.exit(2)
    records = data if isinstance(data, list) else data.get("students", data.get("records", []))
    if not records:
        print("数据集为空或结构无法识别")
        sys.exit(2)

    # 题目档案（可选）：qid -> max_score
    paper_max = {}
    if args.paper:
        try:
            with open(args.paper, encoding="utf-8-sig") as f:
                p = json.load(f)
        except Exception as e:
            print(f"无法读取题目档案: {e}")
            sys.exit(2)
        qs = p.get("questions", p) if isinstance(p, dict) else p
        for q in qs:
            qid = q.get("qid") or q.get("id")
            if qid:
                paper_max[qid] = q.get("max_score", q.get("max"))

    # 多科考试的各科满分：考试档案 subjects 或记录里的 subject_full
    subj_full = {}
    if args.index:
        try:
            with open(args.index, encoding="utf-8-sig") as f:
                idx = json.load(f)
        except Exception as e:
            print(f"无法读取考试档案: {e}")
            sys.exit(2)
        ids = {r.get("exam_id") for r in records}
        for e in idx.get("exams", []):
            if e.get("exam_id") in ids and isinstance(e.get("subjects"), dict):
                subj_full.update(e["subjects"])
    for r in records:
        if isinstance(r.get("subject_full"), dict):
            for k, v in r["subject_full"].items():
                subj_full.setdefault(k, v)

    errors, warnings = [], []
    seen = set()
    totals_only, with_q, with_subj, absents = [], [], [], []
    subj_absent = []
    subj_names = None

    for r in records:
        name = r.get("name") or r.get("姓名") or "(无名)"
        cls = r.get("class") or r.get("班级")
        exam = r.get("exam_id") or r.get("exam") or "?"
        sid = r.get("student_id") or r.get("考号")

        key = (exam, sid, cls, name)
        if key in seen:
            errors.append(f"[{exam}] 重复学生: {name} 班级={cls} 考号={sid}")
        seen.add(key)

        if r.get("absent"):
            absents.append(name)
            continue

        # --- 多科成绩：subjects = {科目: 得分 或 null(该科缺考)} ---
        subj = r.get("subjects")
        if isinstance(subj, dict) and subj:
            with_subj.append(name)
            if r.get("scores"):
                errors.append(f"[{exam}] {name} 同时有 subjects（各科得分）和 scores（逐题得分）；多科成绩只写各科得分")
            keys = list(subj.keys())
            if subj_names is None:
                subj_names = keys
            elif set(keys) != set(subj_names):
                lack = [k for k in subj_names if k not in subj]
                more = [k for k in keys if k not in subj_names]
                errors.append(f"[{exam}] {name} 科目与其他学生不一致"
                              + (f"，缺少 {'、'.join(lack)}（该科缺考请写 null）" if lack else "")
                              + (f"，多出 {'、'.join(more)}" if more else ""))
            if subj_full:
                unknown = [k for k in keys if k not in subj_full]
                if unknown:
                    errors.append(f"[{exam}] {name} 科目 {'、'.join(unknown)} 不在考试档案的 subjects 中")
            got, present, nulls = 0.0, 0, []
            for k, v in subj.items():
                if v is None:
                    nulls.append(f"{name}（{k}）")
                    continue
                try:
                    v = float(v)
                except (TypeError, ValueError):
                    errors.append(f"[{exam}] {name} {k} 得分非数值: {v!r}")
                    continue
                present += 1
                got += v
                mx = subj_full.get(k)
                if v < 0 or (mx is not None and v > float(mx) + 1e-6):
                    errors.append(f"[{exam}] {name} {k} 得分 {v} 不在 0–{mx} 之间")
            if not present:
                errors.append(f"[{exam}] {name} 各科都没有成绩；全科缺考请标 \"absent\": true")
                continue
            subj_absent.extend(nulls)
            total = first_present(r, "total", "总分")
            if total is None:
                errors.append(f"[{exam}] {name} 没有总分（total 应为各科得分之和 {got:g}）")
                continue
            try:
                total = float(total)
            except (TypeError, ValueError):
                errors.append(f"[{exam}] {name} 总分非数值: {total!r}")
                continue
            if abs(total - got) > 1e-6:
                errors.append(f"[{exam}] {name} 总分 {total:g} != 各科得分之和 {got:g}（差 {total - got:g}）")
            rate, full = first_present(r, "score_rate", "得分率"), r.get("full_score")
            if rate is not None and full:
                try:
                    rate = float(rate)
                    rate = rate / 100.0 if rate > 1 else rate
                    if abs(round(rate, 4) - round(total / float(full), 4)) > 0.01:
                        errors.append(f"[{exam}] {name} 得分率 {rate} != 期望 {round(total / float(full), 4)}")
                except (TypeError, ValueError):
                    pass
            if subj_full and full and abs(float(full) - sum(float(v) for v in subj_full.values())) > 1e-6:
                errors.append(f"[{exam}] {name} 满分 {full} 与各科满分之和不一致")
            continue

        # --- 逐题得分：canonical scores dict 或中文明细数组/字典 ---
        scores = r.get("scores") or {}
        canonical = bool(scores)
        cn_q = {}
        for sec_key in ("选择题明细", "填空题明细", "解答题明细"):
            v = r.get(sec_key)
            if isinstance(v, dict):
                for k, val in v.items():
                    cn_q[f"{sec_key.replace('明细', '')}-{k}"] = val
            elif isinstance(v, list):
                for i, val in enumerate(v, 1):
                    cn_q[f"{sec_key.replace('明细', '')}-{i}"] = val
        if cn_q and not scores:
            scores = cn_q

        has_q = bool(scores)
        (with_q if has_q else totals_only).append(name)

        # --- 题目覆盖：有题目档案时，逐题记录必须与档案一一对应 ---
        if paper_max and canonical:
            absent = [q for q in paper_max if q not in scores]
            unknown = [q for q in scores if q not in paper_max]
            if absent:
                shown = ", ".join(absent[:10]) + ("..." if len(absent) > 10 else "")
                errors.append(f"[{exam}] {name} 漏录 {len(absent)} 题（记录中没有这些题号）: {shown}")
            if unknown:
                shown = ", ".join(unknown[:10]) + ("..." if len(unknown) > 10 else "")
                errors.append(f"[{exam}] {name} 有 {len(unknown)} 个题号不在题目档案中: {shown}")

        q_sum = 0.0
        missing = []
        for qid, v in scores.items():
            if isinstance(v, dict):
                sc, mx = v.get("score"), v.get("max")
            else:
                sc, mx = v, None
            if sc is None:
                missing.append(qid)
                continue
            try:
                sc = float(sc)
            except (TypeError, ValueError):
                errors.append(f"[{exam}] {name} 题 {qid} 得分非数值: {sc!r}")
                continue
            q_sum += sc
            if mx is None:
                mx = paper_max.get(qid)
            if mx is not None:
                try:
                    if sc > float(mx) + 1e-6:
                        errors.append(f"[{exam}] {name} 题 {qid} 得分 {sc} > 满分 {mx}")
                except (TypeError, ValueError):
                    pass

        if missing:
            shown = ", ".join(missing[:10]) + ("..." if len(missing) > 10 else "")
            msg = f"[{exam}] {name} {len(missing)} 题得分缺失: {shown}"
            if args.allow_missing_questions:
                warnings.append(msg)
            else:
                errors.append(msg + "（可用 --allow-missing-questions 降级为警告）")

        # --- 题型分 ---
        sec = r.get("section_scores") or {}
        cn_sec = {}
        for k in ("选择题得分", "填空题得分", "解答题得分"):
            if k in r:
                cn_sec[k.replace("得分", "")] = r[k]
        if cn_sec and not sec:
            sec = cn_sec
        try:
            sec_sum = sum(float(v) for v in sec.values()) if sec else None
        except (TypeError, ValueError):
            sec_sum = None
        if has_q and sec_sum is not None and not missing and abs(sec_sum - q_sum) > 1e-6:
            errors.append(f"[{exam}] {name} 题型分合计 {sec_sum} != 各题得分合计 {q_sum}")

        # --- 总分 ---
        total = first_present(r, "total", "总分")
        if total is not None:
            try:
                total = float(total)
            except (TypeError, ValueError):
                errors.append(f"[{exam}] {name} 总分非数值: {total!r}")
                total = None
            if total is not None:
                if has_q and not missing and abs(total - q_sum) > 1e-6:
                    errors.append(f"[{exam}] {name} 总分 {total} != 各题得分合计 {q_sum}（差 {total - q_sum}）")
                if sec_sum is not None and abs(total - sec_sum) > 1e-6:
                    errors.append(f"[{exam}] {name} 总分 {total} != 题型分合计 {sec_sum}")

        # --- 得分率 ---
        rate = first_present(r, "score_rate", "得分率")
        full = r.get("full_score")
        if total is None and not has_q:
            errors.append(f"[{exam}] {name} 既没有逐题得分也没有总分（缺考请标 \"absent\": true）")
        base = total if total is not None else (None if (missing or not has_q) else q_sum)
        if rate is not None and full and base is not None:
            try:
                rate = float(rate)
                got = rate / 100.0 if rate > 1 else rate
                exp = round(base / float(full), 4)
                if abs(round(got, 4) - exp) > 0.01:
                    errors.append(f"[{exam}] {name} 得分率 {got} != 期望 {exp}")
            except (TypeError, ValueError):
                pass

    kinds = [(len(with_q), "逐题得分"), (len(with_subj), "各科得分"), (len(totals_only), "只有总分")]
    present_kinds = [(n, k) for n, k in kinds if n]
    if len(present_kinds) > 1:
        eg = f"（只有总分的如 {'、'.join(totals_only[:5])}）" if totals_only else ""
        errors.append("同一数据集里混有 " + "、".join(f"{n} 人{k}" for n, k in present_kinds) + eg
                      + "；请统一为一种（逐题得分 / 各科得分 / 只有总分）")
    elif with_subj:
        if not subj_full:
            warnings.append("未提供各科满分（--index 考试档案的 subjects 或记录里的 subject_full）：未核对各科得分上限")
        warnings.append(f"{len(with_subj)} 名学生为多科成绩（{'、'.join(subj_names or [])}）：可出成绩分析报告与试卷分析报告，"
                        "错题分析报告需要逐题得分")
        if subj_absent:
            warnings.append(f"单科缺考 {len(subj_absent)} 人次（该科不计入统计）：{'、'.join(subj_absent[:20])}"
                            + ("……" if len(subj_absent) > 20 else ""))
    elif totals_only:
        warnings.append(f"{len(totals_only)} 名学生只有总分、没有逐题得分：只核对总分与得分率；"
                        "错题分析报告需要逐题得分，可出成绩分析报告或试卷分析报告")
    if absents:
        warnings.append(f"缺考 {len(absents)} 人（不参与统计）：{'、'.join(absents)}")

    # --- 输出 ---
    n = len(records)
    if errors:
        print(f"✗ 发现 {len(errors)} 个错误、{len(warnings)} 个警告（共 {n} 条记录）：")
        for e in errors[:60]:
            print("  [错误]", e)
        for w in warnings[:30]:
            print("  [警告]", w)
        sys.exit(1)
    if warnings:
        print(f"✓ 无错误，{len(warnings)} 个警告（共 {n} 条记录）：")
        for w in warnings[:30]:
            print("  [警告]", w)
        sys.exit(0 if not args.strict else 1)
    print(f"✓ 通过：{n} 条记录，逐题得分完整且总分一致")
    sys.exit(0)


if __name__ == "__main__":
    main()
