#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""学情报告生成（doubao-xueqing-manager 模式B/C/E）。

版式全部写死在本脚本里：区块顺序、图表类型、配色、图标、卡片样式。
数字全部由脚本从数据文件计算；模型只在分析文件里写短文字。

用法:
  # 1) 生成/补全分析文件骨架（已填的内容保留），列出需要模型填写的空位
  python3 report.py skeleton --type error --scope student --dataset 学情数据/zk1_成绩.json \
      --paper 学情数据/zk1_题目档案.json --analysis 学情数据/zk1_分析.json --student all

  # 2) 只检查文字（不出文件）
  python3 report.py render ... --check-only

  # 3) 出报告（默认 PDF）
  python3 report.py render --type error|score|paper [--scope class|student] \
      --dataset <成绩.json> [--paper <题目档案.json>] [--analysis <分析.json>] \
      [--index <exam_index.json>] [--class "八(9)"] [--student <考号|姓名|all>] \
      [--format pdf|word|html|pdf+html|all] [--out-dir 学情报告] [--dump-json <数字.json>]

导出格式: PDF（默认）、Word、HTML，可组合。三种格式由同一段组装逻辑生成，内容与图表完全一致；
  PDF 默认由 Word 经 LibreOffice 转换；没有 LibreOffice 时自动改用 WeasyPrint 转换脚本生成的 HTML
  （--pdf-engine 可指定）。HTML 为自包含单文件，屏幕自适应、打印为 A4。

报告类型:
  --type error --scope class    错题分析报告·全班版（需要逐题得分）
  --type error --scope student  错题分析报告·单人版（--student 必填，all = 班内每人一份）
  --type score                  成绩分析报告：一个班、几个班或整个年级合成一份（不写 --class 时为全部班级），
                                单科或多科（成绩记录写 subjects）；封面、摘要、考试基本情况、总体概况、
                                班级比较（多班）、学科比较（多科）/ 题型与小题（单科有小题分）、学生情况、
                                主要问题、教学建议、附录成绩单
  --type paper                  试卷分析报告：考情分析 / 班级学情分析 / 试卷分析 / 改进计划，
                                一个或多个班合成一份（不写 --class 时为数据集中全部班级）
  只有总分或只有各科成绩的数据可出 score 与 paper；error 需要逐题得分。

退出码: 0=成功  1=数据或文字检查不通过  2=参数错误  3=环境缺少字体或 PDF 转换工具
"""
import argparse
import base64
import html
import json
import math
import os
import re
import shutil
import subprocess
import sys
import statistics
import tempfile
from collections import OrderedDict, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from build_exam_index import DEFAULT_CONFIG  # noqa: E402

# ---------------------------------------------------------------- 常量

ERROR_TYPES = ["概念不清", "计算失误", "审题失误", "方法不会", "步骤不全", "时间不足", "其他"]
BASIS = ["答卷", "推断", "待确认"]
FLUFF = ["加强练习", "多加练习", "多做练习", "多做题", "继续努力", "再接再厉", "注意细心",
         "提高认识", "端正态度", "认真对待", "查漏补缺", "巩固基础", "夯实基础"]
QNO_RE = re.compile(r"第\s*\d+\s*(题|小题)|Q\d+|\d+\s*题")
LIMITS = {  # 字段: (字数上限, 加粗上限)
    "错因": (20, 1), "表现": (20, 1), "纠正要点": (30, 1), "结论": (30, 2),
    "建议": (30, 1), "补充标题": (15, 0), "补充正文": (150, 2),
    "提升建议": (80, 1), "失分点": (60, 1), "计划": (80, 1), "班级分析": (200, 3),
    "摘要": (120, 2), "学科点评": (150, 1), "问题": (100, 1), "教学建议": (100, 1), "小结": (200, 3),
}
SUMMARY_PARTS = ["总体", "班级", "学科", "题型", "建议"]
PLAN_PARTS = ["专项练习", "分层要求", "班级措施", "评价反馈"]


def split_classes(value):
    """--class 支持多个班：二班,四班 / 二班、四班 / 二班+四班。"""
    if not value:
        return []
    return [x.strip() for x in re.split(r"[,，、+＋;；]", str(value)) if x.strip()]

# 配色（公文样式：参照学校教务处成绩分析报告——藏青、砖红、橙、墨绿，浅灰网格；不用图标与彩色卡片）
INK, INK2, MUTED = "#1a1a1a", "#404040", "#7f7f7f"
SRC = "#6e6e6e"  # 数据来源行
RULE = "#808080"  # 表格线、页眉线
GRID, AXIS = "#e6e6e6", "#333333"
BLUE, CMP_GRAY = "#2e5c8a", "#a6a6a6"
GOOD, WARN, SERIOUS, CRIT = "#4f8a5b", "#d98e32", "#e3ad6b", "#c0504d"
TIER_RAMP = ["#b5c9d8", "#6b9bc4", "#2e5c8a", "#1f4e79"]
TIER_RAMP5 = ["#b5c9d8", "#8fb3d3", "#6b9bc4", "#2e5c8a", "#1f4e79"]
# 色块表底色：低于低分线 / 低分线–及格线 / 及格线以上三级（越深越高），文字一律深色
HEAT_LOW, HEAT_MID = "#f2dcdb", "#fbe5d6"
HEAT_UP = ["#e9eff7", "#d6e3f0", "#bfd3e8"]
SERIES = ["#2e5c8a", "#c0504d", "#d98e32", "#4f8a5b", "#6b9bc4", "#3e8e8e", "#8064a2", "#7f7f7f"]
DARK_FILLS = {BLUE, CRIT, GOOD, TIER_RAMP5[3], TIER_RAMP5[4], SERIES[5], SERIES[6], SERIES[7]}
TABLE_HEAD, ZEBRA, CARD_HEAD = "#d9d9d9", "#f2f2f2", "#f2f2f2"
# Word 字体：中文正文宋体、标题黑体、封面信息楷体，西文 Times New Roman（与学校公文一致）
SONG, HEI, KAI, LATIN = "宋体", "黑体", "楷体", "Times New Roman"
SONG_CANDIDATES = ["SimSun", "宋体", "Songti SC", "STSong", "Noto Serif CJK SC", "Source Han Serif SC", "思源宋体",
                   "Noto Serif SC", "AR PL UMing CN", "Noto Serif CJK JP"]
KAI_CANDIDATES = ["KaiTi", "楷体", "STKaiti", "Kaiti SC", "AR PL UKai CN"]

FONT_CANDIDATES = ["Noto Sans CJK SC", "Source Han Sans SC", "思源黑体", "Microsoft YaHei", "微软雅黑",
                   "PingFang SC", "Noto Sans SC", "WenQuanYi Micro Hei", "WenQuanYi Zen Hei",
                   "SimHei", "黑体", "Noto Sans CJK JP"]


class ReportError(Exception):
    def __init__(self, msg, code=1):
        super().__init__(msg)
        self.code = code


# ---------------------------------------------------------------- 导出格式

FORMATS = ("pdf", "docx", "html")
FORMAT_NAMES = {"pdf": "PDF", "docx": "Word", "html": "HTML"}
FORMAT_ALIASES = {
    "pdf": {"pdf"}, "word": {"docx"}, "docx": {"docx"}, "doc": {"docx"},
    "html": {"html"}, "htm": {"html"}, "网页": {"html"},
    "all": set(FORMATS), "全部": set(FORMATS), "三种": set(FORMATS),
    "both": {"pdf", "docx"},  # 兼容旧写法：PDF + Word
}


def parse_formats(value):
    """解析导出格式（命令行 --format 与 config.报告格式 共用）。
    接受 PDF / Word / HTML 及组合（PDF+HTML、PDF和Word、all/全部）；不认识的格式直接报错。"""
    if isinstance(value, (list, tuple)):
        parts = [str(x) for x in value]
    else:
        parts = re.split(r"[+＋、,，/|;；\s]+|以及|和|与|及", str(value or ""))
    out, bad = set(), []
    for raw in parts:
        x = raw.strip().lower()
        if not x:
            continue
        if x in FORMAT_ALIASES:
            out |= FORMAT_ALIASES[x]
        else:
            bad.append(raw.strip())
    if bad or not out:
        raise ReportError(f"不支持的导出格式：{'、'.join(bad) if bad else repr(value)}。"
                          "只支持 PDF、Word、HTML，可以组合（如 PDF+HTML、PDF和Word），all / 全部 = 三种都出。", 2)
    return [f for f in FORMATS if f in out]


# ---------------------------------------------------------------- 工具

def memo(fn):
    """同一张图只画一次：三种格式共用同一批图表图片，保证内容一致、也省时间。"""
    def wrap(self, *a, **k):
        if any(callable(x) for x in list(a) + list(k.values())):
            return fn(self, *a, **k)
        key = (fn.__name__, repr(a), repr(sorted(k.items())))
        if key not in self._memo:
            self._memo[key] = fn(self, *a, **k)
        return self._memo[key]
    wrap.__name__ = fn.__name__
    return wrap


def load_json(path):
    with open(path, encoding="utf-8-sig") as f:
        return json.load(f)


def fmt_score(x):
    if x is None:
        return "—"
    return str(int(round(x))) if abs(x - round(x)) < 1e-9 else f"{x:.1f}"


def fmt_pct(r):
    return "—" if r is None else f"{r * 100:.1f}%"


def fmt_line(x):
    """分数线按实际值显示（最多 2 位小数），如 580.55；避免四舍五入后看起来“刚好达线”。"""
    return f"{round(x, 2):.2f}".rstrip("0").rstrip(".")


def r1(x):
    """按显示精度（1 位小数）取值：差值用显示值相减，避免与表里的数字差 0.1。"""
    return float(f"{x:.1f}")


def rp(x):
    """比率按显示精度取百分数值（如 0.41935 → 41.9）。"""
    return float(f"{x * 100:.1f}")


CHOICE_RE = re.compile(r"^[A-Ha-h]{1,4}$")
PLACEHOLDER_RE = re.compile(r"^(未知|不详|无名|匿名|待定|unknown|n/?a|null|none)", re.I)


def choice_letters(x):
    """字母选项（如 A、bd、"B, D"）→ 大写；不是字母选项时返回 None。"""
    t = re.sub(r"[\s,，、]", "", str(x or ""))
    return t.upper() if CHOICE_RE.match(t) else None


def text_len(s):
    return len(re.sub(r"\s|\*\*", "", s or ""))


def bold_count(s):
    return (s or "").count("**") // 2


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\s]+', "", str(s))


def student_key(r):
    sid = r.get("student_id")
    return str(sid) if sid not in (None, "") else f"{r.get('name')}|{r.get('class')}"


def qno_label(q):
    return f"第{q['no']}题"


def short(s, n):
    s = s or ""
    return s if len(s) <= n else s[: n - 1] + "…"


def competition_rank(items, key):
    """并列同名次：[(obj, rank)]，按 key 降序。"""
    ordered = sorted(items, key=key, reverse=True)
    out, prev, rank = [], None, 0
    for i, it in enumerate(ordered, 1):
        v = key(it)
        if v != prev:
            rank, prev = i, v
        out.append((it, rank))
    return out


# ---------------------------------------------------------------- 字体与环境

def cjk_families():
    """已安装的中文字体族名（fc-list）。"""
    names = set()
    if shutil.which("fc-list"):
        try:
            out = subprocess.run(["fc-list", ":lang=zh", "family"], capture_output=True, text=True,
                                 timeout=30).stdout
            for line in out.splitlines():
                names.update(x.strip() for x in line.split(","))
        except Exception:
            pass
    return names


def font_substitutes():
    """LibreOffice 转 PDF 的字体替换表。Word 里写宋体 / 黑体 / 楷体（学校电脑都有）；
    转换环境没装这些字体时，换成已安装的宋体类、黑体类字体，正文不至于全部落到同一种黑体上。"""
    have = cjk_families()
    song = next((c for c in SONG_CANDIDATES if c in have), None)
    hei = next((c for c in FONT_CANDIDATES if c in have), None)
    kai = next((c for c in KAI_CANDIDATES if c in have), None) or song
    return {name: alt for name, alt in ((SONG, song or hei), (HEI, hei), (KAI, kai or hei))
            if alt and name not in have and alt != name}


def find_fonts():
    """返回 (HTML 兜底字体名, matplotlib 字体名)；找不到中文字体直接失败，避免出方框字。"""
    from matplotlib import font_manager
    mpl_names = {f.name for f in font_manager.fontManager.ttflist}
    mpl = next((c for c in FONT_CANDIDATES if c in mpl_names), None)
    fc_names = cjk_families()
    word = next((c for c in FONT_CANDIDATES if c in fc_names), None) or mpl
    if not mpl or not word:
        raise ReportError("未找到中文字体（如 Noto Sans CJK SC / 思源黑体 / 微软雅黑），图表与 PDF 会出现方框字；"
                          "请先安装中文字体。", 3)
    return word, mpl


def find_soffice():
    return shutil.which("soffice") or shutil.which("libreoffice")


# ---------------------------------------------------------------- 数据装载与计算

class Exam:
    """一场考试的数据：题目、学生、口径、元信息。"""

    def __init__(self, dataset_path, paper_path=None, cfg=None, meta=None):
        self.dataset_path = dataset_path
        data = load_json(dataset_path)
        recs = data if isinstance(data, list) else data.get("students", data.get("records", []))
        if not recs:
            raise ReportError(f"数据集为空或结构无法识别: {dataset_path}")
        # 缺考：不参与任何统计，只在报告里列名单
        self.absent = [{"name": r.get("name") or "姓名待确认", "class": r.get("class") or "未分班",
                        "sid": r.get("student_id")} for r in recs if r.get("absent")]
        recs = [r for r in recs if not r.get("absent")]
        if not recs:
            raise ReportError("数据集里所有学生都是缺考，没有可统计的成绩")
        # 逐题得分：要么都有，要么都没有（只有总分 / 多科成绩）
        has = [isinstance(r.get("scores"), dict) and bool(r["scores"]) for r in recs]
        if any(has) and not all(has):
            raise ReportError("同一数据集里部分学生有逐题得分、部分只有总分；请统一后再出报告")
        self.has_q = all(has)
        # 多科成绩：subjects = {科目: 得分 或 null（该科缺考）}，不与逐题得分混用
        hs = [isinstance(r.get("subjects"), dict) and bool(r["subjects"]) for r in recs]
        if any(hs) and (not all(hs) or self.has_q):
            raise ReportError("同一数据集里混有各科得分与逐题得分 / 只有总分的记录；请统一后再出报告")
        self.has_subj = all(hs)
        if not self.has_q:
            bad = [r.get("name") for r in recs if r.get("total") is None]
            if bad:
                raise ReportError(f"只有总分的数据集里，{'、'.join(map(str, bad[:5]))} 没有总分（缺考请标 \"absent\": true）")
        self.user_cfg = dict(cfg or {})
        self.cfg = dict(DEFAULT_CONFIG)
        self.cfg.update(cfg or {})
        self.meta = meta or {}
        self.exam_id = recs[0].get("exam_id") or self.meta.get("exam_id") or "exam"
        self.questions = self._load_questions(paper_path, recs)
        self.qmap = {q["qid"]: q for q in self.questions}
        # 各科满分：考试档案 subjects，或记录里的 subject_full；科目顺序按考试档案
        self.subjects = OrderedDict()
        if self.has_subj:
            src = self.meta.get("subjects") or recs[0].get("subject_full") or {}
            for k in (list(src.keys()) or list(recs[0]["subjects"].keys())):
                self.subjects[k] = float(src[k]) if k in src and src[k] else None
            for r in recs:
                for k in r["subjects"]:
                    self.subjects.setdefault(k, None)
            lack = [k for k, v in self.subjects.items() if not v]
            if lack:
                raise ReportError(f"缺少科目满分：{'、'.join(lack)}。请在考试档案登记 --subjects \"语文:150,数学:150,…\"", 2)
        self.full = float(self.meta.get("full_score") or recs[0].get("full_score")
                          or sum(self.subjects.values()) or sum(q["max"] for q in self.questions) or 0)
        if not self.full:
            raise ReportError("缺少满分：请在成绩记录的 full_score 或考试档案里写明满分")
        self.n_records = len(recs) + len(self.absent)
        # 分数段可以写比例（0~1）或分数（大于 1 的值按分数理解）
        raw_b = [float(x) for x in self.cfg["分数段"]]
        self.abs_bounds = any(x > 1 for x in raw_b)
        self.bounds = [x / self.full for x in raw_b] if self.abs_bounds else raw_b
        self.students = [self._student(r) for r in recs]
        self.sections = list(OrderedDict.fromkeys(q["section"] for q in self.questions))

    def _load_questions(self, paper_path, recs):
        qs = []
        if paper_path:
            p = load_json(paper_path)
            base = os.path.dirname(os.path.abspath(paper_path))
            raw = p.get("questions", p) if isinstance(p, dict) else p
            for i, q in enumerate(raw, 1):
                img = q.get("image")
                qs.append({
                    "qid": q.get("qid") or q.get("id"), "no": q.get("no", i),
                    "section": q.get("section") or "未分类", "text": q.get("text") or "",
                    "max": float(q.get("max_score", q.get("max", 0)) or 0),
                    "kps": [k for k in (q.get("knowledge_points") or []) if k] or ["待定"],
                    "answer": q.get("answer"),
                    "image": os.path.join(base, img) if img and not os.path.isabs(img) else img,
                })
        elif all(isinstance(r.get("scores"), dict) and r["scores"] for r in recs):
            for i, (qid, v) in enumerate(recs[0]["scores"].items(), 1):
                m = re.search(r"(\d+)\D*$", qid)
                qs.append({"qid": qid, "no": int(m.group(1)) if m else i, "section": "未分类", "text": "",
                           "max": float((v or {}).get("max") or 0), "kps": ["待定"], "answer": None,
                           "image": None})
        qs.sort(key=lambda q: (q["no"] if isinstance(q["no"], (int, float)) else 0))
        return qs

    def _student(self, r):
        base = os.path.dirname(os.path.abspath(self.dataset_path))
        sc, ans, img = {}, {}, {}
        for q in (self.questions if self.has_q else []):
            v = r["scores"].get(q["qid"])
            if isinstance(v, dict):
                sc[q["qid"]] = None if v.get("score") is None else float(v["score"])
                if v.get("answer") not in (None, ""):
                    ans[q["qid"]] = str(v["answer"]).strip()
                if v.get("image"):
                    img[q["qid"]] = v["image"] if os.path.isabs(v["image"]) else os.path.join(base, v["image"])
            else:
                sc[q["qid"]] = None if v is None else float(v)
        subj = OrderedDict()
        for k in self.subjects:
            v = (r.get("subjects") or {}).get(k)
            subj[k] = None if v is None else float(v)
        total = r.get("total")
        if total is None:
            total = sum(x for x in (subj or sc).values() if x is not None)
        total = float(total)
        return {"key": student_key(r), "name": r.get("name") or "姓名待确认", "class": r.get("class") or "未分班",
                "sid": r.get("student_id"), "total": total, "scores": sc, "answers": ans, "images": img,
                "subj": subj, "flag": r.get("flag"), "rank": r.get("rank"), "notes": r.get("notes") or []}

    # ---- 口径
    @property
    def pass_line(self):
        v = float(self.cfg["及格线"])
        return v if v > 1 else v * self.full

    @property
    def excel_line(self):
        v = float(self.cfg["优秀线"])
        return v if v > 1 else v * self.full

    def frac(self, key):
        """及格线 / 良好线 / 优秀线 / 低分线 的满分比例（写分数时换算成比例，各科按同一比例）。
        旧考试档案没写良好线、低分线时，先从分档名称里的“良好”“低分”推出，推不出才用默认值。"""
        if key in ("良好线", "低分线") and key not in self.user_cfg:
            names = self.cfg.get("分档名称") or []
            tier = "良好" if key == "良好线" else "低分"
            if tier in names and len(names) == len(self.bounds) - 1:
                i = names.index(tier)
                return self.bounds[i] if key == "良好线" else self.bounds[i + 1]
        v = float(self.cfg[key])
        return v / self.full if v > 1 else v

    def line(self, key, full=None):
        """某条线对应的分数：full 不写为总分满分，写科目满分时按同一比例。"""
        return self.frac(key) * (full or self.full)

    def classes(self):
        return list(OrderedDict.fromkeys(s["class"] for s in self.students))

    def in_class(self, cls):
        return [s for s in self.students if s["class"] == cls]

    def tier_of(self, total):
        b = self.bounds
        frac = total / self.full if self.full else 0
        for i in range(len(b) - 1):
            if frac < b[i + 1]:
                return i
        return len(b) - 2

    def tier_names(self):
        b = self.cfg["分数段"]
        names = self.cfg.get("分档名称") or []
        self.tier_names_auto = len(names) != len(b) - 1
        if len(names) != len(b) - 1:
            if self.abs_bounds:
                names = [f"{fmt_score(float(b[1]))}分以下"] + [
                    f"{fmt_score(float(b[i]))}–{fmt_score(float(b[i + 1]))}分" for i in range(1, len(b) - 1)]
            else:
                names = [f"{int(b[i] * 100)}–{int(b[i + 1] * 100)}%" for i in range(len(b) - 1)]
        return names

    def tier_range(self, i):
        """第 i 档的分数区间文字。"""
        lo, hi = self.bounds[i] * self.full, self.bounds[i + 1] * self.full
        if i == 0:
            return f"{fmt_score(hi)} 分以下"
        if i == len(self.bounds) - 2:
            return f"{fmt_score(lo)}–{fmt_score(hi)} 分"
        return f"{fmt_score(lo)}–{fmt_score(hi)} 分（不含 {fmt_score(hi)}）"

    # ---- 统计
    def stats(self, vals, full):
        """一组分数（总分或某科）的指标；各条线按 full 的同一比例。"""
        n = len(vals)
        if not n:
            return {"人数": 0, "平均分": None, "中位数": None, "标准差": None, "最高分": None, "最低分": None,
                    "得分率": None, "及格率": None, "良好率": None, "优秀率": None, "低分率": None}
        avg = sum(vals) / n

        def share(cond):
            return sum(1 for v in vals if cond(v)) / n
        pl, gl, el, ll = (self.line(k, full) for k in ("及格线", "良好线", "优秀线", "低分线"))
        return {"人数": n, "平均分": avg, "中位数": statistics.median(vals), "标准差": statistics.pstdev(vals),
                "最高分": max(vals), "最低分": min(vals), "得分率": avg / full if full else None,
                "及格率": share(lambda v: v >= pl - 1e-9), "良好率": share(lambda v: v >= gl - 1e-9),
                "优秀率": share(lambda v: v >= el - 1e-9), "低分率": share(lambda v: v < ll - 1e-9)}

    def overall(self, studs):
        tot = [s["total"] for s in studs]
        n = len(tot)
        tiers = [0] * (len(self.cfg["分数段"]) - 1)
        for t in tot:
            tiers[self.tier_of(t)] += 1
        out = self.stats(tot, self.full)
        # 及格率、优秀率沿用原口径（考试档案写分数时直接按分数比较）
        out.update({
            "及格率": sum(t >= self.pass_line - 1e-9 for t in tot) / n if n else None,
            "优秀率": sum(t >= self.excel_line - 1e-9 for t in tot) / n if n else None,
            "分档人数": tiers,
        })
        return out

    def subj_stats(self, studs, subj):
        """某科指标：只算该科有成绩的学生（单科缺考不计入）。"""
        full = self.subjects[subj]
        return self.stats([s["subj"][subj] for s in studs if s["subj"].get(subj) is not None], full)

    def q_stats(self, studs):
        out = OrderedDict()
        for q in self.questions:
            vals = [s["scores"][q["qid"]] for s in studs if s["scores"].get(q["qid"]) is not None]
            n = len(vals)
            rate = sum(vals) / (q["max"] * n) if n and q["max"] else None
            out[q["qid"]] = {
                "得分率": rate, "均分": sum(vals) / n if n else None, "有效人数": n,
                "满分人数": sum(v >= q["max"] - 1e-9 for v in vals),
                "零分人数": sum(v <= 1e-9 for v in vals) if q["max"] else 0,
                "部分人数": sum(1e-9 < v < q["max"] - 1e-9 for v in vals),
            }
        return out

    def sec_rates(self, studs):
        out = OrderedDict()
        for sec in self.sections:
            got = full = 0.0
            for q in self.questions:
                if q["section"] != sec:
                    continue
                for s in studs:
                    v = s["scores"].get(q["qid"])
                    if v is not None:
                        got += v
                        full += q["max"]
            out[sec] = got / full if full else None
        return out

    def kp_rates(self, studs):
        got, full = defaultdict(float), defaultdict(float)
        for q in self.questions:
            for s in studs:
                v = s["scores"].get(q["qid"])
                if v is None:
                    continue
                for k in q["kps"]:
                    got[k] += v
                    full[k] += q["max"]
        return {k: got[k] / full[k] for k in full if full[k]}

    def lost(self, s):
        """本人失分题（得分 < 满分），按题号。"""
        return [q for q in self.questions
                if s["scores"].get(q["qid"]) is not None and s["scores"][q["qid"]] < q["max"] - 1e-9]

    def weak_kps(self, s, kp_rates, below):
        """薄弱知识点：得分率低于 below，按得分率升序；并列时失分多的在前。"""
        lost = defaultdict(float)
        for q in self.questions:
            v = s["scores"].get(q["qid"])
            if v is not None:
                for k in q["kps"]:
                    lost[k] += q["max"] - v
        ks = [k for k in kp_rates if kp_rates[k] < below and k != "待定"]
        return sorted(ks, key=lambda k: (round(kp_rates[k], 6), -lost[k], k))

    def missing(self, s):
        if not self.has_q:  # 只有总分：不是“缺失”，是本来就没有逐题数据
            return []
        return [q for q in self.questions if s["scores"].get(q["qid"]) is None]

    def ranks(self, studs):
        return {s["key"]: r for s, r in competition_rank(studs, key=lambda s: s["total"])}


def load_context(args):
    cfg, meta, index, index_dir = {}, {}, None, None
    if args.index:
        index = load_json(args.index)
        index_dir = os.path.dirname(os.path.abspath(args.index))
        cfg = index.get("config") or {}
    probe = load_json(args.dataset)
    probe = probe if isinstance(probe, list) else probe.get("students", probe.get("records", []))
    exam_id = args.exam_id or (probe[0].get("exam_id") if probe else None)
    if index:
        for e in index.get("exams", []):
            if e.get("exam_id") == exam_id:
                meta = dict(e)
    meta.setdefault("exam_id", exam_id)
    if args.exam_name:
        meta["name"] = args.exam_name
    exam = Exam(args.dataset, args.paper, cfg, meta)
    analysis = load_json(args.analysis) if args.analysis and os.path.exists(args.analysis) else {}
    history = []
    if index:
        cur_date = meta.get("date") or "9999-99-99"
        for e in sorted(index.get("exams", []), key=lambda e: e.get("date", "9999-99-99")):
            if e.get("exam_id") == exam_id:
                history.append(("cur", e, exam))
                continue
            if e.get("date", "9999-99-99") > cur_date or not e.get("dataset"):
                continue
            ds = e["dataset"] if os.path.isabs(e["dataset"]) else os.path.join(index_dir, e["dataset"])
            pp = e.get("paper")
            pp = (pp if os.path.isabs(pp) else os.path.join(index_dir, pp)) if pp else None
            if not os.path.exists(ds):
                continue
            try:
                history.append(("old", e, Exam(ds, pp if pp and os.path.exists(pp) else None, cfg, e)))
            except ReportError:
                continue
        history = [h for h in history if h[0] == "old"] + [h for h in history if h[0] == "cur"]
    return exam, analysis, history


# ---------------------------------------------------------------- 分析文字：骨架与检查

def scope_students(exam, cls, student):
    studs = exam.in_class(cls)
    if student in (None, "", "all"):
        return studs
    hit = [s for s in studs if student in (s["key"], str(s["sid"]), s["name"])]
    if len(hit) > 1:
        raise ReportError(f"班级 {cls} 中有多名学生匹配 {student}，请改用考号", 2)
    return hit


def required_slots(exam, rtype, scope, cls, student):
    """返回该报告需要模型填写的字段清单: [(路径元组, 种类)]。"""
    slots = []
    if rtype != "error":
        return slots
    studs = exam.in_class(cls)
    if scope == "class":
        qs = exam.q_stats(studs)
        for q in exam.questions:
            r = qs[q["qid"]]["得分率"]
            if r is not None and r < 1 - 1e-9:
                slots.append((("questions", q["qid"], "错因"), "错因"))
                slots.append((("questions", q["qid"], "纠正要点"), "纠正要点"))
        for s in studs:
            if exam.lost(s):
                slots.append((("advice", s["key"]), "建议"))
    else:
        for s in scope_students(exam, cls, student):
            lost = exam.lost(s)
            for q in lost:
                slots.append((("student_errors", s["key"], q["qid"]), "学生错因"))
                slots.append((("questions", q["qid"], "纠正要点"), "纠正要点"))
            if lost:
                slots.append((("advice", s["key"]), "建议"))
    # 去重保序
    seen, out = set(), []
    for p, k in slots:
        if p not in seen:
            seen.add(p)
            out.append((p, k))
    return out


def get_path(d, path):
    for p in path:
        if not isinstance(d, dict) or p not in d:
            return None
        d = d[p]
    return d


def check_field(label, text, kind, errors):
    lim, bmax = LIMITS[kind]
    if not isinstance(text, str) or not text.strip():
        errors.append(f"{label}：未填写")
        return
    if text.count("**") % 2:
        errors.append(f"{label}：加粗标记 ** 不成对")
    n = text_len(text)
    if n > lim:
        errors.append(f"{label}：{n} 字，超过上限 {lim} 字 →「{text}」")
    if bold_count(text) > bmax:
        errors.append(f"{label}：加粗 {bold_count(text)} 处，上限 {bmax} 处")


def check_analysis(exam, analysis, rtype, scope, cls, student, conclusion_ids):
    errors = []
    for path, kind in required_slots(exam, rtype, scope, cls, student):
        val = get_path(analysis, path)
        label = "/".join(str(p) for p in path)
        if kind in ("错因", "纠正要点"):
            check_field(label, val, kind, errors)
        elif kind == "学生错因":
            if not isinstance(val, dict):
                errors.append(f"{label}：未填写（需要 类型/表现/依据）")
                continue
            if val.get("类型") not in ERROR_TYPES:
                errors.append(f"{label}/类型：必须是 {'/'.join(ERROR_TYPES)} 之一，当前为 {val.get('类型')!r}")
            check_field(label + "/表现", val.get("表现"), "表现", errors)
            if val.get("依据") not in BASIS:
                errors.append(f"{label}/依据：必须是 {'/'.join(BASIS)} 之一，当前为 {val.get('依据')!r}")
        elif kind == "建议":
            items = val if isinstance(val, list) else ([val] if isinstance(val, str) else [])
            items = [x for x in items if isinstance(x, str) and x.strip()]
            if not items:
                errors.append(f"{label}：未填写建议")
                continue
            if scope == "student" and len(items) > 3:
                errors.append(f"{label}：建议 {len(items)} 条，上限 3 条")
            for i, it in enumerate(items, 1):
                check_field(f"{label}[{i}]", it, "建议", errors)
                if not QNO_RE.search(it):
                    errors.append(f"{label}[{i}]：建议必须落到具体题号（如“订正第12题”）→「{it}」")
                for w in FLUFF:
                    if w in it:
                        errors.append(f"{label}[{i}]：含空话“{w}”，请改成具体动作 →「{it}」")
    # 可选：图表结论改写
    for cid, txt in (analysis.get("conclusions") or {}).items():
        if cid in conclusion_ids and txt:
            check_field(f"conclusions/{cid}", txt, "结论", errors)
    # 可选：补充分析
    scope_key = cls if scope == "class" else None
    keys = [scope_key] if scope_key else [s["key"] for s in scope_students(exam, cls, student)]
    for k in keys:
        for i, blk in enumerate((analysis.get("extra") or {}).get(k, []) or [], 1):
            lab = f"extra/{k}[{i}]"
            check_field(lab + "/标题", blk.get("标题"), "补充标题", errors)
            if blk.get("正文"):
                check_field(lab + "/正文", blk.get("正文"), "补充正文", errors)
            ch = blk.get("图表")
            if ch and len(ch.get("标签", [])) != len(ch.get("数值", [])):
                errors.append(f"{lab}/图表：标签与数值个数不一致")
            tb = blk.get("表格")
            if tb and any(len(r) != len(tb.get("表头", [])) for r in tb.get("行", [])):
                errors.append(f"{lab}/表格：行的列数与表头不一致")
    return errors


def check_items(label, items, kind, lo, hi, errors):
    items = items if isinstance(items, list) else ([items] if isinstance(items, str) else [])
    items = [x for x in items if isinstance(x, str) and x.strip()]
    if len(items) < lo:
        errors.append(f"{label}：未填写（{lo}–{hi} 条）" if not items else f"{label}：只有 {len(items)} 条，需要 {lo}–{hi} 条")
        return
    if len(items) > hi:
        errors.append(f"{label}：{len(items)} 条，上限 {hi} 条")
    for i, it in enumerate(items, 1):
        check_field(f"{label}[{i}]", it, kind, errors)
        for w in FLUFF:
            if w in it:
                errors.append(f"{label}[{i}]：含空话“{w}”，请改成具体动作 →「{it}」")


def check_common(analysis, scope_keys, errors):
    """补充分析与图表结论改写（按范围键）。"""
    for k in scope_keys:
        for i, blk in enumerate((analysis.get("extra") or {}).get(k, []) or [], 1):
            lab = f"extra/{k}[{i}]"
            check_field(lab + "/标题", blk.get("标题"), "补充标题", errors)
            if blk.get("正文"):
                check_field(lab + "/正文", blk.get("正文"), "补充正文", errors)
            ch = blk.get("图表")
            if ch and len(ch.get("标签", [])) != len(ch.get("数值", [])):
                errors.append(f"{lab}/图表：标签与数值个数不一致")
            tb = blk.get("表格")
            if tb and any(len(r) != len(tb.get("表头", [])) for r in tb.get("行", [])):
                errors.append(f"{lab}/表格：行的列数与表头不一致")
    for cid, txt in (analysis.get("conclusions") or {}).items():
        if txt and any(cid.startswith(k + "/") for k in scope_keys):
            check_field(f"conclusions/{cid}", txt, "结论", errors)


def paper_sections(exam):
    return [x for x in exam.sections if x != "未分类"] if exam.has_q else []


def paper_summary_parts(classes):
    """试卷分析报告摘要的段落：考情、班级（多班）、试卷、建议。"""
    return ["考情"] + (["班级"] if len(classes) >= 2 else []) + ["试卷", "建议"]


def paper_section_parts(classes):
    """试卷分析报告“本节小结”的键：考情（一）、班级（二，多班）、试卷（三）。"""
    return ["考情"] + (["班级"] if len(classes) >= 2 else []) + ["试卷"]


def check_paper(exam, analysis, classes):
    """试卷分析报告：摘要、本节小结、班级学情分析、班级提升、失分点（仅有逐题得分时）、改进计划。"""
    scope = "+".join(classes)
    pa = (analysis.get("试卷分析") or {}).get(scope) or {}
    lab0 = f"试卷分析/{scope}"
    errors = []
    summ = pa.get("摘要") or {}
    for k in paper_summary_parts(classes):
        check_field(f"{lab0}/摘要/{k}", summ.get(k), "摘要", errors)
    sm = pa.get("小结") or {}
    for k in paper_section_parts(classes):
        check_field(f"{lab0}/小结/{k}", sm.get(k), "小结", errors)
        for w in FLUFF:
            if w in (sm.get(k) or ""):
                errors.append(f"{lab0}/小结/{k}：含空话“{w}”，请改成具体判断")
    ca = pa.get("班级分析") or {}
    bt = pa.get("班级提升") or {}
    for c in classes:
        check_field(f"{lab0}/班级分析/{c}", ca.get(c), "班级分析", errors)
        check_items(f"{lab0}/班级提升/{c}", bt.get(c), "提升建议", 1, 3, errors)
    fl = pa.get("失分点") or {}
    if exam.has_q:
        for sec in paper_sections(exam):
            check_field(f"{lab0}/失分点/{sec}", fl.get(sec), "失分点", errors)
    else:
        filled = [k for k, v in fl.items() if isinstance(v, str) and v.strip()]
        if filled:
            errors.append(f"{lab0}/失分点：成绩表只有总分、没有逐题得分，不能写失分点（{'、'.join(filled)}），请删除")
    plan = pa.get("改进计划") or {}
    for part in PLAN_PARTS:
        check_items(f"{lab0}/改进计划/{part}", plan.get(part), "计划", 1, 3, errors)
    check_common(analysis, [scope], errors)
    return errors


def paper_skeleton(exam, analysis, classes):
    scope = "+".join(classes)
    pa = analysis.setdefault("试卷分析", {}).setdefault(scope, {})
    todo = 0
    for key, parts in (("摘要", paper_summary_parts(classes)), ("小结", paper_section_parts(classes))):
        node = pa.setdefault(key, {})
        for k in parts:
            if not node.get(k):
                node[k] = ""
                todo += 1
    ca = pa.setdefault("班级分析", {})
    bt = pa.setdefault("班级提升", {})
    for c in classes:
        if not ca.get(c):
            ca[c] = ""
            todo += 1
        if not bt.get(c):
            bt[c] = [""]
            todo += 1
    if exam.has_q:
        fl = pa.setdefault("失分点", {})
        for sec in paper_sections(exam):
            if not fl.get(sec):
                fl[sec] = ""
                todo += 1
    plan = pa.setdefault("改进计划", {})
    for part in PLAN_PARTS:
        if not plan.get(part):
            plan[part] = [""]
            todo += 1
    return todo


def summary_parts(exam, classes):
    """成绩分析报告摘要的句子：总体、班级（多班）、学科（多科）或题型（单科有逐题得分）、建议。"""
    parts = ["总体"]
    if len(classes) >= 2:
        parts.append("班级")
    if exam.has_subj and len(exam.subjects) >= 2:
        parts.append("学科")
    elif exam.has_q:
        parts.append("题型")
    return parts + ["建议"]


def section_parts(exam, classes):
    """成绩分析报告各节末尾“本节小结”的键：总体（二）、班级（三，多班）、学科或题型（四）、学生（五）。"""
    parts = ["总体"]
    if len(classes) >= 2:
        parts.append("班级")
    if exam.has_subj and len(exam.subjects) >= 2:
        parts.append("学科")
    elif exam.has_q:
        parts.append("题型")
    return parts + ["学生"]


def check_score(exam, analysis, classes):
    """成绩分析报告：摘要、学科点评（多科）、主要问题、教学建议。"""
    scope = "+".join(classes)
    sa = (analysis.get("成绩分析") or {}).get(scope) or {}
    lab0 = f"成绩分析/{scope}"
    errors = []
    summ = sa.get("摘要") or {}
    for k in summary_parts(exam, classes):
        check_field(f"{lab0}/摘要/{k}", summ.get(k), "摘要", errors)
    if exam.has_subj and len(exam.subjects) >= 2:
        cm = sa.get("学科点评") or {}
        for x in exam.subjects:
            check_field(f"{lab0}/学科点评/{x}", cm.get(x), "学科点评", errors)
    sm = sa.get("小结") or {}
    for k in section_parts(exam, classes):
        check_field(f"{lab0}/小结/{k}", sm.get(k), "小结", errors)
        for w in FLUFF:
            if w in (sm.get(k) or ""):
                errors.append(f"{lab0}/小结/{k}：含空话“{w}”，请改成具体判断")
    check_items(f"{lab0}/问题", sa.get("问题"), "问题", 2, 4, errors)
    check_items(f"{lab0}/建议", sa.get("建议"), "教学建议", 3, 5, errors)
    check_common(analysis, [scope], errors)
    return errors


def score_skeleton(exam, analysis, classes):
    scope = "+".join(classes)
    sa = analysis.setdefault("成绩分析", {}).setdefault(scope, {})
    todo = 0
    summ = sa.setdefault("摘要", {})
    for k in summary_parts(exam, classes):
        if not summ.get(k):
            summ[k] = ""
            todo += 1
    if exam.has_subj and len(exam.subjects) >= 2:
        cm = sa.setdefault("学科点评", {})
        for x in exam.subjects:
            if not cm.get(x):
                cm[x] = ""
                todo += 1
    sm = sa.setdefault("小结", {})
    for k in section_parts(exam, classes):
        if not sm.get(k):
            sm[k] = ""
            todo += 1
    for key, n in (("问题", 2), ("建议", 3)):
        if not sa.get(key):
            sa[key] = [""] * n
            todo += 1
    return todo


def cmd_skeleton(args):
    exam, analysis, _ = load_context(args)
    if args.type == "error" and not exam.has_q:
        raise ReportError(NO_ITEM_SCORES, 2)
    analysis.setdefault("exam_id", exam.exam_id)
    classes = split_classes(args.cls) or exam.classes()
    todo = (paper_skeleton(exam, analysis, classes) if args.type == "paper" else
            score_skeleton(exam, analysis, classes) if args.type == "score" else 0)
    for cls in (classes if args.type == "error" else []):
        for path, kind in required_slots(exam, args.type, args.scope, cls, args.student):
            cur = get_path(analysis, path)
            node = analysis
            for p in path[:-1]:
                node = node.setdefault(p, {})
            if kind == "学生错因":
                if not isinstance(cur, dict):
                    node[path[-1]] = {"类型": "", "表现": "", "依据": ""}
                    todo += 1
            elif kind == "建议":
                if not cur:
                    node[path[-1]] = [""]
                    todo += 1
            elif not cur:
                node[path[-1]] = ""
                todo += 1
    analysis.setdefault("conclusions", {})
    analysis.setdefault("extra", {})
    out = args.analysis or os.path.join(os.path.dirname(os.path.abspath(args.dataset)),
                                        f"{exam.exam_id}_分析.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2)
    print(f"已写入 {out}；新增待填 {todo} 处。")
    if args.type == "paper":
        print(f"填写位置：试卷分析/{'+'.join(classes)}。规则：摘要（{'、'.join(paper_summary_parts(classes))}）每段 ≤120 字；"
              f"本节小结（{'、'.join(paper_section_parts(classes))}）每段 ≤200 字，写这一节数据说明了什么、可能原因与影响；"
              "班级分析每班一段 ≤200 字；班级提升每班 1–3 条、改进计划每节 1–3 条，每条 ≤80 字，先写结论再写依据或做法；"
              "失分点每个题型 ≤60 字（只有逐题得分时才写）；不得使用空话；重点用 **…** 加粗。")
    elif args.type == "score":
        print(f"填写位置：成绩分析/{'+'.join(classes)}。规则：摘要（{'、'.join(summary_parts(exam, classes))}）；"
              f"摘要每句 ≤120 字；本节小结每节 ≤200 字（{'、'.join(section_parts(exam, classes))}：这一节数据说明了什么、"
              "可能原因与影响）；学科点评每科 ≤150 字（多科时，写表现、原因与做法）；主要问题 2–4 条、教学建议 3–5 条，"
              "每条 ≤100 字、先写结论再写依据或做法；不得使用空话；重点用 **…** 加粗。")
    else:
        print("填写规则：错因/表现 ≤20 字，纠正要点 ≤30 字，建议每条 ≤30 字且含题号；"
              f"错因类型取 {'/'.join(ERROR_TYPES)}；依据取 {'/'.join(BASIS)}；重点用 **…** 加粗。")


# ---------------------------------------------------------------- 图表（matplotlib）

class Charts:
    def __init__(self, font, workdir):
        import logging
        import matplotlib
        matplotlib.use("Agg")
        logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)  # 字体只有一种字重时的提示，不影响出图
        import matplotlib.pyplot as plt
        self.plt = plt
        plt.rcParams.update({
            "font.family": font, "font.size": 9, "axes.unicode_minus": False,
            "axes.edgecolor": AXIS, "axes.linewidth": 0.8, "axes.labelcolor": INK, "axes.labelsize": 8.5,
            "xtick.color": INK, "ytick.color": INK, "xtick.major.size": 3, "ytick.major.size": 3,
            "xtick.major.width": 0.8, "ytick.major.width": 0.8,
            "savefig.dpi": 220, "figure.dpi": 110, "legend.frameon": False, "legend.fontsize": 8.5,
        })
        self.dir = workdir
        self.n = 0
        self._memo = {}

    def _path(self, stem):
        self.n += 1
        return os.path.join(self.dir, f"{self.n:03d}_{stem}.png")

    def _fig(self, w_cm, h_cm):
        fig, ax = self.plt.subplots(figsize=(w_cm / 2.54, h_cm / 2.54))
        fig.patch.set_facecolor("white")
        return fig, ax

    def _save(self, fig, stem):
        p = self._path(stem)
        fig.savefig(p, bbox_inches="tight", pad_inches=0.05, facecolor="white")
        self.plt.close(fig)
        return p

    @staticmethod
    def _clean(ax, value_axis):
        """坐标轴：保留左、下两条轴线，数值轴方向画浅灰网格。"""
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        for s in ("left", "bottom"):
            ax.spines[s].set_color(AXIS)
        ax.grid(axis=value_axis, color=GRID, linewidth=0.6)
        ax.set_axisbelow(True)

    @staticmethod
    def _pct_axis(axis):
        from matplotlib.ticker import FuncFormatter
        axis.set_major_formatter(FuncFormatter(lambda v, _: f"{v * 100:.0f}%"))

    @staticmethod
    def _txt(col):
        return "white" if col in DARK_FILLS else INK

    # ---- 图表
    @memo
    def tiers(self, names, counts, w=8.4, h=4.6):
        fig, ax = self._fig(w, h)
        x = range(len(names))
        ax.bar(x, counts, width=0.56, color=TIER_RAMP[: len(names)] if len(names) <= 4 else BLUE,
               edgecolor="white", linewidth=1.2)
        top = max(counts + [1])
        for i, c in enumerate(counts):
            ax.text(i, c + top * 0.03, f"{c}", ha="center", va="bottom", color=INK, fontsize=8)
        ax.set_xticks(list(x), names)
        ax.set_ylim(0, top * 1.22)
        ax.yaxis.set_major_locator(self.plt.MaxNLocator(integer=True, nbins=4))
        ax.set_ylabel("人数")
        self._clean(ax, "y")
        return self._save(fig, "tiers")

    @memo
    def hbars(self, labels, values, compare=None, names=("本班", None), pct=True, w=8.4, h=None,
              color=BLUE, xmax=None, fmt=None, stem="hbar", colors=None, ref=None, ref_label=""):
        """横向条形；compare 不为空时为“本人/本班 vs 对照”分组条形；colors 为每根条的颜色；ref 为竖向参考线。"""
        n = len(labels)
        h = h or max(2.2, 0.8 * n * (1.6 if compare else 1) + 1.0)
        fig, ax = self._fig(w, h)
        ys = list(range(n))[::-1]
        bh = 0.36 if compare else 0.56
        fmt = fmt or ((lambda v: f"{v * 100:.1f}%") if pct else fmt_score)
        vmax = xmax or (1.0 if pct else max([v for v in values if v is not None] + [1]) * 1.15)
        off = bh / 2 + 0.03 if compare else 0
        vals = [v or 0 for v in values]
        if pct:  # 满格底框：0% 时也能看出是一根空槽
            tr = [y + off for y in ys] + ([y - off for y in ys] if compare else [])
            ax.barh(tr, [1.0] * len(tr), height=bh, color="none", edgecolor="#d0d0d0", linewidth=0.6, zorder=0.6)
        ax.barh([y + off for y in ys], vals, height=bh, color=colors or color, label=names[0], edgecolor="white")
        for y, v, raw in zip(ys, vals, values):
            ax.text(v + vmax * 0.015, y + off, fmt(raw) if raw is not None else "—", va="center",
                    fontsize=8, color=INK)
        if compare:
            cv = [v or 0 for v in compare]
            ax.barh([y - off for y in ys], cv, height=bh, color=CMP_GRAY, label=names[1], edgecolor="white")
            for y, v, raw in zip(ys, cv, compare):
                ax.text(v + vmax * 0.015, y - off, fmt(raw) if raw is not None else "—", va="center",
                        fontsize=8, color=INK2)
            ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, handlelength=1.0)
        if ref is not None:
            ax.axvline(ref, color=INK2, linewidth=0.9, linestyle=(0, (4, 3)))
            ax.text(ref, 1.0, f" {ref_label}", transform=ax.get_xaxis_transform(), ha="left", va="bottom",
                    fontsize=7.5, color=INK2)
        ax.set_yticks(ys, labels)
        ax.set_xlim(0, vmax * 1.16)
        if pct:
            self._pct_axis(ax.xaxis)
            ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
        else:
            ax.xaxis.set_major_locator(self.plt.MaxNLocator(integer=True, nbins=6))
        self._clean(ax, "x")
        return self._save(fig, stem)

    @memo
    def grouped_bars(self, cats, series, w=17.4, h=4.4, unit="人", colors=None, ylabel="人数"):
        """分组柱状图：cats 为横轴分类，series = [(名称, 数值列表)]，每组一个系列（如各班分档人数）。"""
        fig, ax = self._fig(w, h)
        n = len(series)
        width = 0.8 / max(n, 1)
        top = max([v for _, vals in series for v in vals] + [1])
        for i, (name, vals) in enumerate(series):
            xs = [x - 0.4 + width * (i + 0.5) for x in range(len(cats))]
            ax.bar(xs, vals, width=width * 0.9, color=(colors or SERIES)[i % len(colors or SERIES)], label=name,
                   edgecolor="white")
            for x, v in zip(xs, vals):
                ax.text(x, v + top * 0.02, f"{fmt_score(v)}", ha="center", va="bottom", fontsize=7.5, color=INK)
        ax.set_xticks(list(range(len(cats))), cats)
        ax.set_ylim(0, top * 1.22)
        ax.yaxis.set_major_locator(self.plt.MaxNLocator(integer=True, nbins=4))
        ax.set_ylabel(ylabel)
        ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=min(n, 6), handlelength=1.0)
        self._clean(ax, "y")
        return self._save(fig, "grouped")

    @memo
    def multi_hbars(self, labels, series, w=17.4):
        """多系列横向条形（得分率）：series = [(名称, 得分率列表)]，如各班题型得分率。"""
        n, m = len(labels), len(series)
        fig, ax = self._fig(w, max(2.4, 0.52 * n * m + 1.2))
        bh = 0.8 / max(m, 1)
        ys = list(range(n))[::-1]
        for i, (name, vals) in enumerate(series):
            yy = [y + 0.4 - bh * (i + 0.5) for y in ys]
            ax.barh(yy, [1.0] * n, height=bh * 0.9, color="none", edgecolor="#d0d0d0", linewidth=0.6, zorder=0.6)
            ax.barh(yy, [v or 0 for v in vals], height=bh * 0.9, color=SERIES[i % len(SERIES)], label=name,
                    edgecolor="white")
            for y, v in zip(yy, vals):
                ax.text((v or 0) + 0.015, y, fmt_pct(v), va="center", fontsize=7.5, color=INK)
        ax.set_yticks(ys, labels)
        ax.set_xlim(0, 1.16)
        self._pct_axis(ax.xaxis)
        ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
        ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=min(m, 6), handlelength=1.0)
        self._clean(ax, "x")
        return self._save(fig, "multi_hbars")

    @memo
    def question_rates(self, labels, rates, line, w=17.4, h=4.6):
        fig, ax = self._fig(w, h)
        x = list(range(len(labels)))
        cols = [CRIT if (r is not None and r < line) else BLUE for r in rates]
        ax.bar(x, [r or 0 for r in rates], width=0.62, color=cols, edgecolor="white", linewidth=1)
        ax.axhline(line, color=INK2, linewidth=0.9, linestyle=(0, (4, 3)))
        ax.text(len(x) - 0.5, line + 0.02, f"及格线 {line * 100:.0f}%", ha="right", va="bottom",
                fontsize=7.5, color=INK2)
        valid = [(r, i) for i, r in enumerate(rates) if r is not None]
        if valid:
            r, i = min(valid)
            ax.text(i, r + 0.02, f"{r * 100:.0f}%", ha="center", va="bottom", fontsize=7.5, color=CRIT)
        ax.set_xticks(x, labels, fontsize=7.5)
        ax.set_ylim(0, 1.1)
        self._pct_axis(ax.yaxis)
        ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
        from matplotlib.patches import Patch
        ax.legend(handles=[Patch(color=CRIT, label="低于及格线"), Patch(color=BLUE, label="其余题目")],
                  loc="lower right", bbox_to_anchor=(1.0, 1.0), ncol=2, handlelength=1.0)
        self._clean(ax, "y")
        ax.set_xlabel("题号")
        ax.set_ylabel("得分率")
        return self._save(fig, "qrates")

    @memo
    def grid(self, items, w=8.4):
        """逐题得分格：items = [(题号, 状态)]，状态 full/part/zero/miss。"""
        from matplotlib.patches import Patch, Rectangle
        colmap = {"full": GOOD, "part": WARN, "zero": CRIT, "miss": "#d0d0d0"}
        per = 8
        rows = (len(items) + per - 1) // per
        fig, ax = self._fig(w, 1.15 * rows + 1.3)
        for i, (no, st) in enumerate(items):
            r, c = divmod(i, per)
            ax.add_patch(Rectangle((c + 0.06, -r + 0.06), 0.88, 0.88, facecolor=colmap[st], edgecolor="white"))
            ax.text(c + 0.5, -r + 0.5, str(no), ha="center", va="center", fontsize=8,
                    color=INK if st in ("part", "miss") else "white", fontweight="bold")
        ax.set_xlim(0, per)
        ax.set_ylim(-rows + 1, 1)
        ax.set_aspect("equal")
        ax.axis("off")
        ax.legend(handles=[Patch(color=GOOD, label="满分"), Patch(color=WARN, label="部分得分"),
                           Patch(color=CRIT, label="零分")],
                  loc="upper center", bbox_to_anchor=(0.5, 0.0), ncol=3, handlelength=1.0)
        return self._save(fig, "grid")

    @memo
    def history(self, xlabels, series, w=17.4, h=4.4, colors=None, ylabel="比率"):
        fig, ax = self._fig(w, h)
        x = list(range(len(xlabels)))
        ends = []
        markers = ["o", "s", "^", "D", "v", "P", "X", "*"]
        for i, (name, vals) in enumerate(series.items()):
            c = colors[i] if colors else SERIES[i % len(SERIES)]
            ax.plot(x, vals, color=c, linewidth=1.6, marker=markers[i % len(markers)], markersize=4.5,
                    markeredgecolor="white", markeredgewidth=0.8, label=name)
            ends.append([vals[-1], vals[-1]])
        # 末端数值标签错开，避免几条线终点接近时重叠
        order = sorted(range(len(ends)), key=lambda i: ends[i][0])
        for a_, b_ in zip(order, order[1:]):
            if ends[b_][1] - ends[a_][1] < 0.075:
                ends[b_][1] = ends[a_][1] + 0.075
        for (v, y) in ends:
            ax.text(x[-1] + 0.08, y, f"{v * 100:.1f}%", va="center", fontsize=7.5, color=INK)
        ax.set_xticks(x, xlabels, fontsize=8)
        ax.set_xlim(-0.3, len(x) - 0.4)
        ax.set_ylim(0, 1.08)
        self._pct_axis(ax.yaxis)
        ax.set_ylabel(ylabel)
        ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=min(len(series), 8), handlelength=1.6)
        self._clean(ax, "y")
        return self._save(fig, "history")

    @memo
    def options(self, rows, w=17.4):
        """选择题选项分布：rows = [(标签, [(选项, 人数, 是否正确)])]，100% 堆叠。"""
        from matplotlib.patches import Patch
        n = len(rows)
        fig, ax = self._fig(w, 0.62 * n + 1.3)
        ys = list(range(n))[::-1]
        for y, (lab, segs) in zip(ys, rows):
            tot = sum(c for _, c, _ in segs) or 1
            left = 0
            for opt, c, ok in segs:
                share = c / tot
                col = GOOD if ok else ("#d0d0d0" if opt == "未答" else SERIOUS)
                ax.barh(y, share, left=left, height=0.58, color=col, edgecolor="white", linewidth=1.5)
                if share >= 0.09:
                    ax.text(left + share / 2, y, f"{opt} {c}", ha="center", va="center", fontsize=7.5,
                            color="white" if ok else INK)
                left += share
        ax.set_yticks(ys, [r[0] for r in rows])
        ax.set_xlim(0, 1)
        self._pct_axis(ax.xaxis)
        ax.set_xlabel("占作答人数的比例")
        ax.legend(handles=[Patch(color=GOOD, label="正确选项"), Patch(color=SERIOUS, label="错误选项")],
                  loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, handlelength=1.0)
        self._clean(ax, "x")
        return self._save(fig, "options")

    @memo
    def mini_stack(self, full_n, part_n, zero_n, w=7.2):
        fig, ax = self._fig(w, 1.25)
        tot = (full_n + part_n + zero_n) or 1
        left = 0
        for lab, c, col, tc in (("满分", full_n, GOOD, "white"), ("部分", part_n, WARN, INK),
                                ("零分", zero_n, CRIT, "white")):
            share = c / tot
            if c:
                ax.barh(0, share, left=left, height=0.62, color=col, edgecolor="white", linewidth=1.5)
                if share >= 0.16:
                    ax.text(left + share / 2, 0, f"{lab}{c}人", ha="center", va="center", fontsize=7.5, color=tc)
            left += share
        ax.set_xlim(0, 1)
        ax.axis("off")
        small = [f"{lab}{c}人" for lab, c in (("满分", full_n), ("部分", part_n), ("零分", zero_n))
                 if c and c / tot < 0.16]
        if small:
            ax.text(1, -0.55, "，".join(small), ha="right", va="top", fontsize=7, color=INK2)
        return self._save(fig, "mini_stack")

    @memo
    def bar_simple(self, labels, values, unit, w=17.4):
        fig, ax = self._fig(w, 5.0)
        x = list(range(len(labels)))
        vals = [float(v) for v in values]
        ax.bar(x, vals, width=0.56, color=BLUE, edgecolor="white")
        top = max(vals + [1])
        for i, v in enumerate(vals):
            txt = f"{v * 100:.1f}%" if unit == "%" and v <= 1 else f"{fmt_score(v)}{'' if unit == '%' else unit}"
            ax.text(i, v + top * 0.03, txt, ha="center", va="bottom", fontsize=8, color=INK)
        ax.set_xticks(x, labels)
        ax.set_ylim(0, min(top * 1.2, 1.12) if unit == "%" and top <= 1 else top * 1.2)
        if unit == "%" and top <= 1:
            self._pct_axis(ax.yaxis)
        self._clean(ax, "y")
        return self._save(fig, "extra")

    # ---- 成绩分析报告用图
    @memo
    def histogram(self, edges, counts, colors, vline=None, vlabel="", legend=(), w=17.4, h=4.6, marks=()):
        """分数段分布：edges 为分段边界，柱按所在分档着色，竖虚线标及格线；legend = [(名称, 颜色)]；
        marks = [(分数, 文字, 颜色)] 额外的竖线（如单人报告的本人总分）。"""
        from matplotlib.patches import Patch
        fig, ax = self._fig(w, h)
        mids = [(edges[i] + edges[i + 1]) / 2 for i in range(len(counts))]
        width = (edges[1] - edges[0]) * 0.86
        ax.bar(mids, counts, width=width, color=colors, edgecolor="white", linewidth=1)
        top = max(counts + [1])
        for x, c in zip(mids, counts):
            if c:
                ax.text(x, c + top * 0.02, str(c), ha="center", va="bottom", fontsize=7.5, color=INK)
        if vline is not None:
            ax.axvline(vline, color=INK2, linewidth=0.9, linestyle=(0, (4, 3)))
            ax.text(vline, top * 1.13, f" {vlabel}", ha="left", va="center", fontsize=7.5, color=INK2)
        for x, lab, col in marks:  # 标签放在柱顶数字和及格线标签上方，避免重叠
            ax.axvline(x, color=col, linewidth=1.6)
            ax.text(x, top * 1.27, f" {lab}", ha="left", va="center", fontsize=8, color=col, fontweight="bold")
        ax.set_xticks(edges, [fmt_score(x) for x in edges], fontsize=7.5)
        ax.set_xlim(edges[0], edges[-1])
        ax.set_ylim(0, top * (1.36 if marks else 1.22))
        ax.yaxis.set_major_locator(self.plt.MaxNLocator(integer=True, nbins=4))
        ax.set_xlabel("总分（分）")
        ax.set_ylabel("人数")
        if legend:
            ax.legend(handles=[Patch(color=c, label=n) for n, c in legend], loc="lower center",
                      bbox_to_anchor=(0.5, 1.04), ncol=len(legend), handlelength=1.0)
        self._clean(ax, "y")
        return self._save(fig, "hist")

    @memo
    def vbars(self, labels, values, colors, ref=None, ref_label="", pct=False, w=17.4, h=4.6, legend=(), ylabel=""):
        """竖向柱 + 数值标签；ref 为参考线（全体均分 / 及格线），虚线标出。"""
        from matplotlib.patches import Patch
        fig, ax = self._fig(w, h)
        x = list(range(len(labels)))
        vals = [v or 0 for v in values]
        ax.bar(x, vals, width=0.58, color=colors, edgecolor="white", linewidth=1)
        top = max(vals + [ref or 0, 1e-9])
        fmt = fmt_pct if pct else (lambda v: f"{v:.1f}")
        for i, (v, raw) in enumerate(zip(vals, values)):
            ax.text(i, v + top * 0.02, fmt(raw) if raw is not None else "—", ha="center", va="bottom",
                    fontsize=7.5, color=INK)
        if ref is not None:
            ax.axhline(ref, color=INK2, linewidth=0.9, linestyle=(0, (4, 3)))
            ax.text(1.01, ref, ref_label, transform=ax.get_yaxis_transform(), ha="left", va="center",
                    fontsize=7.5, color=INK2)
        ax.set_xticks(x, labels)
        ax.set_xlim(-0.6, len(x) - 0.4)
        ax.set_ylim(0, (1.12 if pct and top <= 1 else top * 1.18))
        if pct:
            self._pct_axis(ax.yaxis)
            ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
        if ylabel:
            ax.set_ylabel(ylabel)
        if legend:
            ax.legend(handles=[Patch(color=c, label=n) for n, c in legend], loc="lower right",
                      bbox_to_anchor=(1.0, 1.0), ncol=len(legend), handlelength=1.0)
        self._clean(ax, "y")
        return self._save(fig, "vbars")

    @memo
    def rate_pairs(self, cats, a, b, names=("及格率", "低分率"), w=17.4, h=4.6):
        """两种比率的分组柱（如 及格率 vs 低分率）。"""
        fig, ax = self._fig(w, h)
        x = list(range(len(cats)))
        bw = 0.36
        for off, vals, col, name in ((-bw / 2 - 0.01, a, BLUE, names[0]), (bw / 2 + 0.01, b, CRIT, names[1])):
            xs = [i + off for i in x]
            ax.bar(xs, [v or 0 for v in vals], width=bw, color=col, label=name, edgecolor="white")
            for xx, v in zip(xs, vals):
                ax.text(xx, (v or 0) + 0.015, fmt_pct(v), ha="center", va="bottom", fontsize=7, color=INK)
        ax.set_xticks(x, cats)
        ax.set_ylim(0, 1.12)
        self._pct_axis(ax.yaxis)
        ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
        ax.set_ylabel("比率")
        ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, handlelength=1.0)
        self._clean(ax, "y")
        return self._save(fig, "pairs")

    @memo
    def stacked(self, cats, names, matrix, colors, w=17.4, h=5.0):
        """分档人数堆叠柱：matrix[类][档] 人数，自下而上从低档到高档。"""
        fig, ax = self._fig(w, h)
        x = list(range(len(cats)))
        bottom = [0] * len(cats)
        tops = [sum(r) for r in matrix]
        top = max(tops + [1])
        for j, (name, col) in enumerate(zip(names, colors)):
            vals = [r[j] for r in matrix]
            ax.bar(x, vals, bottom=bottom, width=0.56, color=col, label=name, edgecolor="white", linewidth=1)
            for i, v in enumerate(vals):
                if v and v >= top * 0.06:
                    ax.text(i, bottom[i] + v / 2, str(v), ha="center", va="center", fontsize=7.5,
                            color=self._txt(col))
            bottom = [b_ + v for b_, v in zip(bottom, vals)]
        for i, t in enumerate(tops):
            ax.text(i, t + top * 0.02, f"{t}", ha="center", va="bottom", fontsize=7.5, color=INK2)
        ax.set_xticks(x, cats)
        ax.set_ylim(0, top * 1.16)
        ax.yaxis.set_major_locator(self.plt.MaxNLocator(integer=True, nbins=4))
        ax.set_ylabel("人数")
        ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=len(names), handlelength=1.0)
        self._clean(ax, "y")
        return self._save(fig, "stacked")

    @memo
    def pie(self, labels, values, colors, unit="人", w=12.0, h=5.4):
        """占比饼图：扇区内标百分比（不足 6% 的不标），图例写名称、数量与占比。"""
        fig, ax = self._fig(w, h)
        tot = sum(values) or 1
        nz = [(lab, v, c) for lab, v, c in zip(labels, values, colors) if v > 0]
        wedges, _t, auto = ax.pie([v for _, v, _ in nz], colors=[c for _, _, c in nz], startangle=90,
                                  counterclock=False, wedgeprops=dict(edgecolor="white", linewidth=1.2),
                                  autopct=lambda p: f"{p:.1f}%" if p >= 6 else "", pctdistance=0.7,
                                  textprops=dict(fontsize=8.5))
        for t, (_, _, c) in zip(auto, nz):
            t.set_color(self._txt(c))
        ax.legend(wedges, [f"{lab}  {fmt_score(v)}{unit}（{v / tot * 100:.1f}%）" for lab, v, _ in nz],
                  loc="center left", bbox_to_anchor=(1.0, 0.5), handlelength=1.0)
        ax.set_aspect("equal")
        return self._save(fig, "pie")

    @memo
    def boxplot(self, labels, data, lines=(), ylabel="总分（分）", w=17.4, h=5.0):
        """分布箱线图：箱为排在中间的一半学生（四分位区间），箱中横线为中位数，菱形为平均分，
        须线到 1.5 倍四分位距以内的最远值，圆点为离群值；lines = [(分数, 文字)] 横向参考线。"""
        from matplotlib.lines import Line2D
        from matplotlib.patches import Patch
        fig, ax = self._fig(w, h)
        ax.boxplot([list(d) for d in data], widths=0.5, patch_artist=True, whis=1.5, showmeans=True,
                   medianprops=dict(color=CRIT, linewidth=1.5),
                   meanprops=dict(marker="D", markerfacecolor="white", markeredgecolor=BLUE, markersize=4.5),
                   boxprops=dict(facecolor=TIER_RAMP5[0], edgecolor=BLUE, linewidth=1),
                   whiskerprops=dict(color=BLUE, linewidth=1), capprops=dict(color=BLUE, linewidth=1),
                   flierprops=dict(marker="o", markersize=3.5, markerfacecolor="white", markeredgecolor=MUTED))
        ax.set_xticks(list(range(1, len(labels) + 1)), labels)
        for v, lab in lines:
            ax.axhline(v, color=INK2, linewidth=0.9, linestyle=(0, (4, 3)))
            ax.text(1.01, v, lab, transform=ax.get_yaxis_transform(), ha="left", va="center", fontsize=7.5,
                    color=INK2)
        ax.set_ylabel(ylabel)
        ax.legend(handles=[Patch(facecolor=TIER_RAMP5[0], edgecolor=BLUE, label="中间一半学生（四分位区间）"),
                           Line2D([], [], color=CRIT, linewidth=1.5, label="中位数"),
                           Line2D([], [], marker="D", linestyle="", markerfacecolor="white", markeredgecolor=BLUE,
                                  label="平均分")],
                  loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, handlelength=1.4)
        self._clean(ax, "y")
        return self._save(fig, "box")

    @memo
    def group_rates(self, cats, series, ref=None, ref_label="", w=17.4, h=5.2, ylabel="得分率"):
        """分组柱（得分率）：横轴为 cats（如学科），每组 series 个系列（如各班）；ref 为虚线参考线（及格线）。"""
        fig, ax = self._fig(w, h)
        n = len(series)
        width = 0.8 / max(n, 1)
        nbar = len(cats) * n
        for i, (name, vals) in enumerate(series):
            xs = [x - 0.4 + width * (i + 0.5) for x in range(len(cats))]
            ax.bar(xs, [v or 0 for v in vals], width=width * 0.9, color=SERIES[i % len(SERIES)], label=name,
                   edgecolor="white", linewidth=0.6)
            if nbar <= 24:
                for x, v in zip(xs, vals):
                    ax.text(x, (v or 0) + 0.012, ("—" if v is None else (f"{v * 100:.1f}" if nbar <= 15
                                                                        else f"{v * 100:.0f}")),
                            ha="center", va="bottom", fontsize=6.8 if nbar > 10 else 7.5, color=INK)
        if ref is not None:
            ax.axhline(ref, color=INK2, linewidth=0.9, linestyle=(0, (4, 3)))
            ax.text(1.01, ref, ref_label, transform=ax.get_yaxis_transform(), ha="left", va="center",
                    fontsize=7.5, color=INK2)
        ax.set_xticks(list(range(len(cats))), cats)
        ax.set_ylim(0, 1.08)
        self._pct_axis(ax.yaxis)
        ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
        ax.set_ylabel(ylabel)
        ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=min(n, 8), handlelength=1.0)
        self._clean(ax, "y")
        return self._save(fig, "group_rates")

    @memo
    def stack100(self, cats, names, matrix, colors, w=17.4):
        """横向百分比堆叠条：每行一个分类（如学科），各段为各档人数占比，自左向右从低档到高档。"""
        from matplotlib.patches import Patch
        n = len(cats)
        fig, ax = self._fig(w, 0.68 * n + 1.7)
        ys = list(range(n))[::-1]
        for y, row in zip(ys, matrix):
            tot = sum(row) or 1
            left = 0
            for v, col in zip(row, colors):
                share = v / tot
                if v:
                    ax.barh(y, share, left=left, height=0.6, color=col, edgecolor="white", linewidth=1)
                if share >= 0.06:
                    ax.text(left + share / 2, y, f"{share * 100:.0f}%", ha="center", va="center", fontsize=7.5,
                            color=self._txt(col))
                left += share
        ax.set_yticks(ys, cats)
        ax.set_xlim(0, 1)
        self._pct_axis(ax.xaxis)
        ax.set_xlabel("占参考人数的比例")
        ax.legend(handles=[Patch(color=c, label=nm) for nm, c in zip(names, colors)], loc="lower center",
                  bbox_to_anchor=(0.5, 1.0), ncol=len(names), handlelength=1.0)
        self._clean(ax, "x")
        return self._save(fig, "stack100")

    @memo
    def rank_scatter(self, pts, n, notes=(), w=10.0, h=8.4):
        """名次对比散点：pts = [(上次名次, 本次名次)]；虚线上为名次不变，虚线上方为进步（名次 1 在上）；
        notes = [(上次, 本次, 文字)] 标注变化最大的几名学生。"""
        fig, ax = self._fig(w, h)
        up = [(a, b) for a, b in pts if b < a]
        dn = [(a, b) for a, b in pts if b > a]
        same = [(a, b) for a, b in pts if a == b]
        ax.plot([1, n], [1, n], color=MUTED, linewidth=0.9, linestyle=(0, (4, 3)), zorder=1)
        for grp, col, mk, lab in ((up, BLUE, "o", f"进步 {len(up)} 人"), (dn, CRIT, "v", f"退步 {len(dn)} 人"),
                                  (same, MUTED, "s", f"不变 {len(same)} 人")):
            if grp:
                ax.scatter([a for a, _ in grp], [b for _, b in grp], s=16, color=col, marker=mk, label=lab,
                           edgecolors="white", linewidths=0.4, zorder=2)
        for a, b, t in notes:
            ax.annotate(t, (a, b), xytext=(4, 3), textcoords="offset points", fontsize=7.5, color=INK)
        ax.set_xlim(0, n + 1)
        ax.set_ylim(n + 1, 0)
        ax.set_xlabel("上次名次")
        ax.set_ylabel("本次名次")
        ax.grid(color=GRID, linewidth=0.6)
        ax.set_axisbelow(True)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        ax.legend(loc="lower left", handlelength=1.0, frameon=True, edgecolor="#d0d0d0")
        return self._save(fig, "rank_scatter")

    @memo
    def quality_scatter(self, pts, secs, w=13.0, h=7.6):
        """逐题难度—区分度散点：pts = [(题号, 难度, 区分度, 题型序号)]，按题型着色；
        虚线为难度 0.4 / 0.7 与区分度 0.2 / 0.4 的分界。"""
        fig, ax = self._fig(w, h)
        for j, sec in enumerate(secs):
            g = [p for p in pts if p[3] == j]
            if g:
                ax.scatter([p[1] for p in g], [p[2] for p in g], s=26, color=SERIES[j % len(SERIES)], label=sec,
                           edgecolors="white", linewidths=0.5, zorder=3)
        groups = []  # 位置几乎重合的点合并成一个标签（如“5、10”），避免题号叠在一起
        for lab, x, y, _ in pts:
            g = next((g for g in groups if abs(g[1] - x) < 0.025 and abs(g[2] - y) < 0.025), None)
            if g:
                g[0].append(lab)
            else:
                groups.append([[lab], x, y])
        for labs, x, y in groups:
            ax.annotate("、".join(labs), (x, y), xytext=(3, 2), textcoords="offset points", fontsize=7, color=INK2)
        for x in (0.4, 0.7):
            ax.axvline(x, color=MUTED, linewidth=0.8, linestyle=(0, (4, 3)))
        for y in (0.2, 0.4):
            ax.axhline(y, color=MUTED, linewidth=0.8, linestyle=(0, (4, 3)))
        ys = [p[2] for p in pts] or [0]
        ax.set_xlim(0, 1.02)
        ax.set_ylim(min(-0.05, min(ys) - 0.05), max(0.8, max(ys) + 0.05))
        ax.set_xlabel("难度（该题得分率，越靠右越容易）")
        ax.set_ylabel("区分度")
        ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=min(len(secs), 6), handlelength=1.0)
        self._clean(ax, "y")
        ax.grid(axis="x", color=GRID, linewidth=0.6)
        return self._save(fig, "quality")


# ---------------------------------------------------------------- Word 版式（python-docx）：学校公文样式

LAYOUT_W = 17.4  # 组装逻辑里图、表的宽度按这个版心宽度给出；版式类按自己的版心等比缩放
BODY_PT = 12  # 正文小四


def end_punct(text):
    """结论句补句号，接在后面的解读才读得通。"""
    t = (text or "").rstrip()
    return t if not t or re.sub(r"\*\*", "", t)[-1:] in "。！？；：" else t + "。"


def table_font(ncol, font=None):
    """表格字号：列少用五号，列多逐级缩小；成绩单这类长表最小 9 磅。"""
    size = 10.5 if ncol <= 5 else (10 if ncol <= 7 else (9.5 if ncol <= 9 else 9))
    return min(size, 9) if font is not None and font < 8.5 else size


KEEP_ROWS = 20  # 不超过这么多行的表整表不拆页（表题、表头、表身同页）；更长的表跨页时重复表头


def pair_text(nos, concls):
    """并排两图的结论合成一段：“从图1看，……；从图2看，……。”"""
    parts = [f"从图{n}看，{re.sub(r'[。；]+$', '', c)}" for n, c in zip(nos, concls) if c]
    return "；".join(parts) + "。" if parts else ""


class Doc:
    """Word 报告：A4，左右边距 2.5 cm；正文宋体小四、1.5 倍行距、首行缩进 2 字；标题黑体，按 1 / 1.1 /（1）编号；
    表题在表上、图题在图下，各有一行“数据来源”；表格全框线、表头灰底。"""
    PAGE_W = 16.0

    def __init__(self, font, header_text, layout=None):
        from docx import Document
        from docx.shared import Cm, Pt
        from docx.oxml.ns import qn
        self.Cm, self.Pt, self.qn = Cm, Pt, qn
        self.font = font
        self.n_h1, self.n_h2, self.n_h3 = None, 0, 0
        self.n_fig = self.n_tab = 0
        # 版面调整（第二遍排版时由 refine_layout 填写）：scale = {("f", 图号): 缩放比例}，
        # float = {("f"|"t", 编号)}：这张图 / 表被挤到下一页时，把它的分析段挪到它前面，填补上一页的留白
        self.layout = layout or {"scale": {}, "float": set(), "compact": set(), "split": set()}
        self.doc = Document()
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.left_margin = sec.right_margin = Cm(2.5)
        sec.top_margin, sec.bottom_margin = Cm(2.5), Cm(2.3)
        sec.header_distance, sec.footer_distance = Cm(1.4), Cm(1.2)
        st = self.doc.styles["Normal"]
        st.font.name = LATIN
        st.font.size = Pt(BODY_PT)
        st.element.rPr.rFonts.set(qn("w:eastAsia"), SONG)
        st.paragraph_format.space_after = Pt(0)
        st.paragraph_format.space_before = Pt(0)
        st.paragraph_format.line_spacing = 1.0
        # 页眉：报告名居中、下划细线；页脚：页码居中
        self._header_footer(sec.header, sec.footer, header_text)

    def _header_footer(self, header, footer, header_text):
        hp = header.paragraphs[0]
        hp.alignment = 1
        self.run(hp, header_text, 9, color=INK2)
        self._border(hp, "bottom", RULE, 4)
        fp = footer.paragraphs[0]
        fp.alignment = 1
        self._field(fp, "PAGE")

    # ---- 底层工具
    def _el(self, tag, **attrs):
        from docx.oxml import OxmlElement
        e = OxmlElement(tag)
        for k, v in attrs.items():
            e.set(self.qn(k), str(v))
        return e

    def _field(self, p, code):
        fld = self._el("w:fldSimple", **{"w:instr": code})
        r = self._el("w:r")
        rpr = self._el("w:rPr")
        rpr.append(self._el("w:rFonts", **{"w:ascii": LATIN, "w:hAnsi": LATIN}))
        rpr.append(self._el("w:sz", **{"w:val": 21}))
        r.append(rpr)
        t = self._el("w:t")
        t.text = "1"
        r.append(t)
        fld.append(r)
        p._p.append(fld)

    def _border(self, p, side, color, sz):
        ppr = p._p.get_or_add_pPr()
        bdr = ppr.find(self.qn("w:pBdr"))
        if bdr is None:
            bdr = self._el("w:pBdr")
            ppr.append(bdr)
        bdr.append(self._el(f"w:{side}", **{"w:val": "single", "w:sz": sz, "w:space": 4, "w:color": color[1:]}))

    def _w(self, cm):
        """组装逻辑给的宽度（按 17.4 cm 版心）→ 本版心宽度。"""
        return min(self.PAGE_W, cm * self.PAGE_W / LAYOUT_W)

    def run(self, p, text, size=BODY_PT, bold=False, color=INK, shade=None, face=SONG):
        from docx.shared import Pt, RGBColor
        r = p.add_run(text)
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.color.rgb = RGBColor.from_string(color[1:])
        r.font.name = LATIN
        r._element.get_or_add_rPr().get_or_add_rFonts().set(self.qn("w:eastAsia"), face)
        if shade:
            r._element.get_or_add_rPr().append(
                self._el("w:shd", **{"w:val": "clear", "w:color": "auto", "w:fill": shade[1:]}))
        return r

    def rich(self, p, text, size=BODY_PT, color=INK, bold_color=INK, face=SONG):
        """解析 **加粗**。"""
        for i, part in enumerate(re.split(r"\*\*", text or "")):
            if part:
                self.run(p, part, size, bold=(i % 2 == 1), color=bold_color if i % 2 else color, face=face)

    def chip(self, p, text, size=10.5):
        """标签：公文里用方头括号，不用彩色底。"""
        self.run(p, f"【{text}】", size, bold=True)

    def pic(self, p, path, width=None, height=None):
        r = p.add_run()
        r.add_picture(path, width=self.Cm(self._w(width)) if width else None,
                      height=self.Cm(height) if height else None)
        return r

    def para(self, space_before=0, space_after=0, align=None, keep=False):
        p = self.doc.add_paragraph()
        pf = p.paragraph_format
        pf.space_before, pf.space_after = self.Pt(space_before), self.Pt(space_after)
        if align is not None:
            p.alignment = align
        pf.keep_with_next = keep
        return p

    def _cell_shade(self, cell, color):
        tcpr = cell._tc.get_or_add_tcPr()
        tcpr.append(self._el("w:shd", **{"w:val": "clear", "w:color": "auto", "w:fill": color[1:]}))

    def _cell_margins(self, cell, top=40, bottom=40, left=80, right=80):
        tcpr = cell._tc.get_or_add_tcPr()
        mar = self._el("w:tcMar")
        for side, v in (("top", top), ("bottom", bottom), ("start", left), ("end", right),
                        ("left", left), ("right", right)):
            mar.append(self._el(f"w:{side}", **{"w:w": v, "w:type": "dxa"}))
        tcpr.append(mar)

    def _valign(self, cell, v="center"):
        cell._tc.get_or_add_tcPr().append(self._el("w:vAlign", **{"w:val": v}))

    def _table(self, rows, widths, grid=False):
        """widths 已是本版心的 cm。grid=True 为全框线（公文表格），否则无框线（并排图的排版表）。"""
        from docx.enum.table import WD_TABLE_ALIGNMENT
        t = self.doc.add_table(rows=rows, cols=len(widths))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        tblpr = t._tbl.tblPr
        tblpr.append(self._el("w:tblLayout", **{"w:type": "fixed"}))
        bd = self._el("w:tblBorders")
        for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
            bd.append(self._el(f"w:{side}", **({"w:val": "single", "w:sz": 4, "w:space": 0, "w:color": RULE[1:]}
                                                if grid else {"w:val": "nil"})))
        tblpr.append(bd)
        for row in t.rows:
            for c, w in zip(row.cells, widths):
                c.width = self.Cm(w)
        grid_el = t._tbl.tblGrid
        for gc, w in zip(grid_el.findall(self.qn("w:gridCol")), widths):
            gc.set(self.qn("w:w"), str(int(w * 567)))
        return t

    def _row_flags(self, row, header=False):
        trpr = row._tr.get_or_add_trPr()
        trpr.append(self._el("w:cantSplit"))
        if header:
            trpr.append(self._el("w:tblHeader"))

    def _fit_widths(self, widths):
        tot = sum(widths) or 1
        k = self.PAGE_W / LAYOUT_W
        if tot * k > self.PAGE_W:
            k = self.PAGE_W / tot
        return [w * k for w in widths]

    def _style(self, p, name):
        try:
            p.style = self.doc.styles[name]
        except KeyError:
            pass

    # ---- 标题
    def _head(self, text, size, before, after, style):
        p = self.para(space_before=before, space_after=after, keep=True)
        self._style(p, style)
        pf = p.paragraph_format
        pf.space_before, pf.space_after, pf.keep_with_next = self.Pt(before), self.Pt(after), True
        pf.line_spacing = 1.5
        p.alignment = 0
        self.run(p, text, size, bold=True, face=HEI)
        return p

    def title(self, title, subtitle):
        """不带封面的报告（错题分析、试卷分析）：首页居中标题与考试信息。"""
        p = self.para(space_before=6, space_after=6, align=1)
        self.run(p, title, 22, bold=True, face=HEI)
        p = self.para(space_after=14, align=1)
        self.run(p, subtitle, 12, color=INK2, face=KAI)

    def heading(self, idx, title):
        self.n_h1, self.n_h2, self.n_h3 = idx, 0, 0
        self._head(f"{idx}　{title}", 16, 14, 6, "Heading 1")

    def plain_heading(self, title):
        """不编号的一级标题（报告摘要、附录）。"""
        self.n_h1, self.n_h2, self.n_h3 = None, 0, 0
        self._head(title, 16, 14, 6, "Heading 1")

    def subhead(self, text):
        self.n_h2 += 1
        self.n_h3 = 0
        num = f"{self.n_h1}.{self.n_h2}　" if self.n_h1 else ""
        return self._head(num + text, 14, 10, 4, "Heading 2")

    def subhead3(self, text):
        self.n_h3 += 1
        return self._head(f"（{self.n_h3}）{text}", 12, 8, 3, "Heading 3")

    # ---- 正文
    def body(self, text="", keep=False, indent=True, color=INK, face=SONG):
        """正文段：宋体小四、1.5 倍行距、两端对齐、首行缩进 2 字。"""
        p = self.para(keep=keep)
        pf = p.paragraph_format
        pf.line_spacing = 1.5
        if indent:
            pf.first_line_indent = self.Pt(BODY_PT * 2)
        p.alignment = 3
        if text:
            self.rich(p, text, BODY_PT, color, face=face)
        return p

    def item(self, no, text):
        """编号条目：1．……（标题已用 1 / 1.1 /（1），条目用 1．，层次不混）"""
        p = self.body()
        self.run(p, f"{no}．")
        self.rich(p, text)
        return p

    def lead(self, text):
        """节导读：标题下的总括段。标题与它同页；它本身不再和后面的图表绑在一起，避免整串挪页留下大片空白。"""
        self.body(text)

    def analysis(self, concl=None, items=None, keep=False, prefix=""):
        """图表下的分析段：先写结论，再接带加粗小标题的解读要点，合成一段正文。
        prefix 用于分析段挪到图表前面时（“如图3所示，”）。"""
        items = [x for x in (items or []) if x]
        if not concl and not items:
            return None
        p = self.body(keep=keep)
        if prefix:
            self.run(p, prefix)
        if concl:
            self.rich(p, end_punct(concl))
        for it in items:
            if isinstance(it, (tuple, list)):
                self.run(p, f"{it[0]}：", bold=True)
                self.rich(p, it[1])
            else:
                self.rich(p, it)
        return p



    def placeholder(self, text):
        self.body("注：" + text, color=INK2, face=KAI)

    def signature(self, lines):
        """文末落款：右对齐，与正文最后一段同页（不单独落到下一页页首）。"""
        if self.doc.paragraphs:
            self.doc.paragraphs[-1].paragraph_format.keep_with_next = True
        for i, ln in enumerate(lines):
            p = self.para(space_before=24 if i == 0 else 2, align=2, keep=i < len(lines) - 1)
            p.paragraph_format.line_spacing = 1.5
            self.run(p, ln)

    def kpis(self, tiles, caption=None, source=None, concl=None, explain=None):
        """核心指标表：tiles = [(图标, 数值, 指标名)]，排成“指标 | 数值 | 指标 | 数值”四列。"""
        pairs = [(lab, val) for _, val, lab in tiles]
        if len(pairs) % 2:
            pairs.append(("—", "—"))
        rows = [[a[0], a[1], b[0], b[1]] for a, b in zip(pairs[0::2], pairs[1::2])]
        self.ctable(caption, ["指标", "数值", "指标", "数值"], rows, [4.35] * 4, source=source,
                    after=[("concl", concl), ("exp", explain)])

    def kpi_rows(self, rows, explain=None, caption=None, source=None, concl=None):
        self.kpis([t for r in rows for t in r], caption, source, concl, explain)

    def cover(self, school, title, lines, foot):
        """封面（单独一页，不带页眉页脚）：学校、报告名、信息行、编制部门。"""
        sec = self.doc.sections[0]
        sec.different_first_page_header_footer = True
        p = self.para(space_before=150, align=1)
        if school:
            self.run(p, school, 26, bold=True, face=HEI)
        p = self.para(space_before=14, space_after=0, align=1)
        self.run(p, title, 22, bold=True, face=HEI)
        for i, ln in enumerate(lines):
            p = self.para(space_before=70 if i == 0 else 6, align=1)
            self.run(p, ln, 14, face=KAI)
        for i, ln in enumerate(foot):
            p = self.para(space_before=150 if i == 0 else 6, align=1)
            self.run(p, ln, 14, face=KAI)
        self.page_break()

    # ---- 图与表
    def table_caption(self, text):
        self.n_tab += 1
        p = self.para(space_before=6, space_after=4, align=1, keep=True)
        self.run(p, f"表{self.n_tab}　{text}", 10.5, bold=True)

    def source(self, text, keep=False):
        p = self.para(space_before=2, space_after=6, keep=keep)
        self.run(p, text, 9, color=SRC)

    def _after(self, items):
        concl = next((t for k, t in items if k == "concl" and t), None)
        exp = next((t for k, t in items if k == "exp" and t), None)
        self.analysis(concl, exp)

    def figure(self, path, caption, source, concl, width=None, explain=None):
        """图在上、图题在下（图n），再一行数据来源，然后是分析段。图、图题、数据来源不拆页；分析段可以接到下一页。
        版面调整：图可按 layout.scale 缩小；被挤到下一页时分析段挪到图前（layout.float）。"""
        n = self.n_fig + 1
        key = ("f", n)
        moved = key in self.layout["float"]
        if moved:
            self.analysis(concl, explain, prefix=f"如图{n}所示，")
        p = self.para(space_before=4, align=1, keep=True)
        self.pic(p, path, width=(width or LAYOUT_W) * self.layout["scale"].get(key, 1.0))
        self.n_fig = n
        p = self.para(space_before=2, space_after=1 if source else 6, align=1, keep=bool(source))
        self.run(p, f"图{n}　{caption}", 10.5)
        if source:
            self.source(source)
        if not moved:
            self.analysis(concl, explain)

    def chart(self, title, path, concl, width=None, source=None, explain=None):
        self.figure(path, title, source, concl, width=width, explain=explain)

    def chart_pair(self, left, right, source=None):
        """并排两张图（各有图题），两句结论合成一段放在下面。left/right = (标题, 图片, 结论)"""
        half = self.PAGE_W / 2
        key = ("f", self.n_fig + 1)
        sc = self.layout["scale"].get(key, 1.0)
        text = pair_text([self.n_fig + 1, self.n_fig + 2], [left[2], right[2]])
        if key in self.layout["float"] and text:
            self.analysis(text)
        t = self._table(1, [half, half])
        nos = []
        for cell, (title, path, concl) in zip(t.rows[0].cells, (left, right)):
            self._cell_margins(cell, 0, 0, 40, 40)
            self._valign(cell, "bottom")
            p = cell.paragraphs[0]
            p.alignment = 1
            p.paragraph_format.keep_with_next = True
            r = p.add_run()
            r.add_picture(path, width=self.Cm((half - 0.3) * sc))
            self.n_fig += 1
            nos.append(self.n_fig)
            p2 = cell.add_paragraph()
            p2.alignment = 1
            p2.paragraph_format.space_before = self.Pt(3)
            self.run(p2, f"图{self.n_fig}　{title}", 10.5)
        self._row_flags(t.rows[0])
        if source:
            for c in t.rows[0].cells:
                for pp in c.paragraphs:
                    pp.paragraph_format.keep_with_next = True
            self.source(source)
        else:
            self.para(space_after=3)
        if text and key not in self.layout["float"]:
            self.analysis(text)

    def kp_tiles(self, tiles, concl, caption="本人薄弱知识点"):
        """薄弱知识点表：tiles = [(状态, 得分/满分, 知识点, 涉及题目与班级得分率)]。"""
        rows = [[name, val, sub] for _, val, name, sub in tiles]
        self.ctable(caption, ["知识点", "本人得分 / 满分", "涉及题目"], rows, [6.4, 3.8, 7.2],
                    align=["left", "center", "left"], after=[("concl", concl)])

    def ctable(self, caption, headers, rows, widths, source=None, after=None, **kw):
        """带表题的表：表题、表头、表身同页（见 table）；数据来源紧跟表格；分析段在表后。
        这张表被挤到下一页时（layout.float），分析段挪到表题前面，填补上一页的留白。"""
        n = self.n_tab + 1
        after = [(k, x) for k, x in (after or []) if x]
        moved = ("t", n) in self.layout["float"] and after
        if moved:
            concl = next((t for k, t in after if k == "concl"), None)
            exp = next((t for k, t in after if k == "exp"), None)
            self.analysis(concl, exp, prefix=f"如表{n}所示，")
        if caption:
            self.table_caption(caption)
        if ("t", n) in self.layout["split"]:  # 长表被整表挤到下一页：改为跨页续排（表题、表头和前两行同页，续页重复表头）
            kw["keep_together"] = False
        return self.table(headers, rows, widths, source=source, after=None if moved else after,
                          compact=("t", n) in self.layout["compact"], **kw)

    def table(self, headers, rows, widths, font=None, align=None, bold_first=False, keep_together=None, source=None,
              after=None, compact=False):
        """表格。不超过 KEEP_ROWS 行的表整表不拆页；更长的表跨页时重复表头，且表头至少带两行表身，
        表题不会单独留在上一页。"""
        if keep_together is None:
            keep_together = len(rows) <= KEEP_ROWS
        size = table_font(len(headers), font)
        if compact:  # 紧凑排版：字号小一号（不小于 8.5 磅）、单元格上下留白减半
            size = max(8.5, size - 1)
        pad = 10 if compact else 25
        widths = self._fit_widths(widths)
        t = self._table(len(rows) + 1, widths, grid=True)
        align = align or ["center"] * len(headers)
        amap = {"left": 0, "center": 1, "right": 2}

        from docx.enum.text import WD_LINE_SPACING

        def fmt(p):  # 表内固定行距（字号的 1.3 倍）：中文字体单倍行距偏高，表格会被撑大
            pf = p.paragraph_format
            pf.space_before = pf.space_after = self.Pt(0)
            pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
            pf.line_spacing = self.Pt(round(size * 1.3, 1))
        for c, h in zip(t.rows[0].cells, headers):
            self._cell_shade(c, TABLE_HEAD)
            self._cell_margins(c, pad, pad)
            self._valign(c)
            p = c.paragraphs[0]
            fmt(p)
            p.alignment = 1
            self.run(p, h, size, bold=True)
        self._row_flags(t.rows[0], header=True)
        for ri, row in enumerate(rows, 1):
            tr = t.rows[ri]
            self._row_flags(tr)
            for ci, (c, v) in enumerate(zip(tr.cells, row)):
                heat = isinstance(v, tuple) and len(v) == 3
                if heat:  # (文本, 文字色, 底色)：色块表
                    self._cell_shade(c, v[2])
                elif ri % 2 == 0:
                    self._cell_shade(c, ZEBRA)
                self._cell_margins(c, pad, pad)
                self._valign(c)
                p = c.paragraphs[0]
                fmt(p)
                p.alignment = amap[align[ci]]
                if heat:
                    self.run(p, v[0], size, color=v[1])
                elif isinstance(v, tuple):  # (文本, 颜色)：加粗
                    self.run(p, v[0], size, bold=True, color=v[1])
                else:
                    self.rich(p, str(v), size)
                    if bold_first and ci == 0:
                        for r in p.runs:
                            r.font.bold = True
        # 短表整表不拆页（除最后一行外每行与下段同页）；长表至少让表头和前两行表身同页
        for row in (t.rows[:-1] if keep_together else t.rows[:3]):
            for c in row.cells:
                for pp in c.paragraphs:
                    pp.paragraph_format.keep_with_next = True
        after = [(k, x) for k, x in (after or []) if x]
        if source:  # 数据来源行紧跟表格最后一行
            for c in t.rows[-1].cells:
                for pp in c.paragraphs:
                    pp.paragraph_format.keep_with_next = True
            self.source(source)
        if after:
            self._after(after)
        elif not source:
            self.para(space_after=4)
        return t

    def card(self, head, body, left_pic, right_lines):
        """逐题卡片（全框线表格）。head = dict(title, sub, right, badges, body_extra)；body = (image|text, 值)；
        right_lines = [段落构造函数]。整卡不跨页。"""
        from docx.enum.text import WD_TAB_ALIGNMENT
        lw = self.PAGE_W * 0.42
        t = self._table(3, [lw, self.PAGE_W - lw], grid=True)
        h = t.cell(0, 0).merge(t.cell(0, 1))
        b = t.cell(1, 0).merge(t.cell(1, 1))
        self._cell_shade(h, CARD_HEAD)
        if left_pic is None:  # 没有左侧小图（单人版）：下栏合并为一整行
            rc = t.cell(2, 0).merge(t.cell(2, 1))
            for c in (h, b, rc):
                self._cell_margins(c, 60, 60, 110, 110)
        else:
            for c in (h, b, t.cell(2, 0), t.cell(2, 1)):
                self._cell_margins(c, 60, 60, 110, 110)
            self._valign(t.cell(2, 0))
            self._valign(t.cell(2, 1), "center")
        # 卡头
        p = h.paragraphs[0]
        p.paragraph_format.tab_stops.add_tab_stop(self.Cm(self.PAGE_W - 0.45), WD_TAB_ALIGNMENT.RIGHT)
        self.run(p, head["title"], 11, bold=True, face=HEI)
        self.run(p, "　" + head["sub"], 10, color=INK2)
        for txt, col in head.get("badges", []):
            self.run(p, f"　【{txt}】", 10, bold=True, color=col)
        self.run(p, "\t", 10)
        self.rich(p, head["right"], 10.5)
        # 题目
        p = b.paragraphs[0]
        kind, val = body
        if kind == "image":
            # 限高 7cm，避免高图把整张卡片撑出一页（卡片设为不跨页）
            from PIL import Image
            with Image.open(val) as im:
                iw, ih = im.size
            r = p.add_run()
            r.add_picture(val, width=self.Cm(min(self.PAGE_W - 0.6, 7.0 * iw / ih if ih else 15.0)))
        else:
            self.run(p, val or "（题目档案无原文）", 10.5)
        for extra in head.get("body_extra", []):
            p2 = b.add_paragraph()
            p2.paragraph_format.space_before = self.Pt(2)
            self.rich(p2, extra, 10.5)
        # 下栏
        if left_pic is not None:
            lp = t.cell(2, 0).paragraphs[0]
            lp.alignment = 1
            r = lp.add_run()
            r.add_picture(left_pic, width=self.Cm(lw - 0.4))
            rc = t.cell(2, 1)
        first = True
        for build in right_lines:
            p = rc.paragraphs[0] if first else rc.add_paragraph()
            p.paragraph_format.line_spacing = 1.25
            if not first:
                p.paragraph_format.space_before = self.Pt(3)
            first = False
            build(p)
        for row in t.rows:
            self._row_flags(row)
        for row in t.rows[:-1]:
            for c in row.cells:
                for pp in c.paragraphs:
                    pp.paragraph_format.keep_with_next = True
        self.para(space_after=6)

    def notes(self, lines):
        """文末“说明”：小五号，悬挂编号；整块不拆页。"""
        p = self.para(space_before=14, space_after=3, keep=True)
        self.run(p, "说明", 10.5, bold=True, face=HEI)
        for i, ln in enumerate(lines, 1):
            p = self.para(space_after=1, keep=i < min(2, len(lines)))
            pf = p.paragraph_format
            pf.left_indent, pf.first_line_indent = self.Pt(16), self.Pt(-16)
            pf.line_spacing = 1.2
            self.run(p, f"{i}．{ln}", 9, color=INK2)

    def page_break(self):
        from docx.enum.text import WD_BREAK
        self.para().add_run().add_break(WD_BREAK.PAGE)

    def save(self, path):
        self.doc.save(path)


# ---------------------------------------------------------------- HTML 版式（与 Doc 同一套接口）

class _HP:
    """HTML 段落：先收集行内片段，保存时再输出。"""

    def __init__(self, cls="", style=""):
        self.parts, self.cls, self.style = [], cls, style

    def html(self):
        c = f' class="{self.cls}"' if self.cls else ""
        s = f' style="{self.style}"' if self.style else ""
        return f'<p{c}{s}>{"".join(self.parts)}</p>'


class HtmlDoc:
    """HTML 报告：与 Doc 同一套接口，由同一段组装逻辑驱动，内容、顺序、图表与 Word/PDF 一致。
    自包含单文件（图片内嵌），屏幕上自适应宽度，打印为 A4；区块标题与其后第一块内容绑定，不会孤立在页尾。"""
    PAGE_W = 16.0
    BASE_PT = BODY_PT

    def __init__(self, font, header_text, layout=None):
        self.font, self.header_text = font, header_text
        self.layout = layout or {"scale": {}, "float": set(), "compact": set(), "split": set()}  # 版面调整，见 Doc
        self.blocks, self._keep, self._uris = [], None, {}
        self.n_h1, self.n_h2, self.n_h3 = None, 0, 0
        self.n_fig = self.n_tab = 0
        self.has_cover = False

    # ---- 底层
    @staticmethod
    def _e(t):
        return html.escape(str(t), quote=True).replace("  ", "&nbsp;&nbsp;")

    def _rem(self, pt):
        return f"{pt / self.BASE_PT:.3f}rem"

    def _pct(self, cm, of=None):
        return f"{min(100.0, cm / (of or LAYOUT_W) * 100):.2f}%"

    def _uri(self, path):
        if path not in self._uris:
            ext = os.path.splitext(path)[1].lower().lstrip(".")
            mime = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}.get(ext, "image/png")
            with open(path, "rb") as f:
                self._uris[path] = f"data:{mime};base64," + base64.b64encode(f.read()).decode("ascii")
        return self._uris[path]

    def _img(self, path, style="", cls=""):
        c = f' class="{cls}"' if cls else ""
        return f'<img{c} src="{self._uri(path)}" style="{style}" alt="">'

    def _span(self, text, size=None, bold=False, color=INK, shade=None, face=None):
        st = []
        if size and abs(size - BODY_PT) > 1e-9:
            st.append(f"font-size:{self._rem(size)}")
        if bold:
            st.append("font-weight:700")
        if color != INK:
            st.append(f"color:{color}")
        if shade:
            st.append(f"background:{shade}")
        if face == HEI:
            st.append("font-family:var(--hei)")
        elif face == KAI:
            st.append("font-family:var(--kai)")
        return f'<span style="{";".join(st)}">{self._e(text)}</span>' if st else self._e(text)

    def _rich(self, text, size=None, color=INK, bold_color=INK, face=None):
        return "".join(self._span(part, size, bold=(i % 2 == 1), color=bold_color if i % 2 else color, face=face)
                       for i, part in enumerate(re.split(r"\*\*", text or "")) if part)

    def _add(self, block):
        if self._keep is not None:
            self._keep.append(block)
            # 以长表格收尾的标题组不整组锁定（整组放不下会整体移页、留大片空白），靠"标题后不分页"绑住表头
            flow = isinstance(block, str) and block.startswith('<div class="tbl">')  # 短表（tbl-keep）不算
            self.blocks.append(("keep-t" if flow else "keep", self._keep))
            self._keep = None
        else:
            self.blocks.append(block)

    def _add_text(self, block):
        """正文段：挂起的标题不和它包成不拆页的整块（长段落整块放不下会整体挪页、留下空白），
        标题靠 break-after:avoid 与正文开头同页。"""
        if self._keep:
            self.blocks.extend(self._keep)
            self._keep = None
        self.blocks.append(block)

    def _flush(self):
        """把挂起的标题类块单独收成一组（标题与导读同页，但不再和后面的图表绑在一起）。"""
        if self._keep:
            self.blocks.append(("keep", self._keep))
            self._keep = None

    def _hold(self, block):
        """标题类块：先挂起，和下一块内容包进同一个不拆页的容器。"""
        if self._keep is None:
            self._keep = []
        self._keep.append(block)

    # ---- 与 Doc 相同的接口
    def run(self, p, text, size=BODY_PT, bold=False, color=INK, shade=None, face=SONG):
        p.parts.append(self._span(text, size, bold, color, shade, face))

    def rich(self, p, text, size=BODY_PT, color=INK, bold_color=INK, face=SONG):
        p.parts.append(self._rich(text, size, color, bold_color, face))

    def chip(self, p, text, size=10.5):
        p.parts.append(self._span(f"【{text}】", size, bold=True))

    def pic(self, p, path, width=None, height=None):
        if height:
            p.parts.append(self._img(path, f"height:{height * 28.3465 / self.BASE_PT:.3f}rem"))
        else:
            p.parts.append(self._img(path, f"width:{self._pct(width or LAYOUT_W)}", "fig-img"))

    def para(self, space_before=0, space_after=0, align=None, keep=False):
        st = []
        if space_before:
            st.append(f"margin-top:{self._rem(space_before)}")
        if space_after:
            st.append(f"margin-bottom:{self._rem(space_after)}")
        if align is not None:
            st.append("text-align:" + {0: "left", 1: "center", 2: "right", 3: "justify"}[align])
        p = _HP(style=";".join(st))
        (self._hold if keep else self._add)(p)
        return p

    # ---- 标题
    def title(self, title, subtitle):
        self._add(f'<header><div class="running">{self._e(self.header_text)}</div>'
                  f'<h1 class="doc-title">{self._e(title)}</h1><div class="doc-sub">{self._e(subtitle)}</div></header>')

    def heading(self, idx, title):
        self.n_h1, self.n_h2, self.n_h3 = idx, 0, 0
        self._hold(f'<h2 class="sec">{idx}　{self._e(title)}</h2>')

    def plain_heading(self, title):
        self.n_h1, self.n_h2, self.n_h3 = None, 0, 0
        self._hold(f'<h2 class="sec">{self._e(title)}</h2>')

    def subhead(self, text):
        self.n_h2 += 1
        self.n_h3 = 0
        num = f"{self.n_h1}.{self.n_h2}　" if self.n_h1 else ""
        self._hold(f'<h3 class="sub">{num}{self._e(text)}</h3>')

    def subhead3(self, text):
        self.n_h3 += 1
        self._hold(f'<h4 class="sub3">（{self.n_h3}）{self._e(text)}</h4>')

    # ---- 正文
    def _body_html(self, inner, cls="body"):
        return f'<p class="{cls}">{inner}</p>'

    def body(self, text="", keep=False, indent=True, color=INK, face=SONG):
        p = _HP(cls="body" if indent else "body ni")
        if text:
            self.rich(p, text, BODY_PT, color, face=face)
        (self._hold if keep else self._add_text)(p)
        return p

    def item(self, no, text):
        p = self.body()
        p.parts.append(f"{no}．" + self._rich(text))
        return p

    def lead(self, text):
        self.body(text, keep=True)
        self._flush()

    def _analysis_inner(self, concl, items):
        out = self._rich(end_punct(concl)) if concl else ""
        for it in items:
            if isinstance(it, (tuple, list)):
                out += f"<b>{self._e(it[0])}：</b>" + self._rich(it[1])
            else:
                out += self._rich(it)
        return out

    def analysis(self, concl=None, items=None, keep=False, prefix=""):
        items = [x for x in (items or []) if x]
        if not concl and not items:
            return None
        blk = f'<p class="body">{self._e(prefix)}{self._analysis_inner(concl, items)}</p>'
        (self._hold if keep else self._add_text)(blk)
        return blk



    def placeholder(self, text):
        self._add(f'<p class="body note">注：{self._e(text)}</p>')

    def signature(self, lines):
        self._add('<div class="sign">' + "".join(f"<p>{self._e(x)}</p>" for x in lines) + "</div>")

    def kpis(self, tiles, caption=None, source=None, concl=None, explain=None):
        pairs = [(lab, val) for _, val, lab in tiles]
        if len(pairs) % 2:
            pairs.append(("—", "—"))
        rows = [[a[0], a[1], b[0], b[1]] for a, b in zip(pairs[0::2], pairs[1::2])]
        self.ctable(caption, ["指标", "数值", "指标", "数值"], rows, [4.35] * 4, source=source,
                    after=[("concl", concl), ("exp", explain)])

    def kpi_rows(self, rows, explain=None, caption=None, source=None, concl=None):
        self.kpis([t for r in rows for t in r], caption, source, concl, explain)

    def cover(self, school, title, lines, foot):
        self.has_cover = True
        sch = f'<div class="cv-s">{self._e(school)}</div>' if school else ""
        body = "".join(f'<p>{self._e(x)}</p>' for x in lines)
        ft = "".join(f'<p>{self._e(x)}</p>' for x in foot)
        self._add(f'<section class="cover">{sch}<h1 class="cv-t">{self._e(title)}</h1>'
                  f'<div class="cv-l">{body}</div><div class="cv-f">{ft}</div></section>')

    # ---- 图与表
    def table_caption(self, text):
        self.n_tab += 1
        self._hold(f'<div class="tcap">表{self.n_tab}　{self._e(text)}</div>')

    def source(self, text, keep=False):
        self._add(f'<p class="src">{self._e(text)}</p>')

    def _after(self, items):
        concl = next((t for k, t in items if k == "concl" and t), None)
        exp = next((t for k, t in items if k == "exp" and t), None)
        self.analysis(concl, exp)

    def figure(self, path, caption, source, concl, width=None, explain=None):
        n = self.n_fig + 1
        key = ("f", n)
        moved = key in self.layout["float"]
        if moved:
            self.analysis(concl, explain, prefix=f"如图{n}所示，")
        self.n_fig = n
        w = f"width:{self._pct((width or LAYOUT_W) * self.layout['scale'].get(key, 1.0))}"
        src = f'<p class="src">{self._e(source)}</p>' if source else ""
        self._add(f'<figure class="fig"><div class="fig-s">{self._img(path, w)}</div>'
                  f'<figcaption class="fcap">图{n}　{self._e(caption)}</figcaption>{src}</figure>')
        if not moved:
            self.analysis(concl, explain)

    def chart(self, title, path, concl, width=None, source=None, explain=None):
        self.figure(path, title, source, concl, width=width, explain=explain)

    def chart_pair(self, left, right, source=None):
        key = ("f", self.n_fig + 1)
        sc = self.layout["scale"].get(key, 1.0)
        text = pair_text([self.n_fig + 1, self.n_fig + 2], [left[2], right[2]])
        moved = key in self.layout["float"] and text
        if moved:
            self.analysis(text)
        figs = []
        for title, path, _ in (left, right):
            self.n_fig += 1
            figs.append(f'<figure class="fig">{self._img(path, f"width:{sc * 100:.0f}%")}'
                        f'<figcaption class="fcap">图{self.n_fig}　{self._e(title)}</figcaption></figure>')
        src = f'<p class="src">{self._e(source)}</p>' if source else ""
        self._add(f'<div class="pair-w"><div class="pair">{"".join(figs)}</div>{src}</div>')
        if text and not moved:
            self.analysis(text)

    def kp_tiles(self, tiles, concl, caption="本人薄弱知识点"):
        rows = [[name, val, sub] for _, val, name, sub in tiles]
        self.ctable(caption, ["知识点", "本人得分 / 满分", "涉及题目"], rows, [6.4, 3.8, 7.2],
                    align=["left", "center", "left"], after=[("concl", concl)])

    def ctable(self, caption, headers, rows, widths, source=None, after=None, **kw):
        n = self.n_tab + 1
        after = [(k, x) for k, x in (after or []) if x]
        moved = ("t", n) in self.layout["float"] and after
        if moved:
            concl = next((t for k, t in after if k == "concl"), None)
            exp = next((t for k, t in after if k == "exp"), None)
            self.analysis(concl, exp, prefix=f"如表{n}所示，")
        if caption:
            self.table_caption(caption)
        if ("t", n) in self.layout["split"]:
            kw["keep_together"] = False
        self.table(headers, rows, widths, source=source, after=None if moved else after,
                   compact=("t", n) in self.layout["compact"], **kw)

    def table(self, headers, rows, widths, font=None, align=None, bold_first=False, keep_together=None, source=None,
              after=None, compact=False):
        if keep_together is None:
            keep_together = len(rows) <= KEEP_ROWS
        size = table_font(len(headers), font)
        if compact:
            size = max(8.5, size - 1)
        align = align or ["center"] * len(headers)
        tot = sum(widths) or 1
        cols = "".join(f'<col style="width:{w / tot * 100:.2f}%">' for w in widths)
        head = "".join(f"<th>{self._e(h)}</th>" for h in headers)
        body = []
        for row in rows:
            tds = []
            for ci, v in enumerate(row):
                bg = ""
                if isinstance(v, tuple) and len(v) == 3:  # 色块表
                    inner, bg = self._span(v[0], color=v[1]), f";background:{v[2]}"
                elif isinstance(v, tuple):
                    inner = self._span(v[0], bold=True, color=v[1])
                elif bold_first and ci == 0:
                    inner = self._span(str(v).replace("**", ""), bold=True)
                else:
                    inner = self._rich(str(v))
                tds.append(f'<td style="text-align:{align[ci]}{bg}">{inner}</td>')
            body.append("<tr>" + "".join(tds) + "</tr>")
        wide = (' class="wide cmp"' if compact else ' class="wide"') if len(headers) >= 6 else (' class="cmp"' if compact else "")
        tcls = "tbl tbl-keep" if keep_together else "tbl"
        src = f'<p class="src">{self._e(source)}</p>' if source else ""
        self._add(f'<div class="{tcls}"><table{wide} style="font-size:{self._rem(size)}"><colgroup>{cols}</colgroup>'
                  f'<thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table>{src}</div>')
        self._after([(k, x) for k, x in (after or []) if x])

    def card(self, head, body, left_pic, right_lines):
        badges = "".join(f'<span class="bd" style="color:{col}">【{self._e(t)}】</span>'
                         for t, col in head.get("badges", []))
        h = (f'<div class="card-h"><span class="t">{self._e(head["title"])}</span>'
             f'<span class="s">{self._e(head["sub"])}</span>{badges}'
             f'<span class="r">{self._rich(head["right"])}</span></div>')
        kind, val = body
        if kind == "image":
            from PIL import Image
            with Image.open(val) as im:
                iw, ih = im.size
            b = self._img(val, f"width:{self._pct(min(self.PAGE_W - 0.6, 7.0 * iw / ih if ih else 15.0), self.PAGE_W)}")
        else:
            b = f"<p>{self._e(val or '（题目档案无原文）')}</p>"
        b += "".join(f'<p class="extra">{self._rich(x)}</p>' for x in head.get("body_extra", []))
        lines = []
        for build in right_lines:
            p = _HP()
            build(p)
            lines.append(p.html())
        left = f'<div class="l">{self._img(left_pic)}</div>' if left_pic is not None else ""
        self._add(f'<div class="card">{h}<div class="card-b">{b}</div><div class="card-f">'
                  f'{left}<div class="rr">{"".join(lines)}</div></div></div>')

    def notes(self, lines):
        items = "".join(f"<li>{self._e(x)}</li>" for x in lines)
        self._add(f'<footer class="notes"><div class="nt">说明</div><ol>{items}</ol></footer>')

    def page_break(self):
        self._add('<div class="pb"></div>')

    def _render(self, b):
        if isinstance(b, tuple):
            cls = "keep keep-t" if b[0] == "keep-t" else "keep"
            return f'<div class="{cls}">' + "".join(self._render(x) for x in b[1]) + "</div>"
        return b.html() if isinstance(b, _HP) else b

    def save(self, path):
        if self._keep:
            self.blocks.append(("keep", self._keep))
            self._keep = None
        body = "\n".join(self._render(b) for b in self.blocks)
        head_css = self.header_text.replace("\\", "\\\\").replace('"', '\\"')
        css = (HTML_CSS.replace("__FONT__", self.font).replace("__HEADER__", head_css)
               + (HTML_CSS_COVER if self.has_cover else ""))
        doc = (f'<!doctype html>\n<html lang="zh-CN">\n<head>\n<meta charset="utf-8">\n'
               f'<meta name="viewport" content="width=device-width, initial-scale=1">\n'
               f'<title>{self._e(self.header_text)}</title>\n<style>{css}</style>\n</head>\n'
               f'<body>\n<main class="page">\n{body}\n</main>\n</body>\n</html>\n')
        with open(path, "w", encoding="utf-8") as f:
            f.write(doc)


HTML_CSS = """
:root{--ink:#1a1a1a;--ink2:#404040;--src:#6e6e6e;--rule:#808080;--th:#d9d9d9;--zebra:#f2f2f2;--bg:#e8e8e5;
--song:"Times New Roman","宋体","SimSun","Songti SC","STSong","Noto Serif CJK SC","Source Han Serif SC","思源宋体","__FONT__",serif;
--hei:"Times New Roman","黑体","SimHei","Heiti SC","STHeiti","Noto Sans CJK SC","Source Han Sans SC","Microsoft YaHei","__FONT__",sans-serif;
--kai:"Times New Roman","楷体","KaiTi","STKaiti","Kaiti SC","AR PL UKai CN",var(--song)}
*{box-sizing:border-box}
html{font-size:16px;background:var(--bg)}
body{margin:0;background:var(--bg);color:var(--ink);line-height:1.5;font-family:var(--song);
-webkit-print-color-adjust:exact;print-color-adjust:exact}
.page{max-width:820px;margin:24px auto;padding:56px 64px 40px;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.12)}
@media screen and (max-width:700px){.page{margin:0;padding:22px 16px}.fig-s>img{min-width:34rem;max-width:none}}
p{margin:0}
img{max-width:100%}
.running{text-align:center;color:var(--ink2);font-size:.75rem;border-bottom:1px solid var(--rule);padding-bottom:4px;margin-bottom:22px}
.doc-title{font-family:var(--hei);font-size:1.833rem;font-weight:700;text-align:center;margin:.3rem 0 .4rem;line-height:1.35}
.doc-sub{font-family:var(--kai);text-align:center;color:var(--ink2);margin-bottom:1.2rem}
h2.sec{font-family:var(--hei);font-size:1.333rem;font-weight:700;margin:1.2rem 0 .5rem;line-height:1.5}
h3.sub{font-family:var(--hei);font-size:1.167rem;font-weight:700;margin:.85rem 0 .35rem;line-height:1.5}
h4.sub3{font-family:var(--hei);font-size:1rem;font-weight:700;margin:.65rem 0 .25rem;line-height:1.5}
p.body{text-indent:2em;text-align:justify;line-height:1.8}
p.body.ni{text-indent:0}
p.note{font-family:var(--kai);color:var(--ink2)}
.tcap{text-align:center;font-weight:700;font-size:.875rem;margin:.5rem 0 .3rem}
.fcap{text-align:center;font-size:.875rem;margin:.25rem 0 .1rem}
.src{color:var(--src);font-size:.75rem;margin:.15rem 0 .45rem;line-height:1.4;text-align:left}
.tbl{overflow-x:auto;margin:0}
table{border-collapse:collapse;width:100%;table-layout:fixed}
table.wide{min-width:36rem}
th,td{border:1px solid var(--rule);padding:.06rem .35rem;vertical-align:middle;overflow-wrap:anywhere;line-height:1.3}
th{background:var(--th);font-weight:700;text-align:center}
tbody tr:nth-child(even) td{background:var(--zebra)}
table.cmp th,table.cmp td{padding-top:0;padding-bottom:0}
.fig{margin:.6rem 0 0;text-align:center}
.fig img{display:block;margin:0 auto;height:auto}
.fig-s{overflow-x:auto}
.pair{display:flex;gap:.6rem;align-items:flex-end}
.pair>.fig{flex:1 1 0;min-width:0;margin:.4rem 0 0}
@media screen and (max-width:700px){.pair{flex-direction:column;align-items:stretch}}
.cover{text-align:center;padding:5rem 0 4rem}
.cv-s{font-family:var(--hei);font-weight:700;font-size:2.167rem}
.cv-t{font-family:var(--hei);font-weight:700;font-size:1.833rem;margin:.8rem 0 0}
.cv-l{margin-top:4rem}
.cv-l p,.cv-f p{font-family:var(--kai);font-size:1.167rem;margin:.35rem 0}
.cv-f{margin-top:7rem}
.card{border:1px solid var(--rule);margin:.5rem 0 .8rem}
.card-h{display:flex;flex-wrap:wrap;align-items:baseline;gap:.15rem .6rem;background:var(--zebra);padding:.3rem .65rem;border-bottom:1px solid var(--rule)}
.card-h .t{font-family:var(--hei);font-weight:700}
.card-h .s{font-size:.833rem;color:var(--ink2)}
.card-h .bd{font-size:.833rem;font-weight:700}
.card-h .r{margin-left:auto;font-size:.875rem}
.card-b{padding:.35rem .65rem;border-bottom:1px solid var(--rule);font-size:.875rem}
.card-b img{display:block;height:auto}
.card-b .extra{margin-top:.2rem}
.card-f{display:flex;flex-wrap:wrap;font-size:.875rem}
.card-f .l{flex:0 0 42%;padding:.35rem .65rem;border-right:1px solid var(--rule);display:flex;align-items:center}
.card-f .l img{width:100%}
.card-f .rr{flex:1 1 15rem;padding:.35rem .65rem;display:flex;flex-direction:column;justify-content:center;gap:.25rem;line-height:1.6}
@media screen and (max-width:700px){.card-f .l{flex-basis:100%;border-right:0;border-bottom:1px solid var(--rule)}}
.sign{text-align:right;margin-top:1.6rem;line-height:1.8}
.notes{margin-top:1.4rem;font-size:.75rem;color:var(--ink2)}
.notes .nt{font-family:var(--hei);font-weight:700;font-size:.875rem;color:var(--ink);margin-bottom:.15rem}
.notes ol{margin:0;padding-left:1.4rem}
.notes li{margin:.05rem 0}
.pb{break-after:page;page-break-after:always}
@page{size:A4;margin:25mm 25mm 23mm;
@top-center{content:"__HEADER__";font-family:var(--song);font-size:9pt;color:#404040;vertical-align:bottom;padding-bottom:2mm;border-bottom:.5pt solid #808080}
@bottom-center{content:counter(page);font-size:10.5pt}}
@media print{
html,body{background:#fff;font-size:12pt}
.page{max-width:none;margin:0;padding:0;box-shadow:none}
.running{display:none}
.tbl{overflow:visible}
table.wide{min-width:0}
.keep,.card,.fig,.pair-w,tr,.tbl-keep,.sign{break-inside:avoid;page-break-inside:avoid}
.notes .nt{break-after:avoid;page-break-after:avoid}
.keep.keep-t{break-inside:auto;page-break-inside:auto}
h2.sec,h3.sub,h4.sub3,.tcap{break-after:avoid;page-break-after:avoid}
tbody tr:nth-child(-n+2),.sign{break-before:avoid;page-break-before:avoid}
p.body{orphans:2;widows:2}
thead{display:table-header-group}
.card-f .l{flex-basis:42%}
}
"""

HTML_CSS_COVER = """
@page:first{@top-center{content:none;border:0}@bottom-center{content:none}}
@media print{.cover{padding:55mm 0 0;min-height:235mm;break-after:page;page-break-after:always}.cv-f{margin-top:60mm}}
"""


# ---------------------------------------------------------------- 报告组装

class Builder:
    def __init__(self, exam, analysis, history, charts, word_font):
        self.e, self.a, self.history, self.c, self.font = exam, analysis, history, charts, word_font
        self.used_conclusions = {}
        self.D = Doc  # 版式类：Doc（Word/PDF）或 HtmlDoc（HTML），两者接口相同
        self.layout = None  # 当前这份报告的版面调整（cmd_render 第二遍排版时设置）

    # ---- 通用
    def concl(self, scope_key, cid, default):
        key = f"{scope_key}/{cid}"
        self.used_conclusions[key] = default
        txt = (self.a.get("conclusions") or {}).get(key)
        return txt or default

    def meta_line(self, cls, who=None):
        m = self.e.meta
        parts = [m.get("subject") or self.e.cfg.get("科目") or "", m.get("name") or self.e.exam_id,
                 "" if cls == "未分班" else cls]
        if who:
            parts.append(who)
        if m.get("date"):
            parts.append(m["date"])
        parts.append(f"满分 {fmt_score(self.e.full)} 分")
        return " · ".join(p for p in parts if p)

    def header_text(self, kind):
        return f"{self.e.meta.get('name') or self.e.exam_id} · {kind}"

    def src(self, n):
        return f"数据来源：{self.e.meta.get('name') or self.e.exam_id}成绩（{n} 人）"

    def notes_lines(self, studs, extra=None, source_note=None):
        e, cfg = self.e, self.e.cfg
        b = cfg["分数段"]
        if e.abs_bounds:
            tiers = "、".join(f"{n} [{fmt_score(float(b[i]))}, {fmt_score(float(b[i + 1]))}{']' if i == len(b) - 2 else ')'}"
                             for i, n in enumerate(e.tier_names()))
        else:
            tiers = "、".join(f"{n} [{b[i] * 100:.0f}%, {b[i + 1] * 100:.0f}%{']' if i == len(b) - 2 else ')'}"
                             for i, n in enumerate(e.tier_names()))
        lines = [
            f"数据来源：{os.path.basename(e.dataset_path)}（{source_note or f'{len(studs)} 人'}）",
            "；".join(f"{k} {fmt_line(e.line(k))} 分（{e.frac(k) * 100:.0f}%）" for k in ("低分线", "及格线", "良好线"))
            + f"；优秀线 {fmt_score(e.excel_line)} 分（{e.excel_line / e.full * 100:.0f}%）；分档：{tiers}",
            "得分率 = 得分之和 ÷（满分 × 有效人数）；平均分保留 1 位小数，比率保留 1 位小数。",
        ]
        if not e.has_q:
            lines.append("成绩表只有总分、没有逐题得分：题型与逐题相关内容不作分析。")
        if extra:
            lines += extra
        clss = {s["class"] for s in studs}
        absent = [a for a in e.absent if a["class"] in clss]
        if absent:
            lines.append(f"缺考 {len(absent)} 人（不计入统计）：" + "、".join(a["name"] for a in absent))
        miss = [f"{s['name']}（{'、'.join(str(q['no']) for q in e.missing(s))}题）" for s in studs if e.missing(s)]
        if miss:
            lines.append("得分缺失、未计入统计：" + "；".join(miss))
        flags = [f"{s['name']}（{s['flag']}）" for s in studs if s.get("flag")]
        lines.append("待确认：" + ("；".join(flags) if flags else "无"))
        return lines

    def kpi_class(self, ov, absent_n=0):
        tiles = [(None, str(ov["人数"]), "参考人数")]
        if absent_n:
            tiles.append((None, str(absent_n), "缺考"))
        return tiles + [(None, fmt_score(round(ov["平均分"], 1)), "平均分"),
                        (None, fmt_score(ov["最高分"]), "最高分"),
                        (None, fmt_score(ov["最低分"]), "最低分"),
                        (None, fmt_pct(ov["及格率"]), "及格率"),
                        (None, fmt_pct(ov["优秀率"]), "优秀率")]

    def tiers_chart(self, cls, ov, w=8.4):
        names = self.e.tier_names()
        cnt = ov["分档人数"]
        big = max(range(len(cnt)), key=lambda i: cnt[i])
        default = f"**{names[big]}**档人数最多；{names[0]} **{cnt[0]}** 人"
        return ("学生分档人数", self.c.tiers(names, cnt, w=w), self.concl(cls, "分档", default))

    def section_chart(self, scope_key, rates, compare=None, names=("本班", None), w=8.4):
        secs = [s for s in rates if rates[s] is not None]
        vals = [rates[s] for s in secs]
        cmpv = [compare[s] for s in secs] if compare else None
        if compare:
            diffs = [(vals[i] - (cmpv[i] or 0), secs[i]) for i in range(len(secs))]
            d, s = min(diffs)
            default = (f"**{s}**比班级平均低 **{abs(d) * 100:.1f}** 个百分点" if d < -1e-9
                       else "各题型得分率都**不低于班级平均**")
        else:
            lo = min(range(len(vals)), key=lambda i: vals[i])
            hi = max(range(len(vals)), key=lambda i: vals[i])
            default = (f"**{secs[lo]}**得分率最低，比{secs[hi]}低 {abs(vals[hi] - vals[lo]) * 100:.1f} 个百分点"
                       if lo != hi else f"题型得分率 **{vals[0] * 100:.1f}%**")
            if text_len(default) > 30:
                default = f"**{secs[lo]}**得分率最低"
        path = self.c.hbars(secs, vals, compare=cmpv, names=names, w=w, stem="sections")
        return ("各题型得分率", path, self.concl(scope_key, "题型", default))

    def overview_pair(self, d, cls, ov, studs):
        """学生分档 + 题型得分率；没有题目档案（只有“未分类”）时题型位置给占位说明。"""
        if self.e.has_q and [x for x in self.e.sections if x != "未分类"]:
            d.chart_pair(self.tiers_chart(cls, ov), self.section_chart(cls, self.e.sec_rates(studs)),
                         source=self.src(len(studs)))
        else:
            t, p, c = self.tiers_chart(cls, ov, w=12)
            d.chart(t, p, c, width=12, source=self.src(len(studs)))
            d.placeholder("成绩表只有总分、没有逐题得分，暂无题型得分率。" if not self.e.has_q
                          else "未提供题目档案，暂无题型得分率。")

    def qrate_chart(self, cls, qs):
        qids = [q["qid"] for q in self.e.questions]
        rates = [qs[x]["得分率"] for x in qids]
        line = self.e.frac("及格线")
        below = [q for q in self.e.questions if qs[q["qid"]]["得分率"] is not None and qs[q["qid"]]["得分率"] < line]
        low = min((q for q in self.e.questions if qs[q["qid"]]["得分率"] is not None),
                  key=lambda q: qs[q["qid"]]["得分率"], default=None)
        default = (f"**{len(below)}** 题低于及格线，最低是**{qno_label(low)}**" if below
                   else "所有题目得分率都**达到及格线**")
        path = self.c.question_rates([str(q["no"]) for q in self.e.questions], rates, line)
        return ("逐题得分率", path, self.concl(cls, "逐题", default))

    def hist_data(self, studs):
        """总分分数段：按满分取 1、2、5、10、20、25、50… 分一档（不超过 16 档）。返回 (档宽, 边界, 人数, 颜色)。"""
        e = self.e
        step = next(x for x in (1, 2, 5, 10, 20, 25, 50, 100, 200, 500, 1000) if e.full / x <= 16)
        nb = int(-(-e.full // step))
        edges = [i * step for i in range(nb + 1)]
        cnt = [0] * nb
        for s in studs:
            cnt[min(int(s["total"] // step), nb - 1)] += 1
        tcol = self.tier_colors()
        return step, edges, cnt, [tcol[e.tier_of(edges[i])] for i in range(nb)]

    def hist_figure(self, d, scope_key, studs, explain=None, marks=(), cid="分数段", title="总分分数段分布",
                    default=None):
        e = self.e
        names, tcol = e.tier_names(), self.tier_colors()
        ov = e.overall(studs)
        step, edges, cnt, cols = self.hist_data(studs)
        legend = [(f"{nm} {k}人", col) for nm, k, col in zip(names, ov["分档人数"], tcol)]
        path = self.c.histogram(edges, cnt, cols, vline=e.pass_line, vlabel=f"及格线 {fmt_line(e.pass_line)}",
                                legend=legend, marks=tuple(marks))
        bi = max(range(len(cnt)), key=lambda i: (cnt[i], -i))
        default = default or (f"**{fmt_score(edges[bi])}–{fmt_score(edges[bi + 1])}** 分人数最多"
                              f"（{cnt[bi]} 人，占 {fmt_pct(cnt[bi] / len(studs))}）")
        d.figure(path, title, f"{self.src(len(studs))}；按 {fmt_score(step)} 分一档，虚线为及格线，柱的颜色为所在分档。",
                 self.concl(scope_key, cid, default), explain=explain)
        return step

    def kp_chart(self, d, scope_key, studs, n=12):
        """知识点得分率（得分率最低的 n 个，低于及格线标红）。"""
        e = self.e
        kp = {k: v for k, v in e.kp_rates(studs).items() if k != "待定"}
        if len(kp) < 2:
            return
        ks = sorted(kp, key=lambda k: (kp[k], k))[:n]
        pf = e.frac("及格线")
        below = [k for k in ks if kp[k] < pf - 1e-9]
        path = self.c.hbars([short(k, 12) for k in ks], [kp[k] for k in ks], w=17.4,
                            colors=[CRIT if kp[k] < pf - 1e-9 else BLUE for k in ks], ref=pf,
                            ref_label=f"及格线 {pf * 100:.0f}%", stem="kps")
        default = (f"**{len(below)}** 个知识点低于及格线，最低是**{short(ks[0], 12)}**" if below
                   else "各知识点得分率都**达到及格线**")
        if text_len(default) > 30:
            default = f"最薄弱的知识点是**{short(ks[0], 12)}**"
        d.figure(path, f"知识点得分率（最低的 {len(ks)} 个）" if len(kp) > n else "各知识点得分率",
                 f"{self.src(len(studs))}；一道题涉及多个知识点时分别计入；红色为低于及格线。",
                 self.concl(scope_key, "知识点", default))

    def extra_blocks(self, scope_key):
        return (self.a.get("extra") or {}).get(scope_key) or []

    def render_extra(self, d, blocks):
        for blk in blocks:
            d.subhead(blk.get("标题", ""))
            ch, tb = blk.get("图表"), blk.get("表格")
            if blk.get("正文"):
                d.body(blk["正文"], keep=bool(ch or tb))
            if ch:
                d.figure(self.c.bar_simple(ch["标签"], ch["数值"], ch.get("单位", "")), blk.get("标题", ""), None, None)
            if tb:
                n = len(tb["表头"])
                d.ctable(blk.get("标题", ""), tb["表头"], tb["行"], [LAYOUT_W / n] * n)

    def _numbered(self, d, items):
        for i, it in enumerate(items, 1):
            d.item(i, it)

    # ---- 错题分析报告·全班版
    def error_class(self, cls):
        e = self.e
        studs = e.in_class(cls)
        ov, qs = e.overall(studs), e.q_stats(studs)
        n_st = len(studs)
        d = self.D(self.font, self.header_text("错题分析报告"), self.layout)
        d.title(f"{'' if cls == '未分班' else cls}错题分析报告", self.meta_line(cls))
        sec = 1
        # 1 整体学情
        d.heading(sec, "整体学情")
        d.subhead("核心指标")
        d.kpis(self.kpi_class(ov), caption="全班成绩核心指标", source=self.src(n_st))
        d.subhead("分数分布与分档")
        self.hist_figure(d, cls, studs)
        self.overview_pair(d, cls, ov, studs)
        d.subhead("逐题与知识点得分率")
        t, p, c = self.qrate_chart(cls, qs)
        d.chart(t, p, c, source=f"{self.src(n_st)}；低于及格线的题标红。")
        self.kp_chart(d, cls, studs)
        # 2 高频错题
        sec += 1
        d.heading(sec, "高频错题")
        n = int(e.cfg["高频错题TopN"])
        wrong = [q for q in e.questions if qs[q["qid"]]["得分率"] is not None and qs[q["qid"]]["得分率"] < 1 - 1e-9]
        top = sorted(wrong, key=lambda q: (qs[q["qid"]]["得分率"], q["no"]))[:n]
        top_ids = {q["qid"] for q in top}
        if top:
            labels = [f"{qno_label(q)} {short(q['kps'][0], 8)}" for q in top]
            path = self.c.hbars(labels, [qs[q["qid"]]["得分率"] for q in top], w=17.4, color=CRIT, stem="topn")
            default = f"得分率最低的是**{qno_label(top[0])}**（{short(top[0]['kps'][0], 10)}）"
            d.chart(f"全班得分率最低的 {len(top)} 题", path, self.concl(cls, "高频", default),
                    source=f"{self.src(n_st)}；按得分率从低到高。")
        else:
            d.placeholder("全班所有题目均为满分，没有错题。")
        # 3 逐题分析
        sec += 1
        d.heading(sec, "逐题分析")
        allfull = [q for q in e.questions if qs[q["qid"]]["得分率"] is not None and qs[q["qid"]]["得分率"] >= 1 - 1e-9]
        if allfull:
            d.body("全班满分的题：" + "、".join(qno_label(q) for q in allfull) + "，以下不再逐题分析。")
        se = self.a.get("student_errors") or {}
        keys = {s["key"] for s in studs}
        for q in wrong:
            st = qs[q["qid"]]
            r = st["得分率"]
            qa = (self.a.get("questions") or {}).get(q["qid"], {})
            types = defaultdict(int)
            for k, m in se.items():
                if k in keys and isinstance(m, dict) and isinstance(m.get(q["qid"]), dict):
                    tp = m[q["qid"]].get("类型")
                    if tp in ERROR_TYPES:
                        types[tp] += 1
            head = {"title": qno_label(q),
                    "sub": f"{q['section']} · {'、'.join(q['kps'])} · {fmt_score(q['max'])} 分",
                    "right": f"得分率 **{fmt_pct(r)}**",
                    "badges": [("高频", CRIT)] if q["qid"] in top_ids else []}
            body = ("image", q["image"]) if q.get("image") and os.path.exists(q["image"]) else ("text", q["text"])
            left = self.c.mini_stack(st["满分人数"], st["部分人数"], st["零分人数"])

            def l_err(p, qa=qa):
                d.chip(p, "错因")
                d.rich(p, qa.get("错因", ""), 10.5)

            def l_types(p, types=types):
                d.run(p, "错因构成：", 10, color=INK2)
                d.run(p, "，".join(f"{tp} {types[tp]} 人" for tp in ERROR_TYPES if types.get(tp)), 10, color=INK2)

            def l_fix(p, qa=qa):
                d.chip(p, "纠正")
                d.rich(p, qa.get("纠正要点", ""), 10.5)

            lines = [l_err] + ([l_types] if types else []) + [l_fix]
            d.card(head, body, left, lines)
        if not wrong:
            d.placeholder("没有失分题。")
        # 补充分析
        extra = self.extra_blocks(cls)
        if extra:
            sec += 1
            d.heading(sec, "补充分析")
            self.render_extra(d, extra)
        # 个人分析与建议
        sec += 1
        d.heading(sec, "个人分析与建议")
        rows = []
        adv = self.a.get("advice") or {}
        for s in sorted(studs, key=lambda s: -s["total"]):
            lost = e.lost(s)
            kp = e.kp_rates([s])
            weak = e.weak_kps(s, kp, below=e.cfg["及格线"])[:2]
            a = adv.get(s["key"])
            a = (a[0] if isinstance(a, list) and a else a) if a else ""
            rows.append([s["name"], fmt_score(s["total"]),
                         ", ".join(str(q["no"]) for q in lost) or "无",
                         "、".join(weak) or "—", a or ("—" if not lost else "")])
        d.ctable("学生个人分析与建议", ["姓名", "总分", "失分题号", "薄弱知识点", "建议"], rows, [2.0, 1.4, 4.4, 3.8, 5.8],
                align=["center", "center", "left", "left", "left"], source=f"{self.src(n_st)}；按总分从高到低。")
        d.notes(self.notes_lines(studs, [f"高频错题：全班得分率最低的 {n} 题；错题指得分低于满分。",
                                         "薄弱知识点：本人该知识点得分率低于及格线，取最低 2 个。"]))
        return d

    # ---- 错题分析报告·单人版
    def error_student(self, cls, s):
        e = self.e
        studs = e.in_class(cls)
        qs_cls = e.q_stats(studs)
        lost = e.lost(s)
        d = self.D(self.font, self.header_text(f"{s['name']} 错题分析报告"), self.layout)
        d.title(f"{s['name']}错题分析报告", self.meta_line(cls, s["name"]))
        k = s["key"]
        sec = 1
        # 1 整体学情
        d.heading(sec, "整体学情")
        ov = e.overall(studs)
        has_cls = len(studs) >= 2  # 同班还有其他学生才做班级对比；只有本人时“班级”就是自己，不比较
        src = (f"数据来源：{e.meta.get('name') or e.exam_id}成绩（本人；班级平均基于 {len(studs)} 人）" if has_cls
               else f"数据来源：{e.meta.get('name') or e.exam_id}成绩（仅本人）")
        lost_pts = sum(q["max"] - s["scores"][q["qid"]] for q in lost)
        tiles = [(None, f"{fmt_score(s['total'])} / {fmt_score(e.full)}", "总分"),
                 (None, fmt_pct(s["total"] / e.full if e.full else None), "得分率")]
        if has_cls:
            tiles.append((None, fmt_score(round(ov["平均分"], 1)), "班级平均分"))
        tiles += [(None, fmt_score(lost_pts), "失分"), (None, str(len(lost)), "失分题数")]
        if s.get("rank") not in (None, ""):
            tiles.append((None, str(s["rank"]), "名次"))
        d.subhead("核心指标")
        d.kpis(tiles, caption="本人成绩核心指标", source=src)
        d.subhead("题型与逐题得分")
        mine, clsr = e.sec_rates([s]), e.sec_rates(studs)
        left = (self.section_chart(k, mine, compare=clsr, names=("本人", "班级平均")) if has_cls
                else self.section_chart(k, mine, names=("本人", None)))
        items = []
        for q in e.questions:
            v = s["scores"].get(q["qid"])
            st = "miss" if v is None else ("full" if v >= q["max"] - 1e-9 else ("zero" if v <= 1e-9 else "part"))
            items.append((q["no"], st))
        zeros = sum(1 for _, st in items if st == "zero")
        right = ("逐题得分", self.c.grid(items),
                 self.concl(k, "逐题", f"失分 **{len(lost)}** 题，其中零分 **{zeros}** 题" if lost
                            else "**全部满分**"))
        d.chart_pair(left, right, source=src)
        if has_cls:  # 只说与班级平均的差距，不自行计算名次
            d.subhead("本人在班级中的位置")
            diff = r1(s["total"]) - r1(ov["平均分"])
            default = (f"本人总分比班级平均分{'高' if diff >= 0 else '低'} **{abs(diff):.1f}** 分，"
                       f"位于{e.tier_names()[e.tier_of(s['total'])]}档")
            self.hist_figure(d, k, studs, marks=[(s["total"], f"本人 {fmt_score(s['total'])}", CRIT)], cid="位置",
                             title="本人总分在班级分数段分布中的位置", default=default)
        # 2 单人高频错题
        sec += 1
        d.heading(sec, "单人高频错题")
        n = int(e.cfg["单人高频错题TopN"])
        top = sorted(lost, key=lambda q: (-(q["max"] - s["scores"][q["qid"]]),
                                          qs_cls[q["qid"]]["得分率"] or 0, q["no"]))[:n]
        top_ids = {q["qid"] for q in top}
        if top:
            vals = [q["max"] - s["scores"][q["qid"]] for q in top]
            labels = [f"{qno_label(q)} {short(q['kps'][0], 8)}" for q in top]
            path = self.c.hbars(labels, vals, pct=False, w=17.4, color=CRIT, stem="stopn",
                                fmt=lambda v: f"失 {fmt_score(v)} 分")
            default = f"丢分最多的是**{qno_label(top[0])}**，失 {fmt_score(vals[0])} 分"
            d.chart(f"本人失分最多的 {len(top)} 题", path, self.concl(k, "高频", default), source=src)
        else:
            d.placeholder("本次没有失分题。")
        # 3 逐题分析
        sec += 1
        d.heading(sec, "逐题分析")
        se = ((self.a.get("student_errors") or {}).get(k)) or {}
        for q in lost:
            v = s["scores"][q["qid"]]
            qa = (self.a.get("questions") or {}).get(q["qid"], {})
            er = se.get(q["qid"]) or {}
            # 单人版不画“本人 x%”小图（与卡头得分重复）；有同班数据时班级得分率写在卡头
            right = f"得分 **{fmt_score(v)}** / {fmt_score(q['max'])}"
            if has_cls:
                right += f" · 班级 {fmt_pct(qs_cls[q['qid']]['得分率'])}"
            head = {"title": qno_label(q), "sub": f"{q['section']} · {'、'.join(q['kps'])}", "right": right,
                    "badges": [("高频", CRIT)] if q["qid"] in top_ids else []}
            if q["qid"] in s["images"] and os.path.exists(s["images"][q["qid"]]):
                body = ("image", s["images"][q["qid"]])
            elif q.get("image") and os.path.exists(q["image"]):
                body = ("image", q["image"])
            else:
                body = ("text", q["text"])
            sa, ca = s["answers"].get(q["qid"]), q.get("answer")
            if sa and ca:
                sl, cl = choice_letters(sa), choice_letters(ca)
                head["body_extra"] = [f"本人选 **{sl}** · 正确答案 **{cl}**" if sl and cl
                                      else f"本人作答：**{sa}** · 参考答案：**{ca}**"]
            tp = er.get("类型") or "其他"
            basis = er.get("依据") or "待确认"

            def l_err(p, tp=tp, er=er, basis=basis):
                d.chip(p, tp)
                d.rich(p, er.get("表现", ""), 10.5)
                d.run(p, f"（依据：{basis}）", 10, color=INK2)

            def l_fix(p, qa=qa):
                d.chip(p, "纠正")
                d.rich(p, qa.get("纠正要点", ""), 10.5)

            d.card(head, body, None, [l_err, l_fix])
        if not lost:
            d.placeholder("本次没有失分题。")
        # 补充分析
        extra = self.extra_blocks(k)
        if extra:
            sec += 1
            d.heading(sec, "补充分析")
            self.render_extra(d, extra)
        # 个人分析与建议
        sec += 1
        d.heading(sec, "个人分析与建议")
        kp_me, kp_cls = e.kp_rates([s]), e.kp_rates(studs)
        weak = e.weak_kps(s, kp_me, below=1 - 1e-9)[:5]
        d.subhead("薄弱知识点")
        if weak:
            tiles = []
            for x in weak:
                qx = [q for q in e.questions if x in q["kps"] and s["scores"].get(q["qid"]) is not None]
                got = sum(s["scores"][q["qid"]] for q in qx)
                sub = "、".join(str(q["no"]) for q in qx)
                sub = f"第{sub}题" + (f"（班级得分率 {fmt_pct(kp_cls.get(x))}）" if has_cls else "")
                tiles.append((None, f"{fmt_score(got)} / {fmt_score(sum(q['max'] for q in qx))}", x, sub))
            d.kp_tiles(tiles, self.concl(k, "知识点", f"最薄弱的是**{short(weak[0], 14)}**"))
        else:
            d.placeholder("没有失分的知识点。")
        adv = (self.a.get("advice") or {}).get(k) or []
        adv = [adv] if isinstance(adv, str) else adv
        if adv:
            d.subhead("学习建议")
            self._numbered(d, adv)
        d.notes(self.notes_lines([s], [f"单人高频错题：本人失分最多的 {n} 题；错题指得分低于满分。",
                                       "错因依据：“答卷”表示从答卷批改痕迹确认，“推断”表示未从答卷直接确认，“待确认”表示需结合答卷核实。",
                                       "名次：仅在原始材料提供时显示。"],
                                     source_note=(f"本人；班级平均基于 {len(studs)} 人" if has_cls
                                                  else "仅本人；未提供同班其他学生成绩，本报告不做班级对比")))
        return d

    # ---- 成绩分析报告（模式 C）：通用小件
    def absent_in(self, classes):
        return [a for a in self.e.absent if a["class"] in set(classes)]

    def tier_colors(self):
        """分档颜色：及格线以下用暖色（最低档最红），及格线及以上用蓝色阶梯（越高越深）。"""
        e = self.e
        pf = e.frac("及格线")
        n = len(e.bounds) - 1
        below = [i for i in range(n) if e.bounds[i + 1] <= pf + 1e-9]
        above = [i for i in range(n) if i not in below]
        cols = [None] * n
        for k, i in enumerate(below):
            cols[i] = [CRIT, SERIOUS, WARN][min(k, 2)]
        ramp = TIER_RAMP5[-len(above):] if 0 < len(above) <= len(TIER_RAMP5) else [BLUE] * len(above)
        for k, i in enumerate(above):
            cols[i] = ramp[k]
        return cols

    def heat(self, r):
        """色块表单元格：(文本, 文字色, 底色)。"""
        e = self.e
        if r is None:
            return ("—", MUTED, ZEBRA)
        if r < e.frac("低分线") - 1e-9:
            bg = HEAT_LOW
        elif r < e.frac("及格线") - 1e-9:
            bg = HEAT_MID
        elif r >= e.frac("优秀线") - 1e-9:
            bg = HEAT_UP[2]
        elif r >= e.frac("良好线") - 1e-9:
            bg = HEAT_UP[1]
        else:
            bg = HEAT_UP[0]
        return (fmt_pct(r), INK, bg)

    def heat_note(self):
        e = self.e
        p = {k: f"{e.frac(k) * 100:.0f}%" for k in ("低分线", "及格线", "良好线", "优秀线")}
        return (f"色块：红 = 低于 {p['低分线']}（低分线），橙 = {p['低分线']}–{p['及格线']}，"
                f"蓝 = {p['及格线']} 及以上，越深越高（良好线 {p['良好线']}、优秀线 {p['优秀线']}）")

    def tier_desc(self):
        e, b = self.e, self.e.cfg["分数段"]
        names = e.tier_names()
        if e.abs_bounds:
            return "、".join(f"{n} [{fmt_score(float(b[i]))}, {fmt_score(float(b[i + 1]))}{']' if i == len(b) - 2 else ')'}"
                            for i, n in enumerate(names))
        return "、".join(f"{n} [{b[i] * 100:.0f}%, {b[i + 1] * 100:.0f}%{']' if i == len(b) - 2 else ')'}"
                        for i, n in enumerate(names))

    def section_summary(self, d, sa, key):
        txt = ((sa.get("小结") or {}).get(key) or "").strip()
        if txt:
            d.subhead("本节小结")
            d.body(txt)

    def fig(self, d, path, title, src, concl, width=None, explain=None):
        """带编号的图（编号由版式类连续编排）：图、图题、数据来源、分析段。"""
        d.figure(path, title, src, concl, width=width, explain=explain)

    def tab(self, d, title, headers, rows, widths, src, concl=None, explain=None, **kw):
        """带编号的表：表题、表格、数据来源、分析段。"""
        d.ctable(title, headers, rows, widths, source=src, after=[("concl", concl), ("exp", explain)], **kw)

    @staticmethod
    def _fit(fixed, n_rest, total=17.4, lo=1.2):
        """固定列宽 + n_rest 等宽列，合计为版心宽度。"""
        w = max(lo, (total - sum(fixed)) / max(n_rest, 1))
        return fixed + [w] * n_rest

    def _scope_history(self, classes):
        out = []
        for kind, meta, ex in self.history:
            hs = [s for c in classes for s in ex.in_class(c)]
            if hs:
                out.append((meta, ex, hs))
        return out

    def _rank_change(self, studs, ranks, hist):
        """与上一场考试（同一范围）比较名次变化；返回 (上一场, {学生键: 名次变化})。"""
        if len(hist) < 2:
            return None, {}
        prev = hist[-2]
        pr = prev[1].ranks(prev[2])
        pkeys = {}
        for ps in prev[2]:
            pkeys[ps["key"]] = pr[ps["key"]]
            pkeys.setdefault(f"{ps['name']}|{ps['class']}", pr[ps["key"]])
        out = {}
        for s in studs:
            old = pkeys.get(s["key"])
            if old is None and s["sid"] in (None, ""):
                old = pkeys.get(f"{s['name']}|{s['class']}")
            if old is not None:
                out[s["key"]] = old - ranks[s["key"]]
        return prev, out

    def _options(self, studs):
        """选择题选项分布的行：[(题号, [(选项, 人数, 是否正确)], 正确答案)]。"""
        e = self.e
        rows = []
        for q in [q for q in e.questions if "选择" in q["section"] and q.get("answer")]:
            cnt = defaultdict(int)
            for s in studs:
                a = choice_letters(s["answers"].get(q["qid"]))
                if a:
                    cnt[a] += 1
            ans = choice_letters(q["answer"])
            if not cnt or not ans:
                continue
            segs = sorted(cnt.items(), key=lambda kv: (kv[0] != ans, kv[0]))
            noans = len(studs) - sum(cnt.values())
            segs = [(o, c_, o == ans) for o, c_ in segs] + ([("未答", noans, False)] if noans else [])
            rows.append((qno_label(q), segs, ans))
        return rows

    def _structure_rows(self):
        e = self.e
        rows, tot_n, tot_s = [], 0, 0.0
        for sec in e.sections:
            qs = [q for q in e.questions if q["section"] == sec]
            sc = sum(q["max"] for q in qs)
            rows.append([sec, self._ranges([q["no"] for q in qs]), f"{len(qs)} 题", f"{fmt_score(sc)} 分",
                         fmt_pct(sc / e.full if e.full else None)])
            tot_n += len(qs)
            tot_s += sc
        rows.append([("合计", INK), "", f"{tot_n} 题", f"{fmt_score(tot_s)} 分", fmt_pct(tot_s / e.full if e.full else None)])
        return rows

    def _who(self, s, multi_c):
        return f"{s['name']}（{s['class']}）" if multi_c else s["name"]

    # ---- 成绩分析报告：数据解读（全部由脚本按数据生成；只做由数据直接得出的判断，不推测原因、不提建议）
    @staticmethod
    def _pp(a, b):
        """两个比率之差（按显示值），如“3.5 个百分点”。"""
        return f"{abs(rp(a) - rp(b)):.1f} 个百分点"

    @staticmethod
    def _list(xs, unit="个"):
        xs = list(xs)
        return "、".join(xs) if len(xs) <= 5 else "、".join(xs[:5]) + f"等 {len(xs)} {unit}"

    def _counts(self, studs):
        e = self.e
        t = [s["total"] for s in studs]
        return {"n": len(t), "pass": sum(x >= e.pass_line - 1e-9 for x in t),
                "low": sum(x < e.line("低分线") - 1e-9 for x in t),
                "good": sum(x >= e.line("良好线") - 1e-9 for x in t),
                "exc": sum(x >= e.excel_line - 1e-9 for x in t)}

    def _uplift(self, studs, gap):
        """临界生全部跨线后的比率：[(比率名, 原比率, 新比率, 临界人数, 线名)]。"""
        e = self.e
        n = len(studs)
        out = []
        same = abs(e.line("良好线") - e.excel_line) < 1e-6
        for name, line in (("及格", e.pass_line), ("良好", e.line("良好线")), ("优秀", e.excel_line)):
            if name == "良好" and same:
                continue
            now = sum(s["total"] >= line - 1e-9 for s in studs)
            k = sum(line - gap - 1e-9 <= s["total"] < line - 1e-9 for s in studs)
            if k:
                out.append((name + "率", now / n, (now + k) / n, k, name + "线"))
        return out

    # ---- 节导读（两句：这一节看什么 + 最突出的一个数据结论）
    def _lead_overall(self, ov, n, has_hist):
        part = "核心指标、总分分布" + ("和历次变化" if has_hist else "")
        pa, lo, ex = ov["及格率"], ov["低分率"], ov["优秀率"]
        if lo > pa + 1e-9:
            s2 = f"最突出的是**低分面大于及格面**：低分率 {fmt_pct(lo)} 比及格率 {fmt_pct(pa)} 高 {self._pp(lo, pa)}。"
        elif pa >= 0.8 - 1e-9:
            s2 = f"大部分学生已过及格线（及格率 {fmt_pct(pa)}），差距主要在高分段（优秀率 **{fmt_pct(ex)}**）。"
        else:
            s2 = f"及格率 {fmt_pct(pa)}、低分率 {fmt_pct(lo)}，及格线两侧的学生都比较多。"
        return f"本节从{part}看全体 {n} 名学生的整体水平。" + s2

    def _lead_class(self, classes, ovs, extra_parts):
        e = self.e
        parts = ["总分指标", "分档结构"] + extra_parts
        hi = max(classes, key=lambda k: ovs[k]["平均分"])
        lo = min(classes, key=lambda k: ovs[k]["平均分"])
        d = r1(ovs[hi]["平均分"]) - r1(ovs[lo]["平均分"])
        p = d / e.full if e.full else 0
        lvl = "班级之间差距明显" if p >= 0.08 else ("班级之间有一定差距" if p >= 0.04 else "各班水平接近")
        return (f"本节比较 {len(classes)} 个班的" + "、".join(parts) + "。"
                f"各班平均分最多相差 **{d:.1f}** 分（{hi}与{lo}），约为满分的 {p * 100:.0f}%，{lvl}。")

    def _lead_subj(self, ss, multi_c):
        order = sorted(ss, key=lambda x: (-(ss[x]["得分率"] or 0), x))
        hi, lo = order[0], order[-1]
        return (f"本节比较 {len(ss)} 个学科的得分率、及格率与低分率" + ("，以及各科在班级之间的差距" if multi_c else "") + "。"
                f"得分率最高的{hi}（{fmt_pct(ss[hi]['得分率'])}）与最低的{lo}（{fmt_pct(ss[lo]['得分率'])}）"
                f"相差 **{self._pp(ss[hi]['得分率'], ss[lo]['得分率'])}**，{lo}是最主要的短板学科。")

    def _lead_items(self, studs, has_opts):
        e = self.e
        secs = paper_sections(e)
        s1 = (f"本节看 {len(secs)} 种题型、{len(e.questions)} 道题的得分情况" if secs
              else f"本节看 {len(e.questions)} 道题的得分情况") + ("，以及选择题的选项分布" if has_opts else "") + "。"
        if secs:
            lost = {x: 0.0 for x in secs}
            for q in e.questions:
                if q["section"] in lost:
                    for s in studs:
                        v = s["scores"].get(q["qid"])
                        if v is not None:
                            lost[q["section"]] += q["max"] - v
            tot = sum(lost.values())
            if tot:
                big = max(secs, key=lambda x: (lost[x], x))
                return s1 + f"失分最多的题型是**{big}**，占全部失分的 {fmt_pct(lost[big] / tot)}。"
        qs = e.q_stats(studs)
        valid = [q for q in e.questions if qs[q["qid"]]["得分率"] is not None]
        if valid:
            q = min(valid, key=lambda q: (qs[q["qid"]]["得分率"], q["no"]))
            return s1 + f"得分率最低的是**{qno_label(q)}**（{fmt_pct(qs[q['qid']]['得分率'])}）。"
        return s1

    def _lead_students(self, studs, gap, multi_c, prev):
        e = self.e
        parts = ["前十名"] + (["各班前三名"] if multi_c else []) + ["临界生", "低分学生"] + (["名次进退"] if prev else [])
        crit = sum(x[3] for x in self._uplift(studs, gap))
        low = sum(1 for s in studs if s["total"] < e.line("低分线") - 1e-9)
        return ("本节列出" + "、".join(parts) + "，便于逐人跟进。"
                f"离分数线不到 {fmt_line(gap)} 分的临界生 **{crit}** 人，低分学生 {low} 人（占 {fmt_pct(low / len(studs))}）。")

    def _exp_overall(self, ov, studs, gap):
        e, full = self.e, self.e.full
        avg, med, sd = ov["平均分"], ov["中位数"], ov["标准差"]
        c = self._counts(studs)
        diff = med - avg
        if diff < -0.02 * full:
            s1 = (f"中位数 {fmt_score(med)} 分比平均分低 {abs(r1(med) - r1(avg)):.1f} 分，少数高分学生拉高了平均分，"
                  "一半以上学生的总分低于平均分，平均分不能代表多数学生的水平。")
        elif diff > 0.02 * full:
            s1 = (f"中位数 {fmt_score(med)} 分比平均分高 {abs(r1(med) - r1(avg)):.1f} 分，少数低分学生拉低了平均分，"
                  "一半以上学生的总分高于平均分。")
        else:
            s1 = f"中位数 {fmt_score(med)} 分与平均分 {avg:.1f} 分接近，分数分布大致对称，平均分能代表多数学生的水平。"
        cv = sd / full if full else 0
        lvl = "较大" if cv >= 0.15 else ("较小" if cv < 0.10 else "中等")
        s2 = (f"标准差 {sd:.1f} 分，约为满分的 {cv * 100:.0f}%，学生之间差距**{lvl}**；"
              f"最高分与最低分相差 {fmt_score(ov['最高分'] - ov['最低分'])} 分。")
        pa, lo = ov["及格率"], ov["低分率"]
        if c["low"] > c["pass"]:
            ratio = c["low"] / c["pass"] if c["pass"] else None
            s3 = (f"低分 {c['low']} 人、及格 {c['pass']} 人，低分率比及格率高 **{self._pp(lo, pa)}**"
                  + (f"，低分学生是及格学生的 {ratio:.1f} 倍。" if ratio and ratio <= 5 else
                     ("，及格学生极少。" if ratio else "，没有学生及格。")))
        else:
            s3 = f"及格 {c['pass']} 人、低分 {c['low']} 人，及格率比低分率高 {self._pp(pa, lo)}。"
        if abs(e.line("良好线") - e.excel_line) < 1e-6:
            s4 = f"达到优秀线的 {c['exc']} 人（{fmt_pct(ov['优秀率'])}）。"
        else:
            s4 = (f"达到良好线的 {c['good']} 人（{fmt_pct(ov['良好率'])}），"
                  + (f"其中达到优秀线的 {c['exc']} 人（{fmt_pct(ov['优秀率'])}）" if c["exc"] else "没有学生达到优秀线")
                  + ("，高分段学生偏少。" if ov["良好率"] < 0.1 else "。"))
        out = [("集中趋势", s1), ("离散程度", s2), ("及格与低分", s3), ("高分段", s4)]
        up = self._uplift(studs, gap)
        if up:
            out.append(("提升空间", "；".join(f"{ln}下 {fmt_line(gap)} 分以内有 {k} 人，全部跨线后{nm}可由 {fmt_pct(a)} "
                                              f"升到 **{fmt_pct(b)}**" if i == 0 else
                                              f"{ln}下有 {k} 人，{nm}可由 {fmt_pct(a)} 升到 {fmt_pct(b)}"
                                              for i, (nm, a, b, k, ln) in enumerate(up)) + "。"))
        return out

    def _exp_hist(self, studs, step):
        e = self.e
        tots = sorted(s["total"] for s in studs)
        n = len(tots)
        pl, ll, gl, el = e.pass_line, e.line("低分线"), e.line("良好线"), e.excel_line
        below = sum(t < pl - 1e-9 for t in tots)
        low = sum(t < ll - 1e-9 for t in tots)
        near = sum(pl - step - 1e-9 <= t < pl - 1e-9 for t in tots)
        good = sum(t >= gl - 1e-9 for t in tots)
        exc = sum(t >= el - 1e-9 for t in tots)
        out = []
        if n >= 4:
            q1, _, q3 = statistics.quantiles(tots, n=4, method="inclusive")
            out.append(("中间一半", f"排在中间的一半学生总分在 **{fmt_score(round(q1, 1))}–{fmt_score(round(q3, 1))}** 分之间，"
                                f"区间宽 {fmt_score(round(q3 - q1, 1))} 分。"))
        out.append(("及格线下", f"及格线 {fmt_line(pl)} 分以下 {below} 人（{fmt_pct(below / n)}），其中低于低分线 {fmt_line(ll)} 分的 "
                              f"{low} 人" + (f"，占及格线下人数的 {fmt_pct(low / below)}。" if below else "。")))
        out.append(("线下一档", f"离及格线不到 {fmt_score(step)} 分（{fmt_line(pl - step)}–{fmt_line(pl)} 分）的有 **{near}** 人，"
                              "是离及格最近的一批。" if near else f"及格线下 {fmt_score(step)} 分以内没有学生。"))
        if abs(gl - el) < 1e-6:
            out.append(("高分段", f"优秀线 {fmt_line(el)} 分及以上 {exc} 人（{fmt_pct(exc / n)}）。"))
        else:
            out.append(("高分段", f"良好线 {fmt_line(gl)} 分及以上 {good} 人（{fmt_pct(good / n)}），"
                                + (f"其中达到优秀线 {fmt_line(el)} 分的 {exc} 人。" if exc else f"没有学生达到优秀线 {fmt_line(el)} 分。")))
        return out

    def _exp_trend(self, hist):
        (m1, ex1, h1), (_, ex2, h2) = hist[-2], hist[-1]
        o1, o2 = ex1.overall(h1), ex2.overall(h2)
        name1 = m1.get("name") or m1.get("exam_id")

        def arrow(k):
            dv = rp(o2[k]) - rp(o1[k])
            return f"{fmt_pct(o1[k])} → {fmt_pct(o2[k])}（{'+' if dv >= 0 else '−'}{abs(dv):.1f}）"
        out = [("四项比率", f"与{name1}相比，平均得分率 {arrow('得分率')}，及格率 {arrow('及格率')}，"
                         f"优秀率 {arrow('优秀率')}，低分率 {arrow('低分率')}。")]
        p1 = sum(s["total"] >= ex1.pass_line - 1e-9 for s in h1)
        p2 = sum(s["total"] >= ex2.pass_line - 1e-9 for s in h2)
        l1 = sum(s["total"] < ex1.line("低分线") - 1e-9 for s in h1)
        l2 = sum(s["total"] < ex2.line("低分线") - 1e-9 for s in h2)
        out.append(("人数变化", f"及格人数 {p1} → {p2}，低分人数 {l1} → {l2}（参考人数 {len(h1)} → {len(h2)}）。"))
        dp, dl = rp(o2["及格率"]) - rp(o1["及格率"]), rp(o2["低分率"]) - rp(o1["低分率"])
        if dp == 0 and dl == 0:
            s = "及格率与低分率都没有变化。"
        elif dp > 0 and dl < 0:
            s = "及格面扩大、低分面缩小，整体**向好**。"
        elif dp < 0 and dl > 0:
            s = "及格面缩小、低分面扩大，整体**退步**。"
        else:
            s = "及格率与低分率没有同时向好，需要结合学科和学生名单查看具体变化。"
        out.append(("判断", s))
        return out

    def _tiers_by_gap(self, items, thr):
        """按相邻差距分梯队：items = [(名称, 值)] 降序；相邻差 > thr 时断开。"""
        groups = [[items[0]]]
        for a, b in zip(items, items[1:]):
            if a[1] - b[1] > thr:
                groups.append([b])
            else:
                groups[-1].append(b)
        return groups

    def _exp_class_table(self, classes, ovs):
        e = self.e
        hi = max(classes, key=lambda k: ovs[k]["平均分"])
        lo = min(classes, key=lambda k: ovs[k]["平均分"])
        sh = max(classes, key=lambda k: ovs[k]["标准差"])
        sl = min(classes, key=lambda k: ovs[k]["标准差"])
        out = [("平均分", f"各班平均分从{lo}的 {ovs[lo]['平均分']:.1f} 分到{hi}的 {ovs[hi]['平均分']:.1f} 分，"
                        f"相差 **{r1(ovs[hi]['平均分']) - r1(ovs[lo]['平均分']):.1f}** 分。")]
        if sh != sl:
            out.append(("班内差距", f"标准差最大的是{sh}（{ovs[sh]['标准差']:.1f} 分），班内高低分差距最大；"
                                  f"最小的是{sl}（{ovs[sl]['标准差']:.1f} 分），班内水平最整齐。"))
        skew = [k for k in classes if ovs[k]["中位数"] < ovs[k]["平均分"] - 0.02 * e.full]
        out.append(("中位数", f"{'、'.join(skew)}的中位数明显低于平均分，班里少数高分学生拉高了平均分，多数学生的水平低于表中的平均分。"
                    if skew else "各班中位数与平均分都比较接近，平均分能代表多数学生的水平。"))
        over = [k for k in classes if ovs[k]["低分率"] > 0.5 + 1e-9]
        if over:
            out.append(("低分率", f"低分率超过 50% 的有{'、'.join(over)}，这些班一半以上学生总分低于低分线。"))
        else:
            w = max(classes, key=lambda k: ovs[k]["低分率"])
            out.append(("低分率", f"各班低分率都不超过 50%，最高的是{w}（{fmt_pct(ovs[w]['低分率'])}）。"))
        top = max(ovs[k]["最高分"] for k in classes)
        bot = min(ovs[k]["最低分"] for k in classes)
        mx = "、".join(k for k in classes if abs(ovs[k]["最高分"] - top) < 1e-9)
        mn = "、".join(k for k in classes if abs(ovs[k]["最低分"] - bot) < 1e-9)
        out.append(("最高 / 最低", f"全体最高分 {fmt_score(top)} 出自{mx}，最低分 {fmt_score(bot)} 出自{mn}。"))
        return out

    def _exp_class_avg(self, classes, ovs, ov):
        full = self.e.full
        items = sorted(((k, r1(ovs[k]["平均分"])) for k in classes), key=lambda x: -x[1])
        out = []
        if len(classes) >= 3:
            groups = self._tiers_by_gap(items, 0.04 * full)
            if 1 < len(groups) < len(classes):
                cn = "一二三四五六七八九十"
                out.append(("梯队", "；".join(
                    f"第{cn[i]}梯队 {'、'.join(k for k, _ in g)}" + (f"（组内最多相差 {g[0][1] - g[-1][1]:.1f} 分）" if len(g) > 1 else "")
                    for i, g in enumerate(groups)) + f"。相邻梯队之间相差超过 {fmt_score(round(0.04 * full, 1))} 分（满分的 4%）。"))
        above = [k for k, v in items if v > r1(ov["平均分"])]
        below = [k for k, v in items if v <= r1(ov["平均分"])]
        if len(classes) == 2:
            out.append(("与均分比", f"{items[0][0]}高于全体均分，{items[1][0]}低于全体均分。"))
        else:
            out.append(("与均分比", f"高于全体均分的有{'、'.join(above)}（{len(above)} 个班），其余 {len(below)} 个班低于全体均分。"))
        d = items[0][1] - items[-1][1]
        out.append(("最大差距", f"最高的{items[0][0]}比最低的{items[-1][0]}高 **{d:.1f}** 分，约为满分的 {d / full * 100:.0f}%。"))
        return out

    def _exp_class_rates(self, classes, ovs):
        worse = [k for k in classes if ovs[k]["低分率"] > ovs[k]["及格率"] + 1e-9]
        better = [k for k in classes if k not in worse]
        if len(worse) == 1:
            s1 = f"{worse[0]}低分率高于及格率，低分学生比及格学生多。"
        elif worse and better:
            s1 = (f"{len(worse)} 个班（{self._list(worse)}）低分学生比及格学生多；"
                  f"只有{'、'.join(better)}及格率高于低分率。")
        elif worse:
            s1 = "所有班低分学生都比及格学生多。"
        else:
            s1 = "各班及格率都高于低分率。"
        out = [("低分与及格", s1)]
        hp = max(classes, key=lambda k: ovs[k]["及格率"])
        lp = min(classes, key=lambda k: ovs[k]["及格率"])
        out.append(("及格率", f"最高的{hp}（{fmt_pct(ovs[hp]['及格率'])}）比最低的{lp}（{fmt_pct(ovs[lp]['及格率'])}）"
                            f"高 **{self._pp(ovs[hp]['及格率'], ovs[lp]['及格率'])}**。"))
        hl = max(classes, key=lambda k: ovs[k]["低分率"])
        ll = min(classes, key=lambda k: ovs[k]["低分率"])
        out.append(("低分率", f"最高的{hl}（{fmt_pct(ovs[hl]['低分率'])}）比最低的{ll}（{fmt_pct(ovs[ll]['低分率'])}）"
                            f"高 {self._pp(ovs[hl]['低分率'], ovs[ll]['低分率'])}。"))
        return out

    def _exp_class_tiers(self, classes, ovs):
        e = self.e
        names = e.tier_names()
        out = []
        share = {k: ovs[k]["分档人数"][0] / ovs[k]["人数"] for k in classes if ovs[k]["人数"]}
        hi = max(share, key=lambda k: share[k])
        lo = min(share, key=lambda k: share[k])
        out.append((f"{names[0]}档", f"占本班比例最高的是{hi}（{fmt_pct(share[hi])}），最低的是{lo}（{fmt_pct(share[lo])}）。"))
        pf = e.frac("及格线")
        if len(e.bounds) > 3 and e.bounds[1] < pf - 1e-9 and e.bounds[2] <= pf + 1e-9:
            mid = {k: ovs[k]["分档人数"][1] for k in classes}
            tot = sum(mid.values())
            n = sum(ovs[k]["人数"] for k in classes)
            if tot:
                b = max(classes, key=lambda k: (mid[k], k))
                out.append((f"{names[1]}档", f"共 {tot} 人（占 {fmt_pct(tot / n)}），最多的是{b}（{mid[b]} 人）；"
                                           "这一档在低分线与及格线之间，是提升及格率的主要来源。"))
        gf = e.frac("良好线")
        gi = next((i for i in range(len(e.bounds) - 1) if e.bounds[i] >= gf - 1e-9), None)
        if gi is not None:
            lab = (f"{fmt_score(e.bounds[gi] * e.full)} 分及以上" if getattr(e, "tier_names_auto", False)
                   else f"{names[gi]}及以上")
            cnt = {k: sum(ovs[k]["分档人数"][gi:]) for k in classes}
            tot = sum(cnt.values())
            if tot:
                b = max(classes, key=lambda k: (cnt[k], k))
                zero = [k for k in classes if not cnt[k]]
                out.append((lab, f"共 {tot} 人，其中{b} {cnt[b]} 人，占 **{fmt_pct(cnt[b] / tot)}**"
                                 + (f"；{self._list(zero)}没有这一档的学生。" if zero else "。")))
            else:
                out.append((lab, "没有这一档的学生。"))
        return out

    def _exp_heat(self, classes, rates, cols, what, overall):
        """班级 × 学科（题型）色块表的解读。rates[班级][列] = 得分率；overall[列] = 全体得分率。"""
        e = self.e
        mins, maxs = {}, {}
        for k in classes:
            vv = {x: rates[k][x] for x in cols if rates[k].get(x) is not None}
            if vv:
                mins[k] = min(vv, key=lambda x: vv[x])
                maxs[k] = max(vv, key=lambda x: vv[x])
        out = []
        grp = defaultdict(list)
        for k, x in mins.items():
            grp[x].append(k)
        if len(grp) == 1:
            x = next(iter(grp))
            out.append(("最低" + what, f"{len(mins)} 个班得分率最低的{what}都是**{x}**，属于共性短板，不是个别班的问题。"))
        else:
            out.append(("最低" + what, "；".join(f"{x}（{'、'.join(v)}）" for x, v in grp.items()) + "。"))
        cnt = defaultdict(int)
        for x in maxs.values():
            cnt[x] += 1
        if cnt:
            best = max(cnt, key=lambda x: (cnt[x], x))
            out.append(("优势" + what, f"{'各班' if cnt[best] == len(maxs) else f'{cnt[best]} 个班'}得分率最高的{what}是{best}。"))
        lf = e.frac("低分线")
        red = [(k, x) for k in classes for x in cols if rates[k].get(x) is not None and rates[k][x] < lf - 1e-9]
        if red:
            rc = defaultdict(int)
            for k, x in red:
                rc[x] += 1
            order = sorted(rc, key=lambda x: (-rc[x], x))
            cut = rc[order[min(2, len(order) - 1)]]
            top = [x for x in order if rc[x] >= cut]
            out.append(("红色格子", f"低于低分线的共 {len(red)} 格，集中在" + "、".join(f"{x}（{rc[x]} 个班）" for x in top) + "。"))
        else:
            out.append(("红色格子", "没有低于低分线的格子。"))
        weak = sorted(((rp(rates[k][x]) - rp(overall[x]), k, x) for k in classes for x in cols
                       if rates[k].get(x) is not None and overall.get(x) is not None), key=lambda t: (t[0], t[1], t[2]))
        weak = [w for w in weak if w[0] <= -8]
        if weak:
            out.append(("相对偏弱", "比年级同科低 8 个百分点以上的有" + "、".join(f"{k}{x}（{w:.1f}）" for w, k, x in weak[:6])
                         + ("等" if len(weak) > 6 else "") + "，这些是班级自己的短板。"))
        else:
            out.append(("相对偏弱", f"各班各{what}与年级整体相差都在 8 个百分点以内，没有明显的班级个别短板。"))
        return out

    def _exp_class_hist(self, classes, hist):
        (m1, ex1, _), (_, ex2, _) = hist[-2], hist[-1]
        r_old, r_new = {}, {}
        for k in classes:
            a, b = ex1.in_class(k), ex2.in_class(k)
            if a and b:
                r_old[k], r_new[k] = rp(ex1.overall(a)["得分率"]), rp(ex2.overall(b)["得分率"])
        if not r_old:
            return None
        dl = {k: r_new[k] - r_old[k] for k in r_old}
        ups = [k for k in dl if dl[k] > 0]
        dns = [k for k in dl if dl[k] < 0]
        s = f"与{m1.get('name') or m1.get('exam_id')}相比，"
        s += (f"{len(ups)} 个班上升，升幅最大的是{max(ups, key=lambda k: dl[k])}（+{max(dl[k] for k in ups):.1f} 个百分点）"
              if ups else "没有班级上升")
        s += "；" + (f"{len(dns)} 个班下降，降幅最大的是{min(dns, key=lambda k: dl[k])}（−{abs(min(dl[k] for k in dns)):.1f} 个百分点）"
                    if dns else "没有班级下降") + "。"
        out = [("升降", s)]
        o_old = sorted(r_old, key=lambda k: (-r_old[k], k))
        o_new = sorted(r_new, key=lambda k: (-r_new[k], k))
        moved = [f"{k} 第 {o_old.index(k) + 1} → 第 {o_new.index(k) + 1}" for k in o_new if o_old.index(k) != o_new.index(k)]
        out.append(("班级位次", "各班平均得分率的排序没有变化。" if not moved else "位次变化：" + "、".join(moved) + "。"))
        return out

    def _exp_subjects(self, studs):
        e = self.e
        sh = sorted(e.subjects, key=lambda x: (-e.subjects[x], list(e.subjects).index(x)))
        out = []
        if len(sh) > 1:
            a, b = sh[0], sh[1]
            tw = e.subjects[a] + e.subjects[b]
            out.append(("分值结构", f"{a}、{b}两科分值最高，合计 {fmt_score(tw)} 分，占总分的 **{fmt_pct(tw / e.full)}**，"
                                  f"对总分影响最大；分值最少的是{sh[-1]}（{fmt_score(e.subjects[sh[-1]])} 分）。"))
        miss = {x: sum(1 for s in studs if s["subj"].get(x) is None) for x in e.subjects}
        if any(miss.values()):
            m = max(miss, key=lambda x: (miss[x], x))
            out.append(("单科缺考", f"缺考最多的是{m}（{miss[m]} 人），该科按实际参考人数统计，总分按其余各科之和计算。"))
        return out

    def _exp_structure(self):
        """试卷结构解读：分值最多的题型、前两类合计、单题分值大的题（只用题目档案）。"""
        e = self.e
        secs = [x for x in e.sections if x != "未分类"]
        if not secs or not e.full:
            return None
        val = {x: sum(q["max"] for q in e.questions if q["section"] == x) for x in secs}
        big = max(secs, key=lambda x: (val[x], -secs.index(x)))
        n = sum(1 for q in e.questions if q["section"] == big)
        out = [("分值结构", f"全卷 {len(secs)} 个题型、{len(e.questions)} 题。{big}分值最多，{n} 题共 {fmt_score(val[big])} 分，"
                         f"占满分 **{fmt_pct(val[big] / e.full)}**，这一题型的得失对总分影响最大。")]
        if len(secs) >= 3:
            top2 = sorted(secs, key=lambda x: (-val[x], secs.index(x)))[:2]
            v2 = val[top2[0]] + val[top2[1]]
            out.append(("前两类", f"分值最多的两类（{'、'.join(top2)}）合计 {fmt_score(v2)} 分，占满分 {fmt_pct(v2 / e.full)}。"))
        bigq = [q for q in e.questions if q["max"] >= max(10, 0.08 * e.full) - 1e-9]
        if bigq and len(bigq) < len(e.questions):
            if len(bigq) <= 4:
                which = "、".join(f"{qno_label(q)}（{q['section']}，{fmt_score(q['max'])} 分）" for q in bigq)
            else:
                by = OrderedDict()
                for q in bigq:
                    by.setdefault(q["section"], []).append(q)
                which = "、".join(f"{k} {len(v)} 题" for k, v in by.items())
            vb = sum(q["max"] for q in bigq)
            out.append(("大分值题", f"单题 {fmt_line(max(10, 0.08 * e.full))} 分及以上的有 {len(bigq)} 题：{which}，"
                        f"合计 {fmt_score(vb)} 分，占满分 {fmt_pct(vb / e.full)}；这类题多为主观题，"
                          "评分尺度对总分影响大，阅卷时宜统一标准。"))
        return out

    def _exp_subj_table(self, ss, ov):
        e = self.e
        pf = e.frac("及格线")
        below = [x for x, o in ss.items() if (o["得分率"] or 0) < pf - 1e-9]
        out = [("未达及格线", f"得分率低于及格线（{pf * 100:.0f}%）的有 {len(below)} 科：{'、'.join(below)}。" if below
                else "各科得分率都达到及格线。")]
        lost = {x: e.subjects[x] - (o["平均分"] or 0) for x, o in ss.items()}
        tl = sum(lost.values())
        if tl > 0:
            top = sorted(lost, key=lambda x: (-lost[x], x))[:2]
            share = sum(lost[x] for x in top) / tl
            out.append(("失分构成", f"按各科平均分计算，各科失分合计 {tl:.1f} 分，其中" + "、".join(
                f"{x}丢 {lost[x]:.1f} 分（{fmt_pct(lost[x] / tl)}）" for x in top) +
                        f"，两科合计占 **{fmt_pct(share)}**，是总分提升空间最大的学科。"))
        rel = {x: o["标准差"] / e.subjects[x] for x, o in ss.items() if o["标准差"] is not None}
        if len(rel) >= 2:
            h = max(rel, key=lambda x: rel[x])
            lw = min(rel, key=lambda x: rel[x])
            if (rel[h] - rel[lw]) * 100 < 3:
                out.append(("离散程度", f"按满分折算，各科标准差都在满分的 {rel[lw] * 100:.0f}%–{rel[h] * 100:.0f}% 之间，"
                                     "各科学生之间的差距程度相近。"))
            else:
                out.append(("离散程度", f"按满分折算，标准差最大的是{h}（约为满分的 {rel[h] * 100:.0f}%），这科学生之间差距最大；"
                                     f"最小的是{lw}（约 {rel[lw] * 100:.0f}%）。"))
        return out

    def _exp_subj_rates(self, ss):
        pf = self.e.frac("及格线")
        ok = [x for x, o in ss.items() if (o["得分率"] or 0) >= pf - 1e-9]
        order = sorted(ss, key=lambda x: (-(ss[x]["得分率"] or 0), x))
        hi, lo = order[0], order[-1]
        return [("达标", f"达到及格线的有{'、'.join(ok)}（{len(ok)} 科）。" if ok else "没有学科达到及格线。"),
                ("排序", "得分率从高到低：" + " > ".join(order) + "。"),
                ("差距", f"最高的{hi}（{fmt_pct(ss[hi]['得分率'])}）比最低的{lo}（{fmt_pct(ss[lo]['得分率'])}）"
                       f"高 **{self._pp(ss[hi]['得分率'], ss[lo]['得分率'])}**。")]

    def _exp_subj_pass_low(self, ss):
        over = [x for x, o in ss.items() if (o["低分率"] or 0) > 0.5 + 1e-9]
        worse = [x for x, o in ss.items() if (o["低分率"] or 0) > (o["及格率"] or 0) + 1e-9]
        hp = max(ss, key=lambda x: ss[x]["及格率"] or 0)
        ll = min(ss, key=lambda x: ss[x]["低分率"] or 0)
        out = [("低分率过半", f"{'、'.join(over)}低分率超过 50%，这些科一半以上学生低于低分线。" if over
                else "各科低分率都不超过 50%。")]
        out.append(("低分多于及格", f"{'、'.join(worse)}（{len(worse)} 科）低分学生比及格学生多。" if worse
                    else "各科及格学生都比低分学生多。"))
        out.append(("表现最好", f"及格率最高的是{hp}（{fmt_pct(ss[hp]['及格率'])}），"
                              f"低分率最低的是{ll}（{fmt_pct(ss[ll]['低分率'])}）。"))
        return out

    def _exp_subj_range(self, info):
        """info = {科目: (最高班, 最低班, 极差)}"""
        e = self.e
        rel = {x: v[2] / e.subjects[x] for x, v in info.items()}
        h = max(rel, key=lambda x: rel[x])
        lw = min(rel, key=lambda x: rel[x])
        out = []
        if (rel[h] - rel[lw]) * 100 < 3:
            out.append(("按满分折算", f"各科班际极差都在该科满分的 {rel[lw] * 100:.0f}%–{rel[h] * 100:.0f}% 之间，程度相近。"))
        else:
            out.append(("按满分折算", f"班际差距最大的是{h}（极差约为该科满分的 {rel[h] * 100:.0f}%），"
                                   f"最小的是{lw}（约 {rel[lw] * 100:.0f}%）；分值不同的学科要按比例比较。"))
        for idx, word in ((0, "最高"), (1, "最低")):
            cnt = defaultdict(int)
            for v in info.values():
                cnt[v[idx]] += 1
            k = max(cnt, key=lambda c: (cnt[c], c))
            out.append((f"均分{word}", f"{k}在全部 {len(info)} 科都是均分{word}的班。" if cnt[k] == len(info)
                        else f"{k}在 {cnt[k]} 科均分{word}，其余学科分散在不同班级。"))
        return out

    def _exp_sections(self, studs):
        e = self.e
        secs = paper_sections(e)
        lost = {x: 0.0 for x in secs}
        for q in e.questions:
            if q["section"] not in lost:
                continue
            for s in studs:
                v = s["scores"].get(q["qid"])
                if v is not None:
                    lost[q["section"]] += q["max"] - v
        tot = sum(lost.values())
        if not tot:
            return [("失分构成", "各题型都没有失分。")]
        val = {x: sum(q["max"] for q in e.questions if q["section"] == x) for x in secs}
        order = sorted(secs, key=lambda x: (-lost[x], x))
        out = [("失分构成", "全部失分中，" + "、".join(f"{x}占 {fmt_pct(lost[x] / tot)}" for x in order) + "。")]
        big = order[0]
        out.append(("投入与失分", f"{big}只占满分的 {fmt_pct(val[big] / e.full)}，丢分却占 **{fmt_pct(lost[big] / tot)}**，"
                               "是提分空间最大的题型。" if lost[big] / tot > val[big] / e.full + 0.02 else
                               f"各题型丢分比例与分值比例大体相当，{big}丢分最多是因为分值大。"))
        return out

    def _exp_questions(self, qs):
        e = self.e
        valid = [q for q in e.questions if qs[q["qid"]]["得分率"] is not None]
        low3 = sorted(valid, key=lambda q: (qs[q["qid"]]["得分率"], q["no"]))[:3]
        pf = e.frac("及格线")
        below = [q for q in valid if qs[q["qid"]]["得分率"] < pf - 1e-9]
        by = defaultdict(int)
        for q in below:
            by[q["section"]] += 1
        high = sum(1 for q in valid if qs[q["qid"]]["得分率"] >= 0.9 - 1e-9)
        out = [("最难的题", "得分率最低的 3 道是" + "、".join(f"{qno_label(q)}（{fmt_pct(qs[q['qid']]['得分率'])}，{q['section']}）"
                                                for q in low3) + "。")]
        if below:
            out.append(("低于及格线", f"共 {len(below)} 题，按题型：" + "、".join(f"{k} {v} 题" for k, v in by.items()) + "。"))
        out.append(("掌握较好", f"得分率达到 90% 的有 {high} 道题。" if high else "没有得分率达到 90% 的题。"))
        return out

    def _exp_options(self, rows):
        picks = []
        for lab, segs, ans in rows:
            wrong = [(o, c_) for o, c_, ok in segs if not ok and o != "未答"]
            if wrong:
                o, c_ = max(wrong, key=lambda x: (x[1], x[0]))
                picks.append((lab, o, c_, sum(x[1] for x in wrong)))
        if not picks:
            return None
        picks.sort(key=lambda x: (-x[2], x[0]))
        lab, o, c_, tw = picks[0]
        conc = [p for p in picks if p[3] and p[2] / p[3] >= 0.6]
        out = [("错选最多", "、".join(f"{p[0]}选 {p[1]}（{p[2]} 人）" for p in picks[:3]) + "。"),
               ("集中程度", f"{lab}答错的 {tw} 人中有 {c_} 人选了 {o}，占 **{fmt_pct(c_ / tw)}**。")]
        if conc:
            out.append(("同一误选", f"答错学生中六成以上选同一个错误选项的题有 {len(conc)} 道："
                                  + "、".join(p[0] for p in conc[:6]) + ("等" if len(conc) > 6 else "") + "，说明错误原因比较一致。"))
        return out

    def _exp_top(self, top, ov, ranks, multi_c):
        e = self.e
        last = top[-1]
        avg_top = sum(s["total"] for s in top) / len(top)
        out = [("门槛", f"第 {ranks[last['key']]} 名 {fmt_score(last['total'])} 分，比全体均分高 "
                       f"{r1(last['total']) - r1(ov['平均分']):.1f} 分。"),
               ("前十水平", f"前 {len(top)} 名平均 {avg_top:.1f} 分，得分率 {fmt_pct(avg_top / e.full)}"
                          + ("，没有人达到优秀线。" if all(s["total"] < e.excel_line - 1e-9 for s in top) else "。"))]
        if multi_c:
            cnt = defaultdict(int)
            for s in top:
                cnt[s["class"]] += 1
            out.append(("班级分布", f"分布在 {len(cnt)} 个班：" + "、".join(
                f"{k} {v} 人" for k, v in sorted(cnt.items(), key=lambda kv: (-kv[1], kv[0]))) + "。"))
        return out

    def _exp_top3(self, firsts, ranks):
        hi = max(firsts, key=lambda x: x[1]["total"])
        lo = min(firsts, key=lambda x: x[1]["total"])
        out = [("各班第一", f"最高的是{hi[0]}的{hi[1]['name']}（{fmt_score(hi[1]['total'])} 分），"
                          f"最低的是{lo[0]}的{lo[1]['name']}（{fmt_score(lo[1]['total'])} 分），"
                          f"相差 {fmt_score(r1(hi[1]['total']) - r1(lo[1]['total']))} 分。")]
        out_top = [k for k, s in firsts if ranks[s["key"]] > 10]
        out.append(("头部学生", (f"{self._list(out_top)}的第一名没有进入前十名，"
                                 + ("该班" if len(out_top) == 1 else "这些班") + "缺少领先全体的学生。") if out_top
                    else "各班第一名都在前十名以内。"))
        return out

    def _exp_critical(self, crit_n, gap, studs, multi_c):
        n = len(studs)
        tot = sum(len(v) for v in crit_n.values())
        if not tot:
            return [("人数", f"没有学生处在分数线下 {fmt_line(gap)} 分以内。")]
        out = [("人数", f"{len(crit_n)} 类临界生共 **{tot}** 人，占实考人数的 {fmt_pct(tot / n)}；"
                       f"他们离相应分数线都不到 {fmt_line(gap)} 分，是按分数看最接近跨线的学生。")]
        up = self._uplift(studs, gap)
        if up:
            out.append(("跨线测算", "若临界生全部跨线，" + "，".join(f"{nm} {fmt_pct(a)} → **{fmt_pct(b)}**" if i == 0
                                                             else f"{nm} {fmt_pct(a)} → {fmt_pct(b)}"
                                                             for i, (nm, a, b, k, ln) in enumerate(up)) + "。"))
        pc = crit_n.get("及格临界") or []
        if multi_c and pc:
            byc = defaultdict(int)
            for s in pc:
                byc[s["class"]] += 1
            out.append(("班级分布", "及格临界生：" + "、".join(f"{k} {v} 人" for k, v in
                                                     sorted(byc.items(), key=lambda kv: (-kv[1], kv[0]))) + "。"))
        return out

    def _exp_low(self, lows, studs, classes, multi_c):
        e = self.e
        n = len(studs)
        if not lows:
            return None
        out = [("占比", f"低分学生 {len(lows)} 人，占实考人数的 **{fmt_pct(len(lows) / n)}**。")]
        if multi_c:
            share = {}
            for k in classes:
                st = [s for s in studs if s["class"] == k]
                if st:
                    share[k] = sum(1 for s in lows if s["class"] == k) / len(st)
            h = max(share, key=lambda k: share[k])
            lw = min(share, key=lambda k: share[k])
            out.append(("班级分布", f"占本班比例最高的是{h}（{fmt_pct(share[h])}），最低的是{lw}（{fmt_pct(share[lw])}）。"))
        very = [s for s in lows if s["total"] < 0.2 * e.full - 1e-9]
        out.append(("极低分", f"其中总分不到满分 20%（{fmt_line(0.2 * e.full)} 分）的有 {len(very)} 人，基础最薄弱。" if very
                    else f"没有学生总分低于满分的 20%（{fmt_line(0.2 * e.full)} 分），最低分 {fmt_score(lows[0]['total'])} 分。"))
        return out

    def _exp_progress(self, studs, rank_change):
        up = sum(1 for s in studs if rank_change.get(s["key"], 0) > 0)
        dn = sum(1 for s in studs if rank_change.get(s["key"], 0) < 0)
        same = sum(1 for s in studs if s["key"] in rank_change and rank_change[s["key"]] == 0)
        new = sum(1 for s in studs if s["key"] not in rank_change)
        big = max(2, round(len(studs) * 0.2))
        bu = sum(1 for s in studs if rank_change.get(s["key"], 0) >= big)
        bd = sum(1 for s in studs if rank_change.get(s["key"], 0) <= -big)
        return [("升降人数", f"名次上升 {up} 人、下降 {dn} 人、不变 {same} 人" + (f"，另有 {new} 人上次没有成绩。" if new else "。")),
                ("大幅变化", f"名次变化达到 {big} 名（约为人数的 20%）及以上的：上升 {bu} 人、下降 {bd} 人，"
                           "这些学生成绩波动最大。" if bu or bd else
                           f"没有学生名次变化达到 {big} 名（约为人数的 20%），整体排名比较稳定。")]

    # ---- 成绩分析报告（模式 C）
    # ---- 成绩分析报告：新增图表的数据解读（同样只做由数据直接得出的判断，不推测原因、不提建议）
    @staticmethod
    def _lead_item(items):
        """新增图表：第一条要点作图下结论，其余作解读，避免结论和解读说同一件事。"""
        return (items[0][1] if items else None), items[1:]

    @staticmethod
    def _quart(vals):
        t = sorted(vals)
        if len(t) >= 4:
            q1, med, q3 = statistics.quantiles(t, n=4, method="inclusive")
            return q1, med, q3
        m = statistics.median(t)
        return m, m, m

    def _below_pass_tiers(self):
        pf = self.e.frac("及格线")
        return [i for i in range(len(self.e.bounds) - 1) if self.e.bounds[i + 1] <= pf + 1e-9]

    def _exp_tier_share(self, ov):
        e = self.e
        names, cnt, n = e.tier_names(), ov["分档人数"], ov["人数"]
        nb = sum(cnt[i] for i in self._below_pass_tiers())
        big = max(range(len(cnt)), key=lambda i: (cnt[i], -i))
        top = len(names) - 1
        out = [("及格线两侧", f"及格线以下各档合计 {nb} 人（{fmt_pct(nb / n)}），及格线及以上 {n - nb} 人"
                             f"（{fmt_pct((n - nb) / n)}）。"),
               ("最大一档", f"{names[big]}档 {cnt[big]} 人，占 {fmt_pct(cnt[big] / n)}，是人数最多的一档。")]
        out.append(("最高一档", f"{names[top]}档 {cnt[top]} 人，占 {fmt_pct(cnt[top] / n)}。" if cnt[top]
                    else f"没有学生进入{names[top]}档。"))
        return out

    def _exp_box(self, classes):
        e = self.e
        q = {k: self._quart([s["total"] for s in e.in_class(k)]) for k in classes}
        hi = max(classes, key=lambda k: (q[k][1], k))
        lo = min(classes, key=lambda k: (q[k][1], k))
        out = []
        if hi != lo:
            if q[lo][2] < q[hi][0] - 1e-9:
                out.append(("区间重叠", f"{lo}的上四分位数 {fmt_score(round(q[lo][2], 1))} 分低于{hi}的下四分位数 "
                                    f"{fmt_score(round(q[hi][0], 1))} 分，两班中间一半学生的分数区间没有重叠。"))
            else:
                out.append(("区间重叠", f"{hi}与{lo}中间一半学生的分数区间有重叠，两班有相当一部分学生水平相当。"))
        out.append(("中位数", f"各班中位数从{lo}的 {fmt_score(round(q[lo][1], 1))} 分到{hi}的 "
                            f"{fmt_score(round(q[hi][1], 1))} 分。"))
        iq = {k: round(q[k][2], 1) - round(q[k][0], 1) for k in classes}
        wd = max(classes, key=lambda k: (iq[k], k))
        nr = min(classes, key=lambda k: (iq[k], k))
        if wd != nr:
            out.append(("中间一半", f"四分位区间最宽的是{wd}（{fmt_score(round(q[wd][0], 1))}–{fmt_score(round(q[wd][2], 1))} 分，"
                                f"宽 {iq[wd]:.1f} 分），最窄的是{nr}（宽 {iq[nr]:.1f} 分），{wd}班内中间学生的分数更分散。"))
        pl = e.pass_line
        under = [k for k in classes if q[k][1] < pl - 1e-9]
        out.append(("及格线", f"中位数低于及格线 {fmt_line(pl)} 分的有{self._list(under)}，这些班有一半学生未及格。" if under
                    else f"各班中位数都达到及格线 {fmt_line(pl)} 分，每个班都有一半以上学生及格。"))
        return out

    def _exp_class_bars(self, classes, crates, cols, what):
        e = self.e
        pf = e.frac("及格线")
        lead = defaultdict(int)
        rng = {}
        for x in cols:
            vals = {k: crates[k].get(x) for k in classes if crates[k].get(x) is not None}
            if not vals:
                continue
            hk = max(vals, key=lambda k: (vals[k], k))
            lk = min(vals, key=lambda k: (vals[k], k))
            lead[hk] += 1
            rng[x] = (rp(vals[hk]) - rp(vals[lk]), hk, lk)
        out = []
        if lead:
            order = sorted(lead, key=lambda k: (-lead[k], k))
            out.append(("领先", f"{order[0]}在 {lead[order[0]]} 个{what}中得分率最高" +
                        ("，是各" + what + "都领先的班。" if lead[order[0]] == len(rng) else
                         "；" + "、".join(f"{k} {lead[k]} 个" for k in order[1:]) + "。")))
        if rng:
            big = max(rng, key=lambda x: (rng[x][0], x))
            sm = min(rng, key=lambda x: (rng[x][0], x))
            out.append(("班级差距", f"班级之间差距最大的{what}是{big}（{rng[big][1]}比{rng[big][2]}高 {rng[big][0]:.1f} 个百分点）"
                                + (f"，最小的是{sm}（{rng[sm][0]:.1f} 个百分点）。" if sm != big else "。")))
        cells = [(k, x) for k in classes for x in cols if crates[k].get(x) is not None]
        low = [(k, x) for k, x in cells if crates[k][x] < pf - 1e-9]
        if cells:
            if low:
                by = defaultdict(int)
                for _, x in low:
                    by[x] += 1
                xs = sorted(by, key=lambda x: (-by[x], x))
                out.append(("未达及格线", f"{len(cells)} 个班级与{what}的组合中，有 {len(low)} 个得分率低于及格线 {pf * 100:.0f}%，"
                                       f"集中在{self._list(xs)}。"))
            else:
                out.append(("未达及格线", f"所有班级的各{what}得分率都达到及格线 {pf * 100:.0f}%。"))
        return out

    def _exp_class_lines(self, classes, hist):
        rows = {}
        for k in classes:
            rows[k] = [ex.overall(ex.in_class(k))["得分率"] if ex.in_class(k) else None for m, ex, hs in hist]

        def gap(i):
            v = [rp(rows[k][i]) for k in classes if rows[k][i] is not None]
            return (max(v) - min(v)) if len(v) >= 2 else None
        g0, g1 = gap(0), gap(len(hist) - 1)
        n0 = hist[0][0].get("name") or hist[0][0].get("exam_id")
        out = []
        if g0 is not None and g1 is not None:
            word = "扩大" if g1 > g0 + 1e-9 else ("缩小" if g1 < g0 - 1e-9 else "保持")
            out.append(("班级差距", f"最高班与最低班的平均得分率之差，由{n0}的 {g0:.1f} 个百分点{word}"
                                  f"{'' if word == '保持' else '到'} {g1:.1f} 个百分点。"))
        ov = [ex.overall(hs)["得分率"] for m, ex, hs in hist]
        above = [k for k in classes if rows[k][-1] is not None and rp(rows[k][-1]) >= rp(ov[-1])]
        out.append(("与全体比", f"本次高于或等于全体平均得分率（{fmt_pct(ov[-1])}）的有{self._list(above)}。" if above
                    else f"本次没有班级达到全体平均得分率（{fmt_pct(ov[-1])}）。"))
        if len(hist) >= 3:
            ups = [k for k in classes if all(a is not None and b is not None and rp(b) > rp(a)
                                             for a, b in zip(rows[k], rows[k][1:]))]
            if ups:
                out.append(("连续上升", f"每次都比上一次上升的有{self._list(ups)}。"))
        return out

    def _subj_tiers(self, studs):
        """各科分档人数：按各科满分的同一比例分档（分数段写分数时不适用，返回空）。"""
        e = self.e
        if e.abs_bounds:
            return {}
        out = OrderedDict()
        for x, full in e.subjects.items():
            cnt = [0] * (len(e.bounds) - 1)
            for s in studs:
                v = s["subj"].get(x)
                if v is None:
                    continue
                f = v / full if full else 0
                i = next((j for j in range(len(e.bounds) - 1) if f < e.bounds[j + 1]), len(e.bounds) - 2)
                cnt[i] += 1
            out[x] = cnt
        return out

    def _exp_subj_tiers(self, mat):
        e = self.e
        names = e.tier_names()
        below = self._below_pass_tiers()
        share = {x: [c / (sum(r) or 1) for c in r] for x, r in mat.items()}
        hi0 = max(mat, key=lambda x: (share[x][0], x))
        lo0 = min(mat, key=lambda x: (share[x][0], x))
        out = [(f"{names[0]}档", f"{names[0]}档占比最高的是{hi0}（{fmt_pct(share[hi0][0])}），"
                                f"最低的是{lo0}（{fmt_pct(share[lo0][0])}）。")]
        top = len(names) - 1
        none = [x for x in mat if mat[x][top] == 0]
        ht = max(mat, key=lambda x: (share[x][top], x))
        out.append((f"{names[top]}档", (f"占比最高的是{ht}（{fmt_pct(share[ht][top])}）" if mat[ht][top] else "") +
                    ((("；" if mat[ht][top] else "") + f"{self._list(none)}没有学生进入{names[top]}档") if none else "") + "。"))
        half = [x for x in mat if sum(share[x][i] for i in below) > 0.5]
        out.append(("及格线下", f"及格线以下的学生超过一半的学科有{self._list(half)}。" if half
                    else "各科及格线以下的学生都不到一半。"))
        return out

    def _exp_crit_bars(self, classes, crit, lows):
        tot = {k: sum(len([s for s in v if s["class"] == k]) for v in crit.values()) for k in classes}
        hi = max(classes, key=lambda k: (tot[k], k))
        lo = min(classes, key=lambda k: (tot[k], k))
        out = [("临界生", f"{'、'.join(crit)}合计最多的是{hi}（{tot[hi]} 人），最少的是{lo}（{tot[lo]} 人）。")]
        pc = {k: sum(1 for s in crit.get("及格临界", []) if s["class"] == k) for k in classes}
        lw = {k: sum(1 for s in lows if s["class"] == k) for k in classes}
        more = [k for k in classes if lw[k] > pc[k]]
        out.append(("低分与临界", f"低分学生多于及格临界生的班有{self._list(more)}，这些班离及格线较远的学生更多。" if more
                    else "各班及格临界生都不少于低分学生。"))
        return out

    def _exp_rank_scatter(self, studs, rank_change):
        n = len(studs)
        ch = [abs(v) for v in rank_change.values()]
        thr = max(1, round(n * 0.05))
        small = sum(1 for v in ch if v <= thr)
        out = []
        r = self._rank_corr(studs, rank_change)
        if r is not None:
            lvl = "名次整体稳定" if r >= 0.8 else ("名次有一定变动" if r >= 0.5 else "名次变动较大")
            out.append(("相关程度", f"两次名次的相关系数为 {r:.2f}，{lvl}。"))
        out.append(("名次稳定", f"名次变化在 {thr} 名以内的有 {small} 人（{fmt_pct(small / len(ch))}），这些点落在虚线附近。"))
        ranks = self.e.ranks(studs)
        prev_top = [k for k, v in rank_change.items() if ranks[k] + v <= 10]
        if prev_top:
            stay = sum(1 for k in prev_top if ranks[k] <= 10)
            out.append(("前十名", f"上次前十名中有 {len(prev_top)} 人参加本次考试，其中 {stay} 人本次仍在前十。"))
        return out

    def _rank_corr(self, studs, rank_change):
        """两次名次的相关系数（名次即秩，故等同于斯皮尔曼相关）。"""
        ranks = self.e.ranks(studs)
        pairs = [(ranks[k] + v, ranks[k]) for k, v in rank_change.items()]
        if len(pairs) < 3:
            return None
        xs, ys = [a for a, _ in pairs], [b for _, b in pairs]
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        sx = sum((x - mx) ** 2 for x in xs) ** 0.5
        sy = sum((y - my) ** 2 for y in ys) ** 0.5
        return sum((x - mx) * (y - my) for x, y in pairs) / (sx * sy) if sx and sy else 1.0

    def _loss_by_section(self, studs):
        e = self.e
        secs = paper_sections(e)
        lost = OrderedDict((x, 0.0) for x in secs)
        full = OrderedDict((x, 0.0) for x in secs)
        for q in e.questions:
            if q["section"] in lost:
                full[q["section"]] += q["max"]
                for s in studs:
                    v = s["scores"].get(q["qid"])
                    if v is not None:
                        lost[q["section"]] += q["max"] - v
        return lost, full

    def _exp_loss(self, lost, full):
        tl, tf = sum(lost.values()) or 1, sum(full.values()) or 1
        big = max(lost, key=lambda x: (lost[x], x))
        sm = min(lost, key=lambda x: (lost[x], x))
        a, b = lost[big] / tl, full[big] / tf
        out = [("失分最多", f"{big}的失分占全部失分的 {fmt_pct(a)}，它的分值占满分的 {fmt_pct(b)}，" +
                ("失分比例明显高于分值比例。" if a > b + 0.05 else ("失分比例低于分值比例。" if a < b - 0.05
                                                         else "失分比例与分值比例相当。")))]
        if sm != big:
            out.append(("失分最少", f"{sm}的失分只占 {fmt_pct(lost[sm] / tl)}（分值占 {fmt_pct(full[sm] / tf)}）。"))
        return out

    def score_report(self, classes, label):
        e = self.e
        scope = "+".join(classes)
        sa = (self.a.get("成绩分析") or {}).get(scope) or {}
        studs = [s for c in classes for s in e.in_class(c)]
        multi_c, multi_s, items = len(classes) >= 2, e.has_subj and len(e.subjects) >= 2, e.has_q
        name = e.meta.get("name") or e.exam_id
        n = len(studs)
        src0 = f"数据来源：{name}成绩（{n} 人）"
        d = self.D(self.font, self.header_text("成绩分析报告"), self.layout)
        absent = self.absent_in(classes)
        ov = e.overall(studs)
        names = e.tier_names()
        tcol = self.tier_colors()
        ranks = e.ranks(studs)
        hist = self._scope_history(classes)
        prev, rank_change = self._rank_change(studs, ranks, hist)
        # 封面
        title = f"{label}{'' if label[-1:] in ('班', '级') else ' '}{name}成绩分析报告"
        subj_line = (f"考试科目：{'、'.join(e.subjects)}（共 {len(e.subjects)} 科，满分 {fmt_score(e.full)} 分）"
                     if e.has_subj else
                     f"考试科目：{e.meta.get('subject') or e.cfg.get('科目') or '—'}（满分 {fmt_score(e.full)} 分）")
        lines = [f"参考范围：{'、'.join(classes)}" + (f"（共 {len(classes)} 个班）" if multi_c else ""), subj_line]
        if e.meta.get("date"):
            lines.append(f"考试日期：{e.meta['date']}")
        foot = ([f"编制部门：{e.cfg['编制部门']}"] if e.cfg.get("编制部门") else []) + \
               ([f"编制日期：{e.cfg['编制日期']}"] if e.cfg.get("编制日期") else [])
        d.cover(e.cfg.get("学校") or "", title, lines, foot)
        # 报告摘要
        d.plain_heading("报告摘要")
        summ = sa.get("摘要") or {}
        for k in summary_parts(e, classes):
            d.body(summ.get(k) or "")
        # 1 考试基本情况
        sec = 1
        d.heading(sec, "考试基本情况")
        d.subhead("参考范围")
        d.body(f"本次考试参考范围为{'、'.join(classes)}" + (f"，共 **{len(classes)}** 个班" if multi_c else "") +
               f"；应考 **{n + len(absent)}** 人，实考 **{n}** 人" +
               (f"，缺考 **{len(absent)}** 人：{'、'.join(self._who(a, multi_c) for a in absent)}。" if absent
                else "，无缺考。"))
        if e.has_subj:
            miss = OrderedDict((k, sum(1 for s in studs if s["subj"].get(k) is None)) for k in e.subjects)
            tot_miss = sum(miss.values())
            if tot_miss:
                d.body(f"另有单科缺考 **{tot_miss}** 人次（" + "、".join(f"{k} {v}" for k, v in miss.items() if v) +
                       "），该科按实际参考人数统计。")
            d.subhead("考试科目与分值")
            rows = [[k, fmt_score(f), fmt_pct(f / e.full), str(n - miss[k])] for k, f in e.subjects.items()]
            rows.append([("总分", INK), fmt_score(e.full), "100.0%", str(n)])
            self.tab(d, "考试科目与分值设置", ["科目", "满分（分）", "占总分", "实际参考人数"], rows, [4.4, 4.3, 4.3, 4.4],
                     "数据来源：考试档案；实际参考人数不含该科缺考。", explain=self._exp_subjects(studs))
        elif e.questions and paper_sections(e):
            d.subhead("试卷结构")
            self.tab(d, "试卷结构", ["题型", "题号", "题量", "分值", "占满分"], self._structure_rows(),
                     [3.6, 5.2, 2.6, 3.0, 3.0], "数据来源：题目档案。", explain=self._exp_structure())
        d.subhead("统计口径")
        gap = e.cfg["临界分差"] * e.full
        lns = {k: e.line(k) for k in ("低分线", "及格线", "良好线", "优秀线")}
        cal = [f"分档：{self.tier_desc()}。",
               "分数线：" + "、".join(f"{k} {fmt_line(v)} 分（{e.frac(k) * 100:.0f}%）" for k, v in lns.items()) +
               "；及格率、良好率、优秀率为总分达到相应线的人数占实考人数的比例，低分率为总分低于低分线的人数占比。",
               "得分率 = 平均分 ÷ 满分；平均分、中位数、标准差（总体标准差）保留 1 位小数，比率保留 1 位小数；缺考不计入统计。",
               f"临界生：总分低于及格线、良好线或优秀线，差距在 {fmt_line(gap)} 分（满分的 {e.cfg['临界分差'] * 100:.0f}%）以内。",
               "名次：按总分在本报告范围内排序，同分同名次" + ("；名次变化与上一场考试比较。" if prev else "。")]
        if e.has_subj:
            cal.insert(2, "各科指标按该科满分的同一比例、该科实际参考人数计算，单科缺考不计入该科。")
        d.body("本报告各项指标按以下口径统计：", keep=True)
        self._numbered(d, cal)
        # 2 总体成绩概况
        sec += 1
        d.heading(sec, "总体成绩概况")
        d.lead(self._lead_overall(ov, n, len(hist) >= 2))
        d.subhead("核心指标")
        d.kpi_rows([[(None, str(n), "参考人数"), (None, f"{ov['平均分']:.1f}", "平均分"),
                     (None, fmt_score(ov["中位数"]), "中位数"), (None, fmt_score(ov["最高分"]), "最高分"),
                     (None, fmt_score(ov["最低分"]), "最低分"), (None, f"{ov['标准差']:.1f}", "标准差")],
                    [(None, fmt_pct(ov["得分率"]), "得分率"), (None, fmt_pct(ov["优秀率"]), f"优秀率（≥{e.frac('优秀线') * 100:.0f}%）"),
                     (None, fmt_pct(ov["良好率"]), f"良好率（≥{e.frac('良好线') * 100:.0f}%）"),
                     (None, fmt_pct(ov["及格率"]), f"及格率（≥{e.frac('及格线') * 100:.0f}%）"),
                     (None, fmt_pct(ov["低分率"]), f"低分率（<{e.frac('低分线') * 100:.0f}%）"),
                     (None, str(len(absent)), "缺考人数")]],
                   explain=self._exp_overall(ov, studs, gap), caption="总分核心指标统计",
                   source=f"{src0}，满分 {fmt_score(e.full)} 分；标准差为总体标准差。")
        d.subhead("分数段分布与分档结构")
        self.hist_figure(d, scope, studs, explain=self._exp_hist(studs, self.hist_data(studs)[0]))
        c0, ex = self._lead_item(self._exp_tier_share(ov))
        self.fig(d, self.c.pie(names, ov["分档人数"], tcol), "总分分档人数占比", f"{src0}；分档：{self.tier_desc()}。",
                 self.concl(scope, "分档占比", c0), width=12.0, explain=ex)
        if len(hist) >= 2:
            d.subhead("历次考试对比")
            labs = [short(m.get("name") or m.get("exam_id"), 8) for m, ex, hs in hist]
            os_ = [ex.overall(hs) for m, ex, hs in hist]
            path = self.c.history(labs, OrderedDict([("平均得分率", [o["得分率"] for o in os_]),
                                                     ("及格率", [o["及格率"] for o in os_]),
                                                     ("优秀率", [o["优秀率"] for o in os_]),
                                                     ("低分率", [o["低分率"] for o in os_])]),
                                  colors=[BLUE, GOOD, WARN, CRIT])
            dlt = (rp(os_[-1]["得分率"]) - rp(os_[-2]["得分率"])) / 100
            self.fig(d, path, "历次考试主要指标对比", f"数据来源：考试档案中本次及以前的 {len(hist)} 场考试（同一参考范围）。",
                     self.concl(scope, "历次", f"平均得分率较上次**{'上升' if dlt >= 0 else '下降'} {abs(dlt) * 100:.1f}** 个百分点"),
                     explain=self._exp_trend(hist))
        self.section_summary(d, sa, "总体")
        # 3 班级比较
        if multi_c:
            sec += 1
            d.heading(sec, "班级比较")
            ovs = {k: e.overall(e.in_class(k)) for k in classes}
            d.lead(self._lead_class(classes, ovs, (["各科得分率"] if multi_s else
                                                   (["各题型得分率"] if items and paper_sections(e) else []))
                                    + (["历次变化"] if len(hist) >= 2 else [])))
            d.subhead("各班总分核心指标对比")

            def row(lab, o):
                return [lab, str(o["人数"]), f"{o['平均分']:.1f}", fmt_score(o["中位数"]), fmt_score(o["最高分"]),
                        fmt_score(o["最低分"]), f"{o['标准差']:.1f}", fmt_pct(o["及格率"]), fmt_pct(o["低分率"])]
            rows = [row(k, ovs[k]) for k in classes] + [row(("全体", INK), ov)]
            self.tab(d, "各班总分核心指标对比", ["班级", "人数", "平均分", "中位数", "最高分", "最低分", "标准差", "及格率", "低分率"],
                     rows, [2.4, 1.5, 1.9, 1.9, 1.9, 1.9, 1.9, 2.0, 2.0], f"{src0}；标准差为总体标准差。",
                     explain=self._exp_class_table(classes, ovs))
            d.subhead("各班平均分与分数分布")
            avgs = [ovs[k]["平均分"] for k in classes]
            hi = max(classes, key=lambda k: ovs[k]["平均分"])
            path = self.c.vbars(classes, avgs, [BLUE] * len(classes), ref=ov["平均分"],
                                ref_label=f"全体均分 {ov['平均分']:.1f}", ylabel="平均分（分）")
            self.fig(d, path, "各班总分平均分对比", f"{src0}；虚线为全体均分。",
                     self.concl(scope, "各班平均分", f"**{hi}**平均分最高，比全体均分高 **{r1(ovs[hi]['平均分']) - r1(ov['平均分']):.1f}** 分"),
                     explain=self._exp_class_avg(classes, ovs, ov))
            path = self.c.boxplot(classes, [[s["total"] for s in e.in_class(k)] for k in classes],
                                  lines=((e.pass_line, f"及格线 {fmt_line(e.pass_line)}"),))
            c0, ex = self._lead_item(self._exp_box(classes))
            self.fig(d, path, "各班总分分布箱线图",
                     f"{src0}；箱为排在中间的一半学生，箱中横线为中位数，菱形为平均分，圆点为离群值，虚线为及格线。",
                     self.concl(scope, "各班分布", c0), explain=ex)
            d.subhead("各班及格率与低分率")
            path = self.c.rate_pairs(classes, [ovs[k]["及格率"] for k in classes], [ovs[k]["低分率"] for k in classes])
            lo = max(classes, key=lambda k: ovs[k]["低分率"])
            self.fig(d, path, "各班总分及格率与低分率对比", f"{src0}。",
                     self.concl(scope, "各班及格低分", f"低分率最高的是**{lo}**（{fmt_pct(ovs[lo]['低分率'])}）"),
                     explain=self._exp_class_rates(classes, ovs))
            d.subhead("各班成绩分档结构")
            path = self.c.stacked(classes, names, [ovs[k]["分档人数"] for k in classes], tcol)
            worst = max(classes, key=lambda k: (ovs[k]["分档人数"][0], k))
            k0 = ovs[worst]["分档人数"][0]
            self.fig(d, path, "各班总分分档人数分布", f"{src0}；分档：{self.tier_desc()}。",
                     self.concl(scope, "各班分档", f"{names[0]}人数最多的是**{worst}**（{k0} 人）" if k0
                                else f"各班都没有{names[0]}学生"),
                     explain=self._exp_class_tiers(classes, ovs))
            if multi_s:
                d.subhead("各班学科均衡性")
                rows, gaps, crates = [], {}, {}
                for k in classes:
                    st = e.in_class(k)
                    rs = [e.subj_stats(st, x)["得分率"] for x in e.subjects]
                    crates[k] = dict(zip(e.subjects, rs))
                    vv = [rp(r) for r in rs if r is not None]
                    gaps[k] = (max(vv) - min(vv)) / 100 if vv else 0
                    rows.append([k] + [self.heat(r) for r in rs] + [self.heat(ovs[k]["得分率"]),
                                                                    f"{gaps[k] * 100:.1f}"])
                srates = {x: e.subj_stats(studs, x)["得分率"] for x in e.subjects}
                rows.append([("全体", INK)] + [self.heat(srates[x]) for x in e.subjects] + [self.heat(ov["得分率"]), ""])
                mins = {min(e.subjects, key=lambda x: (e.subj_stats(e.in_class(k), x)["得分率"] or 0)) for k in classes}
                bigk = max(classes, key=lambda k: gaps[k])
                default = (f"各班共同的短板是**{mins.pop()}**" if len(mins) == 1
                           else f"**{bigk}**学科差距最大（{gaps[bigk] * 100:.1f} 个百分点）")
                self.tab(d, "各班各科得分率", ["班级"] + list(e.subjects) + ["总分", "差距"], rows,
                         self._fit([2.0], len(e.subjects) + 2, lo=1.3), f"{src0}；{self.heat_note()}；"
                         "差距 = 本班得分率最高与最低学科之差（百分点）。", self.concl(scope, "各班学科", default),
                         explain=self._exp_heat(classes, crates, list(e.subjects), "学科", srates))
                pf = e.frac("及格线")
                path = self.c.group_rates(list(e.subjects), [(k, [crates[k][x] for x in e.subjects]) for k in classes],
                                          ref=pf, ref_label=f"及格线 {pf * 100:.0f}%")
                c0, ex = self._lead_item(self._exp_class_bars(classes, crates, list(e.subjects), "学科"))
                self.fig(d, path, "各班各学科得分率对比", f"{src0}；虚线为及格线。",
                         self.concl(scope, "各班学科柱", c0), explain=ex)
            elif items and paper_sections(e):
                d.subhead("各班题型得分率")
                secs = paper_sections(e)
                crates = {k: e.sec_rates(e.in_class(k)) for k in classes}
                rows = [[k] + [self.heat(crates[k].get(x)) for x in secs] for k in classes]
                sr = e.sec_rates(studs)
                rows.append([("全体", INK)] + [self.heat(sr.get(x)) for x in secs])
                self.tab(d, "各班题型得分率", ["班级"] + secs, rows, self._fit([2.4], len(secs)),
                         f"{src0}；{self.heat_note()}。", explain=self._exp_heat(classes, crates, secs, "题型", sr))
                pf = e.frac("及格线")
                path = self.c.group_rates(secs, [(k, [crates[k].get(x) for x in secs]) for k in classes],
                                          ref=pf, ref_label=f"及格线 {pf * 100:.0f}%")
                c0, ex = self._lead_item(self._exp_class_bars(classes, crates, secs, "题型"))
                self.fig(d, path, "各班各题型得分率对比", f"{src0}；虚线为及格线。",
                         self.concl(scope, "各班学科柱", c0), explain=ex)
            if len(hist) >= 2:
                d.subhead("各班历次变化")
                labs = [short(m.get("name") or m.get("exam_id"), 8) for m, ex, hs in hist]
                rows = []
                for k in classes:
                    rr = []
                    for m, ex, hs in hist:
                        cs = ex.in_class(k)
                        rr.append(self.heat(ex.overall(cs)["得分率"]) if cs else ("—", MUTED, ZEBRA))
                    rows.append([k] + rr)
                self.tab(d, "各班历次平均得分率", ["班级"] + labs, rows, self._fit([2.4], len(labs)),
                         f"数据来源：考试档案中本次及以前的 {len(hist)} 场考试；{self.heat_note()}。",
                         explain=self._exp_class_hist(classes, hist))
                series = OrderedDict()
                for k in classes:
                    series[k] = [(ex.overall(ex.in_class(k))["得分率"] if ex.in_class(k) else 0) for m, ex, hs in hist]
                path = self.c.history(labs, series, ylabel="平均得分率")
                c0, ex = self._lead_item(self._exp_class_lines(classes, hist))
                self.fig(d, path, "各班历次平均得分率走势", f"数据来源：考试档案中本次及以前的 {len(hist)} 场考试。",
                         self.concl(scope, "各班历次线", c0), explain=ex)
            self.section_summary(d, sa, "班级")
        # 4 学科比较 / 题型与小题
        if multi_s:
            sec += 1
            d.heading(sec, "学科比较")
            ss = OrderedDict((x, e.subj_stats(studs, x)) for x in e.subjects)
            d.lead(self._lead_subj(ss, multi_c))
            d.subhead("各学科核心指标与得分率")

            def srow(lab, full, o):
                return [lab, fmt_score(full), str(o["人数"]), f"{o['平均分']:.1f}", fmt_pct(o["得分率"]),
                        f"{o['标准差']:.1f}", fmt_pct(o["及格率"]), fmt_pct(o["低分率"])]
            rows = [srow(x, e.subjects[x], o) for x, o in ss.items()] + [srow(("总分", INK), e.full, ov)]
            self.tab(d, "各学科核心指标统计", ["科目", "满分", "参考人数", "平均分", "得分率", "标准差", "及格率", "低分率"],
                     rows, [2.4, 1.8, 2.1, 2.1, 2.2, 2.1, 2.3, 2.4], f"{src0}；各科按实际参考人数统计。",
                     explain=self._exp_subj_table(ss, ov))
            pf = e.frac("及格线")
            rates = [o["得分率"] for o in ss.values()]
            path = self.c.vbars(list(ss), rates, [CRIT if (r or 0) < pf - 1e-9 else BLUE for r in rates], ref=pf,
                                ref_label=f"及格线 {pf * 100:.0f}%", pct=True, ylabel="得分率",
                                legend=[("低于及格线", CRIT), ("达到及格线", BLUE)])
            lo = min(ss, key=lambda x: ss[x]["得分率"] or 0)
            self.fig(d, path, "各学科得分率对比", f"{src0}；虚线为及格线。",
                     self.concl(scope, "学科得分率", f"得分率最低的是**{lo}**（{fmt_pct(ss[lo]['得分率'])}）"),
                     explain=self._exp_subj_rates(ss))
            d.subhead("各学科及格率、低分率与分档")
            path = self.c.rate_pairs(list(ss), [o["及格率"] for o in ss.values()], [o["低分率"] for o in ss.values()])
            worse = [x for x, o in ss.items() if (o["低分率"] or 0) > (o["及格率"] or 0)]
            self.fig(d, path, "各学科及格率与低分率对比", f"{src0}；各科按实际参考人数统计。",
                     self.concl(scope, "学科及格低分", f"**{len(worse)}** 科低分率高于及格率" if worse
                                else "各科及格率都**高于**低分率"),
                     explain=self._exp_subj_pass_low(ss))
            mat = self._subj_tiers(studs)
            if mat:
                c0, ex = self._lead_item(self._exp_subj_tiers(mat))
                self.fig(d, self.c.stack100(list(mat), names, list(mat.values()), tcol), "各学科分档人数占比",
                         f"{src0}；各科按该科满分的同一比例分档，按实际参考人数统计。",
                         self.concl(scope, "学科分档", c0), explain=ex)
            if multi_c:
                d.subhead("各学科班际差异")
                rows, rng, info_r = [], {}, {}
                for x in e.subjects:
                    avg = {k: e.subj_stats(e.in_class(k), x)["平均分"] for k in classes}
                    avg = {k: v for k, v in avg.items() if v is not None}
                    hk, lk = max(avg, key=lambda k: avg[k]), min(avg, key=lambda k: avg[k])
                    rng[x] = r1(avg[hk]) - r1(avg[lk])
                    info_r[x] = (hk, lk, rng[x])
                    rows.append([x, hk, f"{avg[hk]:.1f}", lk, f"{avg[lk]:.1f}", f"{rng[x]:.1f}"])
                bigx = max(rng, key=lambda x: rng[x])
                self.tab(d, "各学科班际均分差距", ["科目", "最高班", "均分", "最低班", "均分", "极差"], rows,
                         [2.6, 3.0, 2.8, 3.0, 2.8, 3.2], f"{src0}；极差 = 最高班均分 − 最低班均分。",
                         self.concl(scope, "学科班际", f"班际差距最大的是**{bigx}**（极差 {rng[bigx]:.1f} 分）"),
                         explain=self._exp_subj_range(info_r))
            d.subhead("分学科分析")
            cm = sa.get("学科点评") or {}
            for x in ss:
                d.subhead3(f"{x}：得分率 {fmt_pct(ss[x]['得分率'])}，及格率 {fmt_pct(ss[x]['及格率'])}")
                d.body(cm.get(x) or "")
            self.section_summary(d, sa, "学科")
        elif items:
            sec += 1
            d.heading(sec, "题型与小题")
            d.lead(self._lead_items(studs, bool(self._options(studs))))
            d.subhead("题型得分率与失分构成")
            if paper_sections(e):
                t, p_, cc = self.section_chart(scope, e.sec_rates(studs), w=17.4)
                self.fig(d, p_, "各题型得分率", f"{src0}；题型得分率 = 该题型得分之和 ÷（该题型满分 × 人数）。", cc,
                         explain=self._exp_sections(studs))
                lost, full = self._loss_by_section(studs)
                if sum(lost.values()) > 0:
                    secs = list(lost)
                    path = self.c.pie(secs, [round(lost[x], 1) for x in secs], SERIES[: len(secs)], unit="分")
                    c0, ex = self._lead_item(self._exp_loss(lost, full))
                    self.fig(d, path, "各题型失分构成", f"{src0}；失分 = 满分 − 得分，按全体学生合计。",
                             self.concl(scope, "失分构成", c0), width=12.0, explain=ex)
            else:
                d.placeholder("未提供题目档案，暂无题型得分率。")
            d.subhead("逐题得分率")
            qs_all = e.q_stats(studs)
            t, p_, cc = self.qrate_chart(scope, qs_all)
            self.fig(d, p_, "逐题得分率", f"{src0}；低于及格线的题标红。", cc, explain=self._exp_questions(qs_all))
            d.subhead("选择题选项分布")
            rows = self._options(studs)
            if rows:
                worst = max(rows, key=lambda r: max([c_ for o, c_, ok in r[1] if not ok and o != "未答"] or [0]))
                wseg = max([sg for sg in worst[1] if not sg[2] and sg[0] != "未答"], key=lambda sg: sg[1], default=None)
                self.fig(d, self.c.options([(r[0], r[1]) for r in rows]), "选择题选项分布", f"{src0}；绿色为正确选项。",
                         self.concl(scope, "选项", f"错选最集中：**{worst[0]}** 选 {wseg[0]} 的有 **{wseg[1]}** 人"
                                    if wseg else "选择题无错选"), explain=self._exp_options(rows))
            else:
                d.placeholder("录入时未记录学生选项，暂无选择题选项分布。")
            self.section_summary(d, sa, "题型")
        # 5 学生情况
        sec += 1
        d.heading(sec, "学生情况")
        d.lead(self._lead_students(studs, gap, multi_c, prev and rank_change))
        d.subhead("总分前十名")
        top = sorted([s for s in studs if ranks[s["key"]] <= 10], key=lambda s: (ranks[s["key"]], s["name"]))
        rows = [[str(ranks[s["key"]]), s["name"]] + ([s["class"]] if multi_c else []) +
                [fmt_score(s["total"]), fmt_pct(s["total"] / e.full)] for s in top]
        heads = ["名次", "姓名"] + (["班级"] if multi_c else []) + ["总分", "得分率"]
        if multi_c:
            cnt_c = defaultdict(int)
            for s in top:
                cnt_c[s["class"]] += 1
            bc = max(cnt_c, key=lambda k: (cnt_c[k], k))
            tc = self.concl(scope, "前十", f"前十名中**{bc}**占 **{cnt_c[bc]}** 人")
        else:
            tc = None
        self.tab(d, "总分前十名学生名单", heads, rows, self._fit([2.2], len(heads) - 1), f"{src0}；同分同名次。", tc,
                 explain=self._exp_top(top, ov, ranks, multi_c))
        if multi_c:
            d.subhead("各班前三名")
            rows, firsts = [], []
            for k in classes:
                st = e.in_class(k)
                rk = e.ranks(st)
                t3 = sorted([s for s in st if rk[s["key"]] <= 3], key=lambda s: (rk[s["key"]], s["name"]))
                rows.append([k, "、".join(f"{s['name']}（{fmt_score(s['total'])}）" for s in t3)])
                if t3:
                    firsts.append((k, t3[0]))
            self.tab(d, "各班总分前三名学生名单", ["班级", "前三名（总分）"], rows, [2.8, 14.6], f"{src0}；按班内名次。",
                     explain=self._exp_top3(firsts, ranks) if len(firsts) >= 2 else None,
                     align=["center", "left"])
        d.subhead("临界生与低分学生")
        rows, crit_n = [], {}
        same_ge = abs(e.line("良好线") - e.excel_line) < 1e-6
        for lab, key in (("及格临界", "及格线"), ("良好临界", "良好线"), ("优秀临界", "优秀线")):
            if key == "良好线" and same_ge:  # 良好线与优秀线相同时只列优秀临界
                continue
            ln = e.excel_line if key == "优秀线" else e.line(key)
            hit = sorted([s for s in studs if ln - gap - 1e-9 <= s["total"] < ln - 1e-9],
                         key=lambda s: (-s["total"], s["name"]))
            crit_n[lab] = hit
            rows.append([(lab, INK), f"{fmt_line(ln - gap)}–{fmt_line(ln)} 分（不含）", str(len(hit)),
                         "、".join(f"{self._who(s, multi_c)} {fmt_score(s['total'])}" for s in hit) or "无"])
        pc = crit_n.get("及格临界", [])
        if multi_c and pc:
            byc = defaultdict(int)
            for s in pc:
                byc[s["class"]] += 1
            bk = max(byc, key=lambda k: (byc[k], k))
            cdef = f"及格临界 **{len(pc)}** 人，最多的是{bk}（{byc[bk]} 人）"
        else:
            cdef = f"及格临界 **{len(pc)}** 人" if pc else "没有及格临界生"
        self.tab(d, f"临界生名单（线下 {fmt_line(gap)} 分以内）", ["类别", "分数段", "人数", "学生（总分）"], rows,
                 [2.2, 3.4, 1.4, 10.4], f"{src0}。", self.concl(scope, "临界", cdef),
                 explain=self._exp_critical(crit_n, gap, studs, multi_c), align=["center", "center", "center", "left"])
        ll = e.line("低分线")
        lows = sorted([s for s in studs if s["total"] < ll - 1e-9], key=lambda s: (s["total"], s["name"]))
        if multi_c:
            rows = []
            for k in classes:
                hk = [s for s in lows if s["class"] == k]
                rows.append([k, str(len(hk)), "、".join(f"{s['name']} {fmt_score(s['total'])}" for s in hk) or "无"])
            byc = {k: sum(1 for s in lows if s["class"] == k) for k in classes}
            bk = max(classes, key=lambda k: (byc[k], k))
            ldef = (f"低分学生 **{len(lows)}** 人，{bk}最多（{byc[bk]} 人）" if lows else "没有低分学生")
            self.tab(d, f"低分学生名单（总分低于 {fmt_line(ll)} 分）", ["班级", "人数", "学生（总分）"], rows,
                     [2.4, 1.4, 13.6], f"{src0}；按总分从低到高。", self.concl(scope, "低分", ldef),
                     explain=self._exp_low(lows, studs, classes, True), align=["center", "center", "left"])
            series = [(lab, [sum(1 for s in hit if s["class"] == k) for k in classes]) for lab, hit in crit_n.items()]
            series.append(("低分学生", [byc[k] for k in classes]))
            colors = [{"及格临界": WARN, "良好临界": TIER_RAMP5[2], "优秀临界": BLUE}[lab] for lab, _ in series[:-1]] + [CRIT]
            c0, ex = self._lead_item(self._exp_crit_bars(classes, crit_n, lows))
            self.fig(d, self.c.grouped_bars(classes, series, colors=colors), "各班临界生与低分学生人数",
                     f"{src0}；临界生为线下 {fmt_line(gap)} 分以内。", self.concl(scope, "临界分布", c0), explain=ex)
        else:
            self.tab(d, f"低分学生名单（总分低于 {fmt_line(ll)} 分）", ["人数", "学生（总分）"],
                     [[str(len(lows)), "、".join(f"{s['name']} {fmt_score(s['total'])}" for s in lows) or "无"]],
                     [2.0, 15.4], f"{src0}；按总分从低到高。",
                     self.concl(scope, "低分", f"低分学生 **{len(lows)}** 人" if lows else "没有低分学生"),
                     explain=self._exp_low(lows, studs, classes, False), align=["center", "left"])
        if prev and rank_change:
            d.subhead("名次进退")
            up = sorted([s for s in studs if rank_change.get(s["key"], 0) > 0],
                        key=lambda s: (-rank_change[s["key"]], s["name"]))[:5]
            dn = sorted([s for s in studs if rank_change.get(s["key"], 0) < 0],
                        key=lambda s: (rank_change[s["key"]], s["name"]))[:5]
            rows = []
            for i in range(max(len(up), len(dn), 1)):
                a = up[i] if i < len(up) else None
                b = dn[i] if i < len(dn) else None
                rows.append([self._who(a, multi_c) if a else "—", (f"▲ {rank_change[a['key']]}", GOOD) if a else "",
                             self._who(b, multi_c) if b else "—", (f"▼ {-rank_change[b['key']]}", CRIT) if b else ""])
            pname = prev[0].get("name") or prev[0].get("exam_id")
            self.tab(d, "进步与退步前五名", ["进步", "名次变化", "退步", "名次变化"], rows, [5.2, 3.5, 5.2, 3.5],
                     f"数据来源：{name}与{pname}成绩；名次按本报告范围排序。",
                     explain=self._exp_progress(studs, rank_change))
            pts = [(ranks[k] + v, ranks[k]) for k, v in rank_change.items()]
            nmax = max([n] + [a for a, _ in pts])
            byk = {s["key"]: s for s in studs}
            notes = []  # 标注名次变化最大的学生，彼此离得太近的跳过，避免名字叠在一起
            for k in sorted(rank_change, key=lambda k: (-abs(rank_change[k]), byk[k]["name"])):
                x, y = ranks[k] + rank_change[k], ranks[k]
                if all(abs(x - a) + abs(y - b) > nmax * 0.12 for a, b, _ in notes):
                    notes.append((x, y, byk[k]["name"]))
                if len(notes) == 4:
                    break
            c0, ex = self._lead_item(self._exp_rank_scatter(studs, rank_change))
            self.fig(d, self.c.rank_scatter(tuple(pts), nmax, tuple(notes)), "本次与上次名次对比",
                     f"数据来源：{name}与{pname}成绩；横轴为上次名次，纵轴为本次名次，虚线上方为进步，标注的是名次变化较大的 {len(notes)} 人。",
                     self.concl(scope, "名次散点", c0), width=10.0, explain=ex)
        self.section_summary(d, sa, "学生")
        # 补充分析
        extra = self.extra_blocks(scope)
        if extra:
            sec += 1
            d.heading(sec, "补充分析")
            self.render_extra(d, extra)
        # 主要问题 / 教学建议
        sec += 1
        d.heading(sec, "存在的主要问题")
        d.body("综合本次考试数据，主要存在以下问题：", keep=True)
        self._numbered(d, sa.get("问题") or [])
        sec += 1
        d.heading(sec, "教学建议")
        d.body("针对上述问题，对下一阶段教学工作提出以下建议：", keep=True)
        self._numbered(d, sa.get("建议") or [])
        sign = "".join(x for x in (e.cfg.get("学校") or "", e.cfg.get("编制部门") or "") if x)
        if sign:
            d.signature([sign] + ([e.cfg["编制日期"]] if e.cfg.get("编制日期") else []))
        # 附录：成绩单（不强制另起一页，避免上一页留下大片空白）
        d.plain_heading("附录　成绩单")
        cols = list(e.subjects) if e.has_subj else (e.sections if e.has_q else [])
        heads = ["名次", "姓名"] + (["班级"] if multi_c else []) + ["总分", "得分率"] + cols + (["名次变化"] if prev else [])
        fixed = [1.1, 1.9] + ([1.6] if multi_c else []) + [1.4, 1.6]
        widths = self._fit(fixed, len(cols) + (1 if prev else 0), lo=1.1) if (cols or prev) else None
        if widths is None:
            widths = fixed[:]
            widths[1] += LAYOUT_W - sum(widths)
        rows = []
        for s in sorted(studs, key=lambda s: (ranks[s["key"]], s["class"], s["name"])):
            if e.has_subj:
                vals = ["缺考" if s["subj"][x] is None else fmt_score(s["subj"][x]) for x in cols]
            else:
                vals = [fmt_score(sum(v for v in (s["scores"][q["qid"]] for q in e.questions if q["section"] == x)
                                      if v is not None)) for x in cols]
            r_ = [str(ranks[s["key"]]), s["name"] + (" *" if s.get("flag") else "")] + ([s["class"]] if multi_c else []) + \
                [fmt_score(s["total"]), fmt_pct(s["total"] / e.full)] + vals
            if prev:
                ch = rank_change.get(s["key"])
                r_.append("新" if ch is None else ((f"▲{ch}", GOOD) if ch > 0 else ((f"▼{-ch}", CRIT) if ch < 0 else "—")))
            rows.append(r_)
        self.tab(d, "学生成绩单", heads, rows, widths, f"{src0}；姓名后带 * 表示信息待确认" +
                 ("；“新”表示上一场无记录" if prev else "") + "。", font=8)
        # 说明
        flags = [f"{s['name']}（{s['flag']}）" for s in studs if s.get("flag")]
        notes = [f"数据来源：{os.path.basename(e.dataset_path)}（实考 {n} 人）；统计口径见“1.{3 if (e.has_subj or (e.questions and paper_sections(e))) else 2}　统计口径”。",
                 "报告摘要、本节小结、分学科分析、主要问题与教学建议由分析人员填写；其余文字与全部数字由成绩数据计算生成。"]
        miss = [f"{s['name']}（{'、'.join(str(q['no']) for q in e.missing(s))}题）" for s in studs if e.missing(s)]
        if miss:
            notes.append("得分缺失、未计入统计：" + "；".join(miss))
        notes.append("待确认：" + ("；".join(flags) if flags else "无"))
        d.notes(notes)
        return d

    # ---- 试卷分析报告（第三种模板）
    @staticmethod
    def _p_level(p):
        return "较易" if p >= 0.7 - 1e-9 else ("适中" if p >= 0.4 - 1e-9 else "偏难")

    @staticmethod
    def _d_level(dv):
        return "很好" if dv >= 0.4 - 1e-9 else ("较好" if dv >= 0.3 - 1e-9 else ("尚可" if dv >= 0.2 - 1e-9 else "较差"))

    def _quality(self, studs):
        """试卷质量指标（只用总分即可算）：难度系数 P = 平均分 ÷ 满分；区分度 D = （前 27% 平均分 − 后 27% 平均分）÷ 满分；
        标准差；偏度（三阶矩，>0 低分集中、高分拖尾）。"""
        e = self.e
        t = sorted((s["total"] for s in studs), reverse=True)
        n = len(t)
        avg = sum(t) / n
        k = max(1, round(n * 0.27))
        top, bot = sum(t[:k]) / k, sum(t[-k:]) / k
        sd = statistics.pstdev(t)
        skew = (sum((x - avg) ** 3 for x in t) / n) / sd ** 3 if sd else 0.0
        return {"P": avg / e.full, "D": (top - bot) / e.full, "k": k, "top": top, "bot": bot, "sd": sd, "skew": skew,
                "avg": avg}

    def _item_quality(self, studs):
        """逐题难度（该题平均得分 ÷ 该题满分）与区分度（按总分分前 27% / 后 27% 两组，两组该题平均分之差 ÷ 该题满分）。"""
        e = self.e
        order = sorted(studs, key=lambda s: -s["total"])
        k = max(1, round(len(order) * 0.27))
        hi, lo = order[:k], order[-k:]
        out = []
        for q in e.questions:
            def mean(ss):
                v = [s["scores"].get(q["qid"]) for s in ss if s["scores"].get(q["qid"]) is not None]
                return sum(v) / len(v) if v else None
            m, mh, ml = mean(studs), mean(hi), mean(lo)
            if m is None or not q["max"]:
                continue
            out.append((q, m, m / q["max"], ((mh or 0) - (ml or 0)) / q["max"]))
        return out

    def _lead_paper_overall(self, ov, n, absent_n, multi_c):
        s1 = ("本节从核心指标、总分分数段" + ("和各班对比" if multi_c else "") + "看本次考试的整体情况。")
        below = 1 - ov["及格率"]
        s2 = (f"实考 {n} 人" + (f"（缺考 {absent_n} 人）" if absent_n else "") +
              f"，平均分 {ov['平均分']:.1f} 分，及格率 **{fmt_pct(ov['及格率'])}**，"
              + (f"及格线以下的学生占 {fmt_pct(below)}，整体处在及格线以下。" if below > 0.5 else
                 f"多数学生达到及格线（及格线以下占 {fmt_pct(below)}）。"))
        return s1 + s2

    def _lead_paper_classes(self, classes):
        e = self.e
        if len(classes) == 1:
            o = e.overall(e.in_class(classes[0]))
            return (f"本节列出{classes[0]}的分档结构、分层名单、临界生和学情分析。"
                    f"全班 {o['人数']} 人，人数最多的一档是{e.tier_names()[max(range(len(o['分档人数'])), key=lambda i: (o['分档人数'][i], -i))]}。")
        ovs = {k: e.overall(e.in_class(k)) for k in classes}
        hi = max(classes, key=lambda k: ovs[k]["平均分"])
        lo = min(classes, key=lambda k: ovs[k]["平均分"])
        dlt = r1(ovs[hi]["平均分"]) - r1(ovs[lo]["平均分"])
        return (f"本节逐班列出分档结构、分层名单、临界生和学情分析。{hi}平均分最高、{lo}最低，相差 **{dlt:.1f}** 分，"
                f"约为满分的 {dlt / e.full * 100:.0f}%。")

    def _lead_paper_items(self, q):
        e = self.e
        s1 = "本节从试卷结构、试卷质量指标" + ("和逐题得分" if e.has_q else "") + "看试卷本身与学生的作答。"
        return s1 + (f"全卷难度系数 **{q['P']:.2f}**（{self._p_level(q['P'])}），区分度 {q['D']:.2f}"
                     f"（{self._d_level(q['D'])}）。")

    def _exp_quality(self, q, classes):
        e = self.e
        out = [("难度", f"全卷平均分 {q['avg']:.1f} 分，难度系数 P = 平均分 ÷ 满分 = **{q['P']:.2f}**，属于{self._p_level(q['P'])}"
                       "（0.7 以上较易、0.4–0.7 适中、0.4 以下偏难）。"),
               ("区分度", f"按总分取前 27% 与后 27% 各 {q['k']} 人，两组平均分分别为 {q['top']:.1f} 分和 {q['bot']:.1f} 分，"
                        f"相差 {q['top'] - q['bot']:.1f} 分，区分度 D = **{q['D']:.2f}**，{self._d_level(q['D'])}"
                        "（0.4 以上很好、0.3–0.39 较好、0.2–0.29 尚可、0.2 以下较差）。")]
        cv = q["sd"] / e.full if e.full else 0
        shape = ("分数集中在低分段、高分段拖尾（正偏）" if q["skew"] > 0.5 else
                 ("分数集中在高分段、低分段拖尾（负偏）" if q["skew"] < -0.5 else "分数分布大致对称"))
        out.append(("分布形态", f"标准差 {q['sd']:.1f} 分，约为满分的 {cv * 100:.0f}%；偏度 {q['skew']:.2f}，{shape}。"))
        if len(classes) >= 2:
            ps = [(k, self._quality(e.in_class(k))["P"]) for k in classes]
            out.append(("各班难度", "按各班平均分算的难度系数：" + "、".join(f"{k} {p:.2f}" for k, p in ps) +
                        "；同一份试卷，班级之间的差别反映的是学生水平的差距。"))
        return out

    def _exp_items_quality(self, rows):
        bad = [r for r in rows if r[3] < 0.2 - 1e-9]
        hard = [r for r in rows if r[2] < 0.4 - 1e-9]
        good = [r for r in rows if r[3] >= 0.4 - 1e-9]
        out = [("难度分布", f"偏难（P < 0.4）的有 {len(hard)} 题" + (f"：{self._list(qno_label(r[0]) for r in hard)}" if hard else "")
                         + f"；适中 {sum(1 for r in rows if 0.4 - 1e-9 <= r[2] < 0.7 - 1e-9)} 题；"
                           f"较易（P ≥ 0.7）{sum(1 for r in rows if r[2] >= 0.7 - 1e-9)} 题。")]
        out.append(("区分度", f"区分度很好（D ≥ 0.4）的有 {len(good)} 题；" +
                    (f"较差（D < 0.2）的有 {len(bad)} 题：{self._list(qno_label(r[0]) for r in bad)}，"
                     "这些题高分组与低分组得分接近，区分不同水平学生的能力弱。" if bad else "没有区分度低于 0.2 的题。")))
        both = [r for r in rows if r[2] < 0.4 - 1e-9 and r[3] < 0.2 - 1e-9]
        if both:
            out.append(("又难又不区分", f"{self._list(qno_label(r[0]) for r in both)}难度低于 0.4、区分度低于 0.2，"
                                    "高分组和低分组都普遍失分。"))
        return out

    def _exp_one_class(self, cls, ovc, ov_all, multi_c):
        e = self.e
        names = e.tier_names()
        cnt, n = ovc["分档人数"], ovc["人数"]
        out = [("分档结构", "、".join(f"{names[i]} {cnt[i]} 人（{fmt_pct(cnt[i] / n)}）"
                                    for i in reversed(range(len(cnt))) if cnt[i]) + "。")]
        if multi_c:
            dv = r1(ovc["平均分"]) - r1(ov_all["平均分"])
            out.append(("与合计比", f"平均分 {ovc['平均分']:.1f} 分，比合计{'高' if dv >= 0 else '低'} {abs(dv):.1f} 分；"
                                  f"及格率 {fmt_pct(ovc['及格率'])}（合计 {fmt_pct(ov_all['及格率'])}）。"))
        med, ll = ovc["中位数"], e.line("低分线")
        if med >= e.pass_line - 1e-9:
            tail = "一半以上学生达到及格线。"
        elif med < ll - 1e-9:
            tail = f"低于低分线 {fmt_line(ll)} 分，一半以上学生总分在低分线以下。"
        else:
            tail = f"在低分线与及格线之间，比及格线低 {fmt_score(e.pass_line - med)} 分。"
        out.append(("中位数", f"中位数 {fmt_score(med)} 分，{tail}"))
        return out

    def _exp_crit_one(self, studs, gap):
        e = self.e
        n = len(studs)
        out = []
        for name, line in (("及格", e.pass_line), ("优秀", e.excel_line)):
            now = sum(s["total"] >= line - 1e-9 for s in studs)
            k = sum(line - gap - 1e-9 <= s["total"] < line - 1e-9 for s in studs)
            far = sum(s["total"] < line - gap - 1e-9 for s in studs)
            if k:
                out.append((f"{name}临界", f"{name}线下 {fmt_score(gap)} 分以内 {k} 人，全部跨线后{name}率由 {fmt_pct(now / n)} "
                                          f"升到 **{fmt_pct((now + k) / n)}**。"))
            elif name == "及格":
                top = max(s["total"] for s in studs)
                extra = (f"本班最高分 {fmt_score(top)} 分，离及格线还差 {fmt_score(line - top)} 分，"
                         "短期内以提高平均分、降低低分率为主。" if now == 0 else "")
                out.append(("及格临界", f"及格线下 {fmt_score(gap)} 分以内没有学生；及格线以下的 {far} 人离及格线都超过 "
                                       f"{fmt_score(gap)} 分。{extra}" if far else "全班都达到及格线。"))
        return out

    def _compare_block(self, d, classes, scope):
        """多班对比：各班指标对比表 + 各班分数段分组柱状图。"""
        e = self.e
        rows, ovs = [], {}

        def row(lab, o, ab):
            return [lab, str(o["人数"]), str(ab), f"{o['平均分']:.1f}", fmt_score(o["中位数"]), fmt_score(o["最高分"]),
                    fmt_score(o["最低分"]), f"{o['标准差']:.1f}", fmt_pct(o["及格率"]), fmt_pct(o["优秀率"])]
        for c in classes:
            o = ovs[c] = e.overall(e.in_class(c))
            rows.append(row(c, o, len(self.absent_in([c]))))
        allst = [s for c in classes for s in e.in_class(c)]
        o = e.overall(allst)
        rows.append(row(("合计", INK), o, len(self.absent_in(classes))))
        hi = max(classes, key=lambda c: ovs[c]["平均分"])
        lo = min(classes, key=lambda c: ovs[c]["平均分"])
        concl = (self.concl(scope, "各班平均分", f"平均分最高的是**{hi}**，比{lo}高 **{r1(ovs[hi]['平均分']) - r1(ovs[lo]['平均分']):.1f}** 分")
                 if hi != lo else None)
        d.subhead("各班指标对比")
        d.ctable("各班成绩指标对比", ["班级", "参考人数", "缺考", "平均分", "中位数", "最高分", "最低分", "标准差", "及格率", "优秀率"],
                 rows, [2.2, 1.7, 1.3, 1.7, 1.7, 1.7, 1.7, 1.7, 1.8, 1.9], source=f"{self.src(len(allst))}；标准差为总体标准差。",
                 after=[("concl", concl), ("exp", self._exp_class_table(classes, ovs))])
        names = e.tier_names()
        series = [(c, ovs[c]["分档人数"]) for c in classes]
        path = self.c.grouped_bars(names, series)
        share = {c: ovs[c]["分档人数"][0] / ovs[c]["人数"] for c in classes if ovs[c]["人数"]}
        worst = max(share, key=lambda c: share[c])
        d.subhead("各班分数段分布")
        d.chart("各班分数段人数分布", path,
                self.concl(scope, "各班分档", f"**{worst}** {names[0]}占比最高（{share[worst] * 100:.1f}%）"),
                source=f"{self.src(len(allst))}；分档：{self.tier_desc()}。", explain=self._exp_class_tiers(classes, ovs))

    def _layer_table(self, d, studs, cls):
        """分层名单：按分档从高到低，列出人数、占比和学生（总分）。"""
        e = self.e
        names = e.tier_names()
        n = len(studs) or 1
        auto = getattr(e, "tier_names_auto", False)
        rows = []
        for i in reversed(range(len(names))):
            hit = sorted([s for s in studs if e.tier_of(s["total"]) == i], key=lambda s: (-s["total"], s["name"]))
            row = [(names[i], INK)] + ([] if auto else [e.tier_range(i)]) + [
                str(len(hit)), fmt_pct(len(hit) / n), "、".join(f"{s['name']} {fmt_score(s['total'])}" for s in hit) or "无"]
            rows.append(row)
        cap = f"{cls}学生分层名单"
        if auto:
            d.ctable(cap, ["分数段", "人数", "占比", "学生（总分）"], rows, [2.6, 1.4, 1.8, 11.6],
                     align=["center", "center", "center", "left"], source=self.src(len(studs)))
        else:
            d.ctable(cap, ["层次", "分数区间", "人数", "占比", "学生（总分）"], rows, [2.2, 3.2, 1.4, 1.8, 8.8],
                     align=["center", "center", "center", "center", "left"], source=self.src(len(studs)))

    def _critical(self, d, studs, cls):
        """临界生（试卷分析报告用：及格线、优秀线）。"""
        e = self.e
        gap = e.cfg["临界分差"] * e.full
        crit_rows = []
        for lab, line in (("及格临界", e.pass_line), ("优秀临界", e.excel_line)):
            hit = sorted([s for s in studs if line - gap - 1e-9 <= s["total"] < line - 1e-9], key=lambda s: -s["total"])
            crit_rows.append([(lab, INK), f"线 {fmt_score(line)} 分",
                              "、".join(f"{s['name']} {fmt_score(s['total'])}" for s in hit) or "无"])
        d.ctable(f"{cls}临界生名单（线下 {fmt_score(gap)} 分以内）", ["类别", "分数线", "学生（总分）"], crit_rows,
                 [2.4, 2.4, 12.6], align=["center", "center", "left"], source=self.src(len(studs)),
                 after=[("exp", self._exp_crit_one(studs, gap))])
        return gap

    @staticmethod
    def _ranges(nos):
        """题号压缩：1,2,3,5 → 1–3、5。"""
        out, start, prev = [], None, None
        for x in nos:
            if start is None:
                start = prev = x
            elif isinstance(x, int) and isinstance(prev, int) and x == prev + 1:
                prev = x
            else:
                out.append(f"{start}–{prev}" if start != prev else f"{start}")
                start = prev = x
        if start is not None:
            out.append(f"{start}–{prev}" if start != prev else f"{start}")
        return "、".join(out)

    def _paper_structure(self, d):
        e = self.e
        d.subhead("试卷结构")
        if not e.questions:
            d.placeholder("未提供题目档案，无法列出试卷结构。")
            return
        d.ctable("试卷结构", ["题型", "题号", "题量", "分值", "占满分"], self._structure_rows(), [3.6, 5.2, 2.6, 3.0, 3.0],
                 source="数据来源：题目档案。", after=[("exp", self._exp_structure())])

    def _paper_quality(self, d, scope, studs, classes, q):
        e = self.e
        d.subhead("试卷质量指标")
        cv = q["sd"] / e.full if e.full else 0
        rows = [["难度系数 P", f"{q['P']:.2f}", "≥0.7 较易；0.4–0.7 适中；<0.4 偏难", (self._p_level(q["P"]), INK)],
                ["区分度 D", f"{q['D']:.2f}", "≥0.4 很好；0.3–0.39 较好；0.2–0.29 尚可；<0.2 较差", (self._d_level(q["D"]), INK)],
                ["标准差", f"{q['sd']:.1f} 分（满分的 {cv * 100:.0f}%）", "≥15% 较大；10%–15% 中等；<10% 较小",
                 ("较大" if cv >= 0.15 else ("较小" if cv < 0.10 else "中等"), INK)],
                ["偏度", f"{q['skew']:.2f}", ">0.5 正偏（低分集中）；<−0.5 负偏（高分集中）",
                 ("正偏" if q["skew"] > 0.5 else ("负偏" if q["skew"] < -0.5 else "近似对称"), INK)]]
        d.ctable("试卷质量指标", ["指标", "数值", "参考标准", "评价"], rows, [3.0, 3.6, 8.2, 2.6],
                 align=["center", "center", "left", "center"],
                 source=f"{self.src(len(studs))}；区分度按总分前 27% 与后 27% 两组（各 {q['k']} 人）的平均分之差 ÷ 满分。",
                 after=[("exp", self._exp_quality(q, classes))])
        if not e.has_q:
            return
        items = self._item_quality(studs)
        if not items:
            return
        d.subhead("逐题难度与区分度")
        rows = [[str(it[0]["no"]), it[0]["section"], fmt_score(it[0]["max"]), f"{it[1]:.1f}", f"{it[2]:.2f}", f"{it[3]:.2f}",
                 f"{self._p_level(it[2])}，区分{self._d_level(it[3])}"] for it in items]
        d.ctable("逐题难度与区分度", ["题号", "题型", "分值", "平均分", "难度", "区分度", "评价"], rows,
                 [1.4, 2.4, 1.6, 2.0, 1.8, 1.8, 6.4], align=["center"] * 6 + ["left"],
                 source=f"{self.src(len(studs))}；难度 = 该题平均分 ÷ 该题满分，区分度按总分前、后 27% 两组计算。")
        secs = list(OrderedDict.fromkeys(it[0]["section"] for it in items))
        pts = tuple((str(it[0]["no"]), round(it[2], 3), round(it[3], 3), secs.index(it[0]["section"])) for it in items)
        ex = self._exp_items_quality(items)
        c0, rest = self._lead_item(ex)
        self.fig(d, self.c.quality_scatter(pts, tuple(secs)), "逐题难度与区分度分布",
                 f"{self.src(len(studs))}；横轴为难度（越靠右越容易），纵轴为区分度，虚线为 0.4、0.7 与 0.2、0.4 分界。",
                 self.concl(scope, "难度区分", c0), width=13.0, explain=rest)

    def paper_report(self, classes):
        e = self.e
        scope = "+".join(classes)
        pa = (self.a.get("试卷分析") or {}).get(scope) or {}
        allst = [s for c in classes for s in e.in_class(c)]
        multi_c = len(classes) >= 2
        name = e.meta.get("name") or e.exam_id
        subj = e.meta.get("subject") or e.cfg.get("科目") or ""
        d = self.D(self.font, self.header_text("试卷分析报告"), self.layout)
        # 封面
        title = f"{name}{'' if (not subj or subj in name or subj == '多科') else subj}试卷分析报告"
        lines = [f"参考班级：{'、'.join(classes)}" + (f"（共 {len(classes)} 个班）" if multi_c else ""),
                 f"考试科目：{subj or '—'}（满分 {fmt_score(e.full)} 分）"]
        if e.meta.get("date"):
            lines.append(f"考试日期：{e.meta['date']}")
        foot = ([f"编制部门：{e.cfg['编制部门']}"] if e.cfg.get("编制部门") else []) + \
               ([f"编制日期：{e.cfg['编制日期']}"] if e.cfg.get("编制日期") else [])
        d.cover(e.cfg.get("学校") or "", title, lines, foot)
        # 报告摘要
        d.plain_heading("报告摘要")
        summ = pa.get("摘要") or {}
        for k in paper_summary_parts(classes):
            d.body(summ.get(k) or "")
        sa = pa.get("小结") or {}
        sec = 1
        # 1 考情分析
        d.heading(sec, "考情分析")
        ov = e.overall(allst)
        absent_n = len(self.absent_in(classes))
        gap = e.cfg["临界分差"] * e.full
        d.lead(self._lead_paper_overall(ov, len(allst), absent_n, multi_c))
        d.subhead("核心指标")
        d.kpi_rows([[(None, str(len(allst)), "参考人数"), (None, f"{ov['平均分']:.1f}", "平均分"),
                     (None, fmt_score(ov["中位数"]), "中位数"), (None, fmt_score(ov["最高分"]), "最高分"),
                     (None, fmt_score(ov["最低分"]), "最低分"), (None, f"{ov['标准差']:.1f}", "标准差")],
                    [(None, fmt_pct(ov["得分率"]), "得分率"), (None, fmt_pct(ov["优秀率"]), f"优秀率（≥{fmt_line(e.excel_line)}分）"),
                     (None, fmt_pct(ov["良好率"]), f"良好率（≥{fmt_line(e.line('良好线'))}分）"),
                     (None, fmt_pct(ov["及格率"]), f"及格率（≥{fmt_line(e.pass_line)}分）"),
                     (None, fmt_pct(ov["低分率"]), f"低分率（<{fmt_line(e.line('低分线'))}分）"), (None, str(absent_n), "缺考人数")]],
                   explain=self._exp_overall(ov, allst, gap), caption="考情核心指标",
                   source=f"{self.src(len(allst))}，满分 {fmt_score(e.full)} 分；标准差为总体标准差。")
        d.subhead("总分分数段分布")
        self.hist_figure(d, scope, allst, explain=self._exp_hist(allst, self.hist_data(allst)[0]))
        if multi_c:
            self._compare_block(d, classes, scope)
        else:
            d.subhead("学生分档")
            t, p, c = self.tiers_chart(scope, ov, w=12)
            d.chart(t, p, c, width=12, source=f"{self.src(len(allst))}；分档：{self.tier_desc()}。",
                    explain=self._exp_tier_share(ov))
        self.section_summary(d, {"小结": sa}, "考情")
        # 2 班级学情分析
        sec += 1
        d.heading(sec, "班级学情分析")
        d.lead(self._lead_paper_classes(classes))
        ca = pa.get("班级分析") or {}
        for cls in classes:
            studs = e.in_class(cls)
            ovc = e.overall(studs)
            d.subhead(f"{cls}（{ovc['人数']} 人）")
            d.subhead3("学生分档")
            t, p, c = self.tiers_chart(cls, ovc, w=12)
            d.chart(f"{cls}学生分档人数", p, c, width=12, source=self.src(len(studs)),
                    explain=self._exp_one_class(cls, ovc, ov, multi_c))
            d.subhead3("分层名单")
            self._layer_table(d, studs, cls)
            d.subhead3("临界生")
            gap = self._critical(d, studs, cls)
            d.subhead3("学情分析")
            d.body(ca.get(cls) or "")
            d.subhead3("提升建议")
            self._numbered(d, ((pa.get("班级提升") or {}).get(cls)) or [])
        if multi_c:
            self.section_summary(d, {"小结": sa}, "班级")
        # 3 试卷分析
        sec += 1
        d.heading(sec, "试卷分析")
        q = self._quality(allst)
        d.lead(self._lead_paper_items(q))
        self._paper_structure(d)
        self._paper_quality(d, scope, allst, classes, q)
        if e.has_q:
            secs = paper_sections(e)
            src = self.src(len(allst))
            if secs:
                d.subhead("题型得分率与失分构成")
                if multi_c:
                    srs = [(c, [e.sec_rates(e.in_class(c)).get(x) for x in secs]) for c in classes]
                    d.chart("各班题型得分率", self.c.multi_hbars(secs, srs), "", source=src,
                            explain=self._exp_sections(allst))
                else:
                    t, p, c = self.section_chart(scope, e.sec_rates(allst), w=17.4)
                    d.chart(t, p, c, source=src, explain=self._exp_sections(allst))
                lost, full = self._loss_by_section(allst)
                if sum(lost.values()) > 0:
                    path = self.c.pie(secs, [round(lost[x], 1) for x in secs], SERIES[: len(secs)], unit="分")
                    c0, ex = self._lead_item(self._exp_loss(lost, full))
                    d.chart("各题型失分构成", path, self.concl(scope, "失分构成", c0), width=12.0,
                            source=f"{src}；失分 = 满分 − 得分，按全体学生合计。", explain=ex)
            d.subhead("逐题得分率")
            qs = e.q_stats(allst)
            t, p, c = self.qrate_chart(scope, qs)
            d.chart(t, p, c, source=f"{src}；低于及格线的题标红。", explain=self._exp_questions(qs))
            n = int(e.cfg["高频错题TopN"])
            wrong = [x for x in e.questions if qs[x["qid"]]["得分率"] is not None and qs[x["qid"]]["得分率"] < 1 - 1e-9]
            top = sorted(wrong, key=lambda x: (qs[x["qid"]]["得分率"], x["no"]))[:n]
            if top:
                labels = [f"{qno_label(x)} {short(x['kps'][0], 8)}" for x in top]
                path = self.c.hbars(labels, [qs[x["qid"]]["得分率"] for x in top], w=17.4, color=CRIT, stem="topn")
                d.chart(f"得分率最低的 {len(top)} 题", path,
                        self.concl(scope, "高频", f"得分率最低的是**{qno_label(top[0])}**"), source=src)
            sr = e.sec_rates(allst)
            rows = [[x, fmt_pct(sr.get(x)), (pa.get("失分点") or {}).get(x, "")] for x in secs]
            d.subhead("各题型失分点")
            d.ctable("各题型失分点", ["题型", "得分率", "失分点"], rows, [3.0, 2.2, 12.2], align=["center", "center", "left"],
                     source=f"{src}；失分点由分析人员填写。")
        else:
            d.placeholder("成绩表只有总分、没有逐题得分：无法分析各题型得分、逐题难度与失分点，以上难度与区分度按总分计算。"
                          "如需逐题分析，请提供小题分（答题卡明细）。")
        self.section_summary(d, {"小结": sa}, "试卷")
        # 补充分析
        extra = self.extra_blocks(scope)
        if extra:
            sec += 1
            d.heading(sec, "补充分析")
            self.render_extra(d, extra)
        # 改进计划
        sec += 1
        d.heading(sec, "改进计划")
        plan = pa.get("改进计划") or {}
        for part in PLAN_PARTS:
            d.subhead(part)
            self._numbered(d, plan.get(part) or [])
        sign = "".join(x for x in (e.cfg.get("学校") or "", e.cfg.get("编制部门") or "") if x)
        if sign:
            d.signature([sign] + ([e.cfg["编制日期"]] if e.cfg.get("编制日期") else []))
        d.notes(self.notes_lines(allst, [
            f"分层：按分数段划分，名单按总分从高到低；临界生指总分低于及格线或优秀线、差距在 {fmt_score(gap)} 分以内。",
            "难度系数 = 平均分 ÷ 满分；区分度 = （总分前 27% 学生平均分 − 后 27% 学生平均分）÷ 满分；偏度为三阶标准矩。",
            "报告摘要、本节小结、班级学情分析、提升建议、各题型失分点与改进计划由分析人员填写；"
            "其余文字与全部数字由成绩数据计算生成。"]))
        return d


# ---------------------------------------------------------------- 渲染入口

def lo_profile(prof):
    """临时 LibreOffice 配置：图表图片无损压缩、不降分辨率（默认会转成 JPEG，图里的字发虚）；
    再写入字体替换表（见 font_substitutes）。"""
    subs = font_substitutes()
    os.makedirs(os.path.join(prof, "user"), exist_ok=True)
    export = "".join(
        f'<item oor:path="/org.openoffice.Office.Common/Filter/PDF/Export"><prop oor:name="{k}" oor:op="fuse">'
        f'<value>{v}</value></prop></item>' for k, v in (("UseLosslessCompression", "true"),
                                                          ("ReduceImageResolution", "false")))
    pairs = export + "".join(
        f'<item oor:path="/org.openoffice.Office.Common/Font/Substitution/FontPairs"><node oor:name="_{i}" oor:op="replace">'
        '<prop oor:name="Always" oor:op="fuse"><value>true</value></prop>'
        '<prop oor:name="OnScreenOnly" oor:op="fuse"><value>false</value></prop>'
        f'<prop oor:name="ReplaceFont" oor:op="fuse"><value>{html.escape(a)}</value></prop>'
        f'<prop oor:name="SubstituteFont" oor:op="fuse"><value>{html.escape(b)}</value></prop></node></item>'
        for i, (a, b) in enumerate(sorted(subs.items())))
    with open(os.path.join(prof, "user", "registrymodifications.xcu"), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<oor:items xmlns:oor="http://openoffice.org/2001/registry" '
                'xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
                '<item oor:path="/org.openoffice.Office.Common/Font/Substitution"><prop oor:name="Replacement" '
                f'oor:op="fuse"><value>true</value></prop></item>{pairs}</oor:items>\n')


def convert_pdf(docx_paths, out_dir):
    soffice = find_soffice()
    if not soffice:
        raise ReportError(NO_SOFFICE, 3)
    with tempfile.TemporaryDirectory() as prof:
        lo_profile(prof)
        for i in range(0, len(docx_paths), 40):
            cmd = [soffice, f"-env:UserInstallation=file://{prof}", "--headless", "--convert-to", "pdf",
                   "--outdir", out_dir] + docx_paths[i:i + 40]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
            if res.returncode != 0:
                raise ReportError(f"PDF 转换失败：{res.stderr.strip()[:300]}", 3)
    outs = [os.path.join(out_dir, os.path.splitext(os.path.basename(p))[0] + ".pdf") for p in docx_paths]
    missing = [p for p in outs if not os.path.exists(p)]
    if missing:
        raise ReportError(f"PDF 未生成：{missing[:3]}", 3)
    return outs


NO_ITEM_SCORES = ("错题分析报告需要逐题得分，当前成绩表只有总分（或只有各科成绩）。"
                  "可改出成绩分析报告（--type score）或试卷分析报告（--type paper），或补充小题分后再出错题分析。")
NO_SOFFICE = "未找到 LibreOffice（soffice），无法导出 PDF；可改出 Word 或 HTML（--format word / html）。"
NO_PDF_ENGINE = ("无法导出 PDF：环境里既没有 LibreOffice（soffice），也没有可用的 WeasyPrint。"
                 "可改出 Word 或 HTML（--format word / html），或安装其中一个后重试（pip install weasyprint）。")


def has_weasyprint():
    try:
        import weasyprint
        return bool(weasyprint.HTML)
    except Exception:  # 未安装，或缺少 pango 等系统库
        return False


def pick_pdf_engine(pref):
    """auto：LibreOffice 优先（由 Word 转换），没有则用 WeasyPrint（由脚本生成的 HTML 转换）。"""
    pref = (pref or "auto").strip().lower()
    if pref in ("libreoffice", "soffice", "lo"):
        if not find_soffice():
            raise ReportError("指定了 LibreOffice，但环境里没有 soffice。可改用 --pdf-engine weasyprint 或 auto。", 3)
        return "libreoffice"
    if pref == "weasyprint":
        if not has_weasyprint():
            raise ReportError("指定了 WeasyPrint，但不可用（pip install weasyprint）。可改用 --pdf-engine auto。", 3)
        return "weasyprint"
    if pref != "auto":
        raise ReportError(f"未知的 PDF 引擎：{pref}。可选 auto / libreoffice / weasyprint。", 2)
    if find_soffice():
        return "libreoffice"
    if has_weasyprint():
        return "weasyprint"
    raise ReportError(NO_PDF_ENGINE, 3)


def _weasy_one(job):
    html_path, pdf_path = job
    import logging
    import weasyprint
    logging.getLogger("weasyprint").setLevel(logging.ERROR)
    logging.getLogger("fontTools").setLevel(logging.ERROR)
    weasyprint.HTML(filename=html_path).write_pdf(pdf_path)
    return pdf_path


def convert_pdf_weasyprint(html_paths, out_dir):
    """用 WeasyPrint 把脚本生成的 HTML 转成 PDF；多份时多进程并行（每份约 10 秒，主要耗在中文字体裁剪）。"""
    jobs = [(h, os.path.join(out_dir, os.path.splitext(os.path.basename(h))[0] + ".pdf")) for h in html_paths]
    workers = max(1, min(len(jobs), os.cpu_count() or 1, 4))
    try:
        if workers > 1:
            from concurrent.futures import ProcessPoolExecutor
            with ProcessPoolExecutor(workers) as ex:
                outs = list(ex.map(_weasy_one, jobs))
        else:
            outs = [_weasy_one(j) for j in jobs]
    except Exception as e:
        raise ReportError(f"WeasyPrint 转换 PDF 失败：{str(e)[:300]}", 3)
    return outs
SEC_HEAD_RE = re.compile(r"^\d+(?:\.\d+)?(?:\u3000|\s{2,})\s*([\u4e00-\u9fff（(].*)$")


def is_heading_line(line):
    """“1　考试基本情况”“2.1　核心指标”这类编号标题：编号顶格、后面是全角空格（pdftotext 转成多个空格）和短标题；
    正文（首行缩进，编号后单个空格）和表格行（列之间有多个空格）不算。"""
    m = SEC_HEAD_RE.match(line.rstrip())
    return bool(m) and len(m.group(1)) <= 30 and not re.search(r"\s{2,}", m.group(1))


def orphans_from_text(text):
    """pdftotext -layout 输出（按换页符分页）中，末行是区块标题的页码。"""
    bad = []
    for i, page in enumerate(text.split("\f"), 1):
        lines = [x.rstrip() for x in page.splitlines() if x.strip()]
        lines = [x for x in lines if not re.match(r"^(第\s*\d+\s*页\s*/\s*共\s*\d+\s*页|\d+)$", x.strip())]
        if lines and is_heading_line(lines[-1]):
            bad.append(i)
    return bad


def orphan_heading_pages(pdf):
    """检查 PDF 每页末尾是否是孤立的区块标题；没有 pdftotext 时返回 None（跳过检查）。"""
    if not shutil.which("pdftotext"):
        return None
    try:
        out = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True, text=True, timeout=120).stdout
    except Exception:
        return None
    return orphans_from_text(out)


PAGE_TOP, PAGE_BOT, PT_CM = 70.9, 776.7, 28.35  # 版心上下边界（pt）：上边距 2.5 cm、下边距 2.3 cm
CAP_RE = re.compile(r"^(图|表)(\d+)(?!\d)")
LAYOUT_PASSES = 5
SPLIT_LINES, SPLIT_BLANK = 10, 5.0  # 表身不少于 10 行、留白不少于 5 cm 时，长表可以跨页续排


def pdf_text_blocks(pdf):
    """每页版心内的文字块 [(上沿, 下沿, 文字)]（pt）；没有 pdftotext 时返回 None。"""
    if not shutil.which("pdftotext"):
        return None
    try:
        out = subprocess.run(["pdftotext", "-bbox-layout", pdf, "-"], capture_output=True, text=True,
                             timeout=120).stdout
    except Exception:
        return None
    pages = []
    for pg in re.findall(r"<page[^>]*>(.*?)</page>", out, flags=re.S):
        raw = []
        for x0, y0, y1, inner in re.findall(
                r'<block xMin="([\d.]+)" yMin="([\d.]+)" xMax="[\d.]+" yMax="([\d.]+)">(.*?)</block>', pg, flags=re.S):
            y0, y1 = float(y0), float(y1)
            if y0 >= PAGE_TOP - 5 and y1 <= PAGE_BOT + 3:
                raw.append((y0, float(x0), y1, html.unescape("".join(re.findall(r">([^<]*)</word>", inner)))))
        # 同一行被拆成几块的（如“图5”与图题文字、标题编号与标题，上下沿可能差几磅）：竖向重叠就合并，按从左到右拼接
        lines = []
        for y0, x0, y1, t in sorted(raw):
            if lines and y0 < lines[-1][1] - 1:
                ly0, ly1, parts = lines[-1]
                lines[-1] = (ly0, max(ly1, y1), parts + [(x0, t)])
            else:
                lines.append((y0, y1, [(x0, t)]))
        pages.append([(y0, y1, "".join(t for _, t in sorted(parts))) for y0, y1, parts in lines])
    return pages


def refine_layout(pdf, layout, min_blank=3.0, min_scale=0.75):
    """第二遍排版。某页底部留白 ≥ min_blank cm，且下一页以被挤过去的图或表开头（前面只有标题）时：
    图缩到 min_scale 以上能放下就缩小；放不下、或是表（表题、表头、表身必须同页，不能拆），
    就把它的分析段挪到它前面，用文字填补留白；表只差一点放不下时改为紧凑排版（行距、字号略小）；
    长表（表身 ≥ SPLIT_LINES 行、留白 ≥ SPLIT_BLANK cm）改为跨页续排：表题、表头和前两行同页，续页重复表头。返回是否有调整。"""
    pages = pdf_text_blocks(pdf)
    if not pages:
        return False
    changed = False
    for cur, nxt in zip(pages, pages[1:]):
        if not cur or not nxt:
            continue
        blank = PAGE_BOT - max(b[1] for b in cur)
        if blank < min_blank * PT_CM:
            continue
        k = next((i for i, b in enumerate(nxt[:6]) if CAP_RE.match(b[2])), None)
        if k is None or any(len(b[2]) > 32 or "。" in b[2] for b in nxt[:k]):
            continue  # 下一页不是以图表开头（或图表前有正文），留白不是图表被挤走造成的
        m = CAP_RE.match(nxt[k][2])
        key = ("f" if m.group(1) == "图" else "t", int(m.group(2)))
        if key[0] == "f":
            top = max([b[1] for b in nxt[:k]], default=PAGE_TOP)
            img = nxt[k][0] - top - 6  # 图片高度（图题在图下）
            end = nxt[k][1]
            if "数据来源" not in nxt[k][2] and k + 1 < len(nxt) and nxt[k + 1][2].startswith("数据来源"):
                end = nxt[k + 1][1]
            need = (end - PAGE_TOP + 8) - (blank - 0.3 * PT_CM)  # 整块放进上一页还差多少
            s0 = layout["scale"].get(key, 1.0)
            if img > 2 * PT_CM and need > 0:
                sc = math.floor(s0 * (1 - need / img) * 20) / 20
                lo = min_scale - 0.1 if img / s0 > 8 * PT_CM else min_scale  # 很高的图（如散点图）可以多缩一点
                if lo <= sc < s0:
                    layout["scale"][key] = sc
                    changed = True
                    continue
        else:
            j = next((i for i in range(k + 1, min(k + 60, len(nxt))) if nxt[i][2].startswith("数据来源")), None)
            end = nxt[j][1] if j is not None else None
            need = (end or 0) - PAGE_TOP + 8 - (blank - 0.3 * PT_CM)
            if end and 0 < need <= 0.2 * (end - nxt[k][0]) and key not in layout["compact"]:
                layout["compact"].add(key)  # 表只差一点：紧凑排版后整表放进上一页
                changed = True
                continue
            if j is not None and j - k - 1 >= SPLIT_LINES and blank >= SPLIT_BLANK * PT_CM and key not in layout["split"]:
                layout["split"].add(key)  # 长表：跨页续排，表题、表头和前两行留在上一页，续页重复表头
                changed = True
                continue
        if key not in layout["float"]:
            layout["float"].add(key)
            changed = True
    return changed


def scope_label(exam, classes, given):
    """成绩分析报告的范围名：(显示用, 文件名用)。一个班用班名；指定多个班用班名连接；不写 --class 用年级名。"""
    if len(classes) == 1:
        return classes[0], classes[0]
    g = "" if given else (exam.meta.get("grade_scope") or exam.cfg.get("年级") or "")
    if g:
        return g, g
    if len(classes) <= 4:
        return "、".join(classes), "+".join(classes)
    return f"{classes[0]}等{len(classes)}个班", f"{classes[0]}等{len(classes)}个班"


def dump_numbers(exam, cls, studs, path):
    data = {"class": cls, "overall": exam.overall(studs), "sections": exam.sec_rates(studs),
            "questions": exam.q_stats(studs), "ranks": exam.ranks(studs)}
    if exam.has_subj:
        data["subjects"] = {x: exam.subj_stats(studs, x) for x in exam.subjects}
        data["classes"] = {c: {"overall": exam.overall(exam.in_class(c)),
                               "subjects": {x: exam.subj_stats(exam.in_class(c), x) for x in exam.subjects}}
                           for c in OrderedDict.fromkeys(s["class"] for s in studs)}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def cmd_render(args):
    if args.type == "score" and args.scope == "student":
        raise ReportError("成绩分析报告没有单人版（不写 --scope 或写 --scope class）；单个学生请出错题分析报告单人版", 2)
    if args.type == "error" and args.scope == "student" and not args.student:
        raise ReportError("单人版需要 --student <考号|姓名|all>", 2)
    exam, analysis, history = load_context(args)
    if args.type == "error" and not exam.has_q:
        raise ReportError(NO_ITEM_SCORES, 2)
    if args.type == "error" and not args.paper:
        raise ReportError("错题分析报告需要题目档案（--paper），用于知识点与题干", 2)
    given = split_classes(args.cls)
    classes = given or exam.classes()
    if args.type == "paper" and len(classes) > 8:
        raise ReportError("试卷分析报告最多 8 个班；请用 --class 指定要合并的班级", 2)
    if args.type == "score" and len(classes) > 30:
        raise ReportError("成绩分析报告最多 30 个班；请用 --class 指定班级", 2)
    for c in classes:
        if not exam.in_class(c):
            raise ReportError(f"数据集中没有班级 {c}；现有班级：{'、'.join(exam.classes())}", 2)
        if (args.type == "score" or args.scope == "class") and len(exam.in_class(c)) < 2:
            raise ReportError(f"{c} 只有 1 名学生的成绩，全班版报告需要至少 2 人。只有一名学生时请出单人版"
                              "（--type error --scope student --student <考号|姓名>），单人版不会做班级对比。", 2)
    ph = sorted({x for st in exam.students for x in (st["name"], st["class"]) if PLACEHOLDER_RE.match(str(x))})
    if ph:
        print(f"  [提示] 姓名/班级像是占位文字：{'、'.join(ph)}。读不出时请留空并在 flag 标“待确认”，"
              "不要填占位文字（会直接印在报告抬头上）。")
    # 文字检查（先查完再出文件）
    errors = []
    if args.type == "paper":
        errors += check_paper(exam, analysis, classes)
    elif args.type == "score":
        errors += check_score(exam, analysis, classes)
    else:
        for cls in classes:
            errors += check_analysis(exam, analysis, args.type, args.scope, cls, args.student,
                                     conclusion_ids=set((analysis.get("conclusions") or {}).keys()))
    if args.type == "error" and args.scope == "student":
        targets = [(cls, s) for cls in classes for s in scope_students(exam, cls, args.student)]
        if not targets:
            raise ReportError(f"没有找到学生 {args.student}", 2)
    if errors:
        print(f"✗ 分析文字检查未通过（{len(errors)} 处），未出报告：")
        for x in errors[:80]:
            print("  -", x)
        if len(errors) > 80:
            print(f"  ……另有 {len(errors) - 80} 处")
        return 1
    if args.check_only:
        print("✓ 分析文字检查通过")
        return 0
    formats = parse_formats(args.format or exam.cfg.get("报告格式") or "PDF")
    word_font, mpl_font = find_fonts()
    engine = pick_pdf_engine(args.pdf_engine) if "pdf" in formats else None
    os.makedirs(args.out_dir, exist_ok=True)
    exam_name = safe_name(exam.meta.get("name") or exam.exam_id)
    produced = []
    with tempfile.TemporaryDirectory() as work:
        charts = Charts(mpl_font, work)
        b = Builder(exam, analysis, history, charts, word_font)
        jobs = []
        if args.type == "paper":
            jobs.append((f"{exam_name}_{safe_name('+'.join(classes))}_试卷分析报告", lambda: b.paper_report(classes)))
        elif args.type == "score":
            label, file_label = scope_label(exam, classes, given)
            jobs.append((f"{exam_name}_{safe_name(file_label)}_成绩分析报告", lambda: b.score_report(classes, label)))
        elif args.scope == "class":
            for cls in classes:
                jobs.append((f"{exam_name}_{safe_name(cls)}_错题分析报告", lambda cls=cls: b.error_class(cls)))
        else:
            names = defaultdict(int)
            for cls, s in targets:
                names[(cls, s["name"])] += 1
            for cls, s in targets:
                who = s["name"] + (f"_{s['sid']}" if names[(cls, s["name"])] > 1 else "")
                jobs.append((f"{exam_name}_{safe_name(cls)}_{safe_name(who)}_错题分析报告",
                             lambda cls=cls, s=s: b.error_student(cls, s)))
        docx_dir = args.out_dir if "docx" in formats else os.path.join(work, "docx")
        html_dir = args.out_dir if "html" in formats else os.path.join(work, "html")
        os.makedirs(docx_dir, exist_ok=True)
        os.makedirs(html_dir, exist_ok=True)
        need_docx = "docx" in formats or engine == "libreoffice"
        need_html = "html" in formats or engine == "weasyprint"
        stems = [stem for stem, _ in jobs]
        docx_paths = [os.path.join(docx_dir, x + ".docx") for x in stems]
        html_paths = [os.path.join(html_dir, x + ".html") for x in stems]
        layouts = {x: {"scale": {}, "float": set(), "compact": set(), "split": set()} for x in stems}

        def write(sel):
            """按当前版面调整生成 Word / HTML（三种格式用同一套调整，内容与顺序一致）。"""
            for stem, build in jobs:
                if stem in sel:
                    b.layout = layouts[stem]
                    if need_docx:
                        b.D = Doc
                        build().save(os.path.join(docx_dir, stem + ".docx"))
                    if need_html:
                        b.D = HtmlDoc
                        build().save(os.path.join(html_dir, stem + ".html"))

        def to_pdf(sel):
            if engine == "libreoffice":
                return convert_pdf([os.path.join(docx_dir, x + ".docx") for x in sel], args.out_dir)
            return convert_pdf_weasyprint([os.path.join(html_dir, x + ".html") for x in sel], args.out_dir)

        write(set(stems))
        warns = []
        if "pdf" in formats:
            pdfs = dict(zip(stems, to_pdf(stems)))
            # 第二遍排版：图表被挤到下一页、上一页留下大片空白时，缩小图或把分析段挪到图表前，再重排（最多 3 遍；批量时 1 遍）
            todo = stems
            for _ in range(LAYOUT_PASSES if len(stems) <= 5 else 1):
                todo = [x for x in todo if refine_layout(pdfs[x], layouts[x])]
                if not todo:
                    break
                write(set(todo))
                pdfs.update(zip(todo, to_pdf(todo)))
            n_sc = sum(len(v["scale"]) for v in layouts.values())
            n_fl = sum(len(v["float"]) for v in layouts.values())
            n_cp = sum(len(v["compact"]) for v in layouts.values())
            n_sp = sum(len(v["split"]) for v in layouts.values())
            acts = [t for n, t in ((n_sc, f"缩小 {n_sc} 张图"), (n_cp, f"{n_cp} 张表改紧凑排版"),
                                   (n_sp, f"{n_sp} 张长表跨页续排（续页重复表头）"),
                                   (n_fl, f"{n_fl} 段分析移到图表前面")) if n]
            if acts:
                print(f"  版面调整：{'、'.join(acts)}，以减少页面留白。")
            produced += [pdfs[x] for x in stems]
            for pdf in [pdfs[x] for x in stems]:
                bad = orphan_heading_pages(pdf)
                if bad:
                    warns.append(f"{os.path.basename(pdf)}：第 {'、'.join(map(str, bad))} 页末尾是孤立的区块标题")
        if "docx" in formats:
            produced += docx_paths
        if "html" in formats:
            produced += html_paths
        if args.dump_json:
            scope = classes if args.type in ("score", "paper") else classes[:1]
            dump_numbers(exam, "+".join(scope), [s for c in scope for s in exam.in_class(c)], args.dump_json)
    eng = {"libreoffice": "；PDF 由 LibreOffice 转换", "weasyprint": "；PDF 由 WeasyPrint 转换"}.get(engine, "")
    print(f"✓ 已生成 {len(produced)} 个文件（{' + '.join(FORMAT_NAMES[f] for f in formats)}{eng}）：")
    for p in produced:
        print("  ", p)
    for w in warns:
        print("  [提示]", w)
    return 0


def main():
    ap = argparse.ArgumentParser(description="学情报告生成（固定版式，PDF / Word / HTML）")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("skeleton", "render"):
        p = sub.add_parser(name)
        p.add_argument("--type", choices=["error", "score", "paper"], required=True,
                       help="error=错题分析报告 score=成绩分析报告 paper=试卷分析报告")
        p.add_argument("--scope", choices=["class", "student"], default="class")
        p.add_argument("--dataset", required=True)
        p.add_argument("--paper")
        p.add_argument("--analysis", help="分析文件 <exam>_分析.json")
        p.add_argument("--index", help="exam_index.json（读取口径、考试信息与历次数据）")
        p.add_argument("--exam-id")
        p.add_argument("--exam-name")
        p.add_argument("--class", dest="cls", help="班级；多个班用逗号分隔。成绩分析报告与试卷分析报告合成一份，不写时为全部班级")
        p.add_argument("--student", help="考号 / 姓名 / all")
        if name == "render":
            p.add_argument("--format", help="pdf / word / html，可组合：pdf+html、pdf,word；all = 三种；"
                                            "不写时取 config.报告格式，默认 PDF")
            p.add_argument("--pdf-engine", default="auto",
                           help="auto（默认：有 LibreOffice 用它，否则用 WeasyPrint）/ libreoffice / weasyprint")
            p.add_argument("--out-dir", default="学情报告")
            p.add_argument("--check-only", action="store_true")
            p.add_argument("--dump-json", help="把计算出的数字另存一份，供回读核对")
    args = ap.parse_args()
    try:
        if args.cmd == "skeleton":
            cmd_skeleton(args)
            sys.exit(0)
        sys.exit(cmd_render(args))
    except ReportError as e:
        print(f"✗ {e}")
        sys.exit(e.code)


if __name__ == "__main__":
    main()
