#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""登记/更新考试档案 exam_index.json（doubao-xueqing-manager 模式A）。

DEFAULT_CONFIG 也被 report.py 用来补齐旧档案缺失的口径键。

用法:
    python3 build_exam_index.py --index <exam_index.json> \
        --exam-id zk1 --name "第一周周练(全年级)" --subject 数学 \
        --full-score 140 --date 2026-09-29 --dataset <路径> [--paper <路径>] \
        [--grade-scope 全年级] [--subjects "语文:150,数学:150,英语:120"] [--remove]

说明:
- --dataset/--paper 若为相对路径，以 exam_index.json 所在目录为基准进行存在性校验，并按相对路径存储。
- --subjects 多科成绩表用：各科满分；不写 --full-score 时满分取各科之和。
- --remove 从档案中移除指定 exam-id（不删除数据文件）。
- 无 --index 时默认在当前目录的 exam_index.json 上操作。
退出码: 0=成功  1=失败（如 exam-id 不存在、文件缺失）
"""
import argparse
import json
import os
import re
import sys

DEFAULT_CONFIG = {
    "及格线": 0.6,
    "良好线": 0.75,
    "优秀线": 0.85,
    "低分线": 0.4,
    "分数段": [0.0, 0.4, 0.6, 0.75, 0.85, 1.0],
    "分档名称": ["低分", "待及格", "及格", "良好", "优秀"],
    "临界分差": 0.05,
    "高频错题TopN": 8,
    "单人高频错题TopN": 5,
    "科目": "",
    "年级": "",
    "语言": "简体中文",
    "报告格式": "PDF",  # PDF / Word / HTML，可组合（PDF+HTML）；全部 = 三种
    "学校": "",  # 成绩分析报告封面用；没有就不写
    "编制部门": "",
    "编制日期": "",  # 成绩分析报告封面与落款用，如“2026年10月”；没有就不写
}


def parse_subjects(value):
    """各科满分："语文:150,数学:150,英语:120" → {"语文": 150.0, ...}（保持顺序）。"""
    out = {}
    for part in re.split(r"[,，、;；]", value or ""):
        part = part.strip()
        if not part:
            continue
        m = re.match(r"^(.+?)\s*[:：=]\s*([\d.]+)$", part)
        if not m:
            raise ValueError(f"科目满分写法不对：{part!r}（应为 科目:满分，如 语文:150）")
        out[m.group(1).strip()] = float(m.group(2))
    return out


def load_index(path):
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            idx = json.load(f)
        if "exams" not in idx:
            idx = {"config": dict(DEFAULT_CONFIG), "exams": idx.get("exams", [])}
        idx.setdefault("config", dict(DEFAULT_CONFIG))
        idx.setdefault("exams", [])
        return idx
    return {"config": dict(DEFAULT_CONFIG), "exams": []}


def save_index(path, idx):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(idx, f, ensure_ascii=False, indent=2)
    print(f"已写入 {path}")


def resolve(base_dir, p):
    """相对路径以 base_dir 为基准校验存在性；返回存储用路径（相对 base_dir）。"""
    if os.path.isabs(p):
        return p
    ap = os.path.join(base_dir, p)
    if not os.path.exists(ap):
        raise FileNotFoundError(f"文件不存在: {ap}")
    return os.path.relpath(ap, base_dir)


def main():
    ap = argparse.ArgumentParser(description="登记/更新考试档案 exam_index.json")
    ap.add_argument("--index", default="exam_index.json", help="exam_index.json 路径（默认当前目录）")
    ap.add_argument("--exam-id", required=True, help="考试唯一标识，如 zk1")
    ap.add_argument("--name", help="考试名称")
    ap.add_argument("--subject", help="科目")
    ap.add_argument("--grade-scope", help="年级/范围")
    ap.add_argument("--full-score", type=float, help="满分")
    ap.add_argument("--date", help="考试日期 YYYY-MM-DD")
    ap.add_argument("--dataset", help="成绩数据集 JSON 路径")
    ap.add_argument("--paper", help="题目档案 JSON 路径（可选）")
    ap.add_argument("--subjects", help="多科成绩：各科满分，如 \"语文:150,数学:150,英语:120\"")
    ap.add_argument("--remove", action="store_true", help="从档案中移除该考试")
    args = ap.parse_args()

    base_dir = os.path.dirname(os.path.abspath(args.index)) or "."
    idx = load_index(args.index)

    if args.remove:
        before = len(idx["exams"])
        idx["exams"] = [e for e in idx["exams"] if e.get("exam_id") != args.exam_id]
        if len(idx["exams"]) == before:
            print(f"exam-id 不存在: {args.exam_id}")
            sys.exit(1)
        save_index(args.index, idx)
        print(f"已移除 {args.exam_id}（剩余 {len(idx['exams'])} 场考试）")
        sys.exit(0)

    entry = {"exam_id": args.exam_id}
    if args.name:
        entry["name"] = args.name
    if args.subject:
        entry["subject"] = args.subject
    if args.grade_scope:
        entry["grade_scope"] = args.grade_scope
    if args.subjects:
        try:
            entry["subjects"] = parse_subjects(args.subjects)
        except ValueError as e:
            print(e)
            sys.exit(1)
    if args.full_score is not None:
        entry["full_score"] = args.full_score
    elif entry.get("subjects"):
        entry["full_score"] = sum(entry["subjects"].values())
    if entry.get("subjects") and abs(entry["full_score"] - sum(entry["subjects"].values())) > 1e-6:
        print(f"满分 {entry['full_score']} 与各科满分之和 {sum(entry['subjects'].values())} 不一致")
        sys.exit(1)
    if args.date:
        entry["date"] = args.date
    if args.dataset:
        try:
            entry["dataset"] = resolve(base_dir, args.dataset)
        except FileNotFoundError as e:
            print(e)
            sys.exit(1)
    if args.paper:
        try:
            entry["paper"] = resolve(base_dir, args.paper)
        except FileNotFoundError as e:
            print(e)
            sys.exit(1)

    for i, e in enumerate(idx["exams"]):
        if e.get("exam_id") == args.exam_id:
            idx["exams"][i] = entry
            break
    else:
        idx["exams"].append(entry)

    # 按日期排序（无日期的排最后）
    idx["exams"].sort(key=lambda e: e.get("date", "9999-99-99"))
    save_index(args.index, idx)
    print(f"已登记/更新 {args.exam_id}（共 {len(idx['exams'])} 场考试）")
    sys.exit(0)


if __name__ == "__main__":
    main()
