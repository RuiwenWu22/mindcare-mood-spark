#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""按坐标裁剪原题 / 学生作答截图（可选能力，供报告逐题卡片使用）。

用法:
    python3 crop_regions.py --image IMG_5522.jpg --boxes boxes.json --out-dir 学情数据/截图 [--prefix 李沐池_]

boxes.json 示例（坐标可以是像素，也可以是 0~1 的比例，[左, 上, 右, 下]）:
    {"zk1-Q3": [0.06, 0.31, 0.95, 0.42], "zk1-Q12": [120, 1680, 1980, 2260]}

输出 <out-dir>/<prefix><qid>.png，并打印 qid → 路径 的 JSON，可直接写入
题目档案的 image 字段（原题）或成绩记录 scores[qid].image（本人作答）。
裁剪后必须打开图片核对：题号、题干与批改痕迹完整，没有切到相邻题。
退出码: 0=成功  1=失败
"""
import argparse
import json
import os
import sys


def main():
    ap = argparse.ArgumentParser(description="按坐标裁剪题目截图")
    ap.add_argument("--image", required=True)
    ap.add_argument("--boxes", required=True, help="qid → [左, 上, 右, 下] 的 JSON 文件")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--prefix", default="")
    ap.add_argument("--pad", type=float, default=0.01, help="四周留白（占图片边长比例）")
    args = ap.parse_args()
    try:
        from PIL import Image
    except ImportError:
        print("需要 Pillow：pip install pillow")
        sys.exit(1)
    with open(args.boxes, encoding="utf-8") as f:
        boxes = json.load(f)
    img = Image.open(args.image)
    W, H = img.size
    os.makedirs(args.out_dir, exist_ok=True)
    out = {}
    for qid, b in boxes.items():
        if len(b) != 4:
            print(f"{qid}: 坐标必须是 4 个数")
            sys.exit(1)
        x0, y0, x1, y1 = [float(v) for v in b]
        if max(x0, y0, x1, y1) <= 1.0:
            x0, x1, y0, y1 = x0 * W, x1 * W, y0 * H, y1 * H
        px, py = args.pad * W, args.pad * H
        x0, y0 = max(0, x0 - px), max(0, y0 - py)
        x1, y1 = min(W, x1 + px), min(H, y1 + py)
        if x1 - x0 < 10 or y1 - y0 < 10:
            print(f"{qid}: 裁剪区域过小 {b}")
            sys.exit(1)
        p = os.path.join(args.out_dir, f"{args.prefix}{qid}.png")
        img.crop((int(x0), int(y0), int(x1), int(y1))).save(p)
        out[qid] = p
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
